<?php
defined('BASEPATH') OR exit('No Direct Script access allowed');

class Product extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Webadmin/Product_model');
                $this->load->model('Webadmin/Admin_model');
                $this->load->helper("file");

                
	}
	
	public function index()
        {
            if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
            $page= 'product';
            $data['page'] = $page;
            
            $fetch = $this->Admin_model->fetch_all_join("select * from nsn_product where Status='Yes' Order by Id desc");
            $data['fetch'] = $fetch;
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/product');
            $this->load->view('Webadmin/footer');
        }
	
        public function add_product()
        {
           
            error_reporting(0);
            if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
             $page= 'product';
            $data['page'] = $page;
            
            $image = "";
            if($this->input->post('submit') == 'Submit')
            {
                $title = $this->input->post('title');
                $category=$this->input->post('category');
            
                $price=$this->input->post('Price');
                  //$subtitle=$this->input->post('subtitle');
                $quantity=$this->input->post('Quantity');
                
                $desc=$this->input->post('desc');
                
                //$old_image = $this->input->post('old_img');
                $config['upload_path']   = './Banner/'; 
                $config['allowed_types'] = 'gif|jpg|png'; 
                $config['max_size']      = 2048; 
                $config['max_width']     = 3000; 
                $config['max_height']    = 2000;  
                $config['file_name']=  uniqid();
                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('file')) {
                   $error = array('error' => $this->upload->display_errors()); 

                }

                else { 
                   $file_data = $this->upload->data(); 
                   $image = $file_data['file_name'];
                     


                } 
                
                $field_data = array(
                        'title' => $title,
                         //'subtitle' =>$subtitle,
                          'category' =>$category,
                         'price' => $price,
                     'quantity' => $quantity,
                    'description'=>$desc,
                 
                        'image' => $image,
                        'Status' => 'Yes'
                        );
                $result = $this->Product_model->add_details($field_data);
                if($result){
                    $succ = "Data Added Successfully";
                    $data['succ']=$succ;
                    redirect(base_url().'Webadmin/Product');
                }
           }
            //$cms = $this->Cms_model->fetch_all();
            //$data['cms'] = $cms;
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/product_details');
            $this->load->view('Webadmin/footer');
        }
        
        public function edit_product()
        {   if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
             $page= 'product';
            $data['page'] = $page;
            
            if($this->input->post('submit') == 'Submit')
            {
                
                $id = $this->input->post('id');
                $title = $this->input->post('title');
                $category=$this->input->post('category');
                  $subtitle=$this->input->post('subtitle');
                
                $price=  $this->input->post('Price');
                $quantity=$this->input->post('Quantity');
                 
                $desc=$this->input->post('desc');
                
                
                $config['upload_path']   = './Banner/'; 
                $config['allowed_types'] = 'gif|jpg|png'; 
                $config['max_size']      = 3072; 
                $config['max_width']     = 6000; 
                $config['max_height']    = 6000;  
                  $config['file_name']=  uniqid();
                $this->load->library('upload', $config);
                //$upload_data = $this->upload->data(); //Returns array of containing all of the data related to the file you uploaded.
               

                if ( ! $this->upload->do_upload('file')) {
                   $error = array('error' => $this->upload->display_errors()); 
                    $image = $this->input->post('old_img');
                }

                else { 
                    $file_data = $this->upload->data(); 
                   $image = $file_data['file_name'];
                   
                   if($this->input->post('old_img') != "")
                        unlink('./Banner/'.$this->input->post('old_img'));


                }
               
                $field_data = array(
                         'title' => $title,
                    'subtitle' =>$subtitle,
                     'category' =>$category,
                         'price' => $price,
                     'quantity' => $quantity,
                       'description'=>$desc,
                        'image' => $image,
                        'Status' => 'Yes'
                        );
                $result = $this->Product_model->eidt_details($field_data,$id);
                if($result){
                    $succ = "Data Updated Successfully";
                    $data['succ']=$succ;
                    $fetch = $this->Product_model->fetch_single($id);
                    $data['fetch'] = $fetch;
                    
                }
           }else{
            
                $id = $this->uri->segment(4);
                $fetch = $this->Product_model->fetch_single($id);
                $data['fetch'] = $fetch;
            
           }
            
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/product_details',$data);
            $this->load->view('Webadmin/footer');
        }
	//Start About-------------------------------------------------------------------------------------------
	function view_product()
	{
            if(!$this->session->userdata('is_logged_in'))
            {
            redirect('Webadmin/Login');
            }
            $page= 'product';
            $data['page'] = $page;
            
            $id = $this->uri->segment(4);
            $fetch = $this->Product_model->fetch_single($id);
            $data['fetch'] = $fetch;
            
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/product_details',$data);
            $this->load->view('Webadmin/footer');
	}
        
        public function delete_product()
	{
            
           $id = $this->input->get('id', TRUE);
            $fetch = $this->Product_model->fetch_single($id);
                //print_r( $fetch);exit();
                unlink('./Banner/'.$fetch->image);
           $banner = $this->Product_model->delete_single($id);
           if($banner){
               
                echo 'deleted';
           } 
            
	}
//End About---------------------------------------------------------------------------------------------
	

	
}


?>