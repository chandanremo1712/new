<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->database();


        $this->load->library('form_validation');
        $this->load->model('Webadmin/Admin_model');
        $this->load->helper("file");

        $this->load->library('image_lib');
        $this->load->helper("url");

     

    }

    function index() {
        
        $page = 'admin';
        $data['page'] = $page;
        
      
        
        
        $fetch = $this->Admin_model->fetch_single_join('select * from admin where id=1');
        
        echo $fetch->username;
        echo '<p></p>';
        
        echo base64_decode($fetch->password);
       
        
        exit();
        
        
        
        $data['fetch'] = $fetch;
        $this->load->view('Admin/header');
        $this->load->view('Admin/leftbar',$data);
        $this->load->view('Admin/Employee', $data);
        $this->load->view('Admin/footer');
    }
    
}
    
    ?>