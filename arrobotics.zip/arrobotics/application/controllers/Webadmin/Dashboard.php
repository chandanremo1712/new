<?php
error_reporting(0);
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->database();
        $this->load->model('Webadmin/Admin_model');
          $this->load->helper("file");

        $this->load->library('image_lib');
    }

    public function index() {
        $page = "home";
        $data['page'] = $page;
        $data['Admin_model'] = $this->Admin_model;
        $this->load->view('Webadmin/header');
        $this->load->view('Webadmin/leftbar', $data);
        $this->load->view('Webadmin/dashboard');
        //$this->load->view('Webadmin/footer');
    }

    function About() {


        if ($this->input->post('submit') == "Submit") {
            
            
                $id = $this->input->post('id');
                $title = $this->input->post('title');
                  $short_description = $this->input->post('short_description');
                $description = $this->input->post('desc');
              
                
                $config['upload_path']   = './CMS/'; 
                $config['allowed_types'] = 'gif|jpg|png'; 
               $config['max_size']      = 204800; 
                $config['max_width']     = 300000; 
                $config['max_height']    = 200000;  
                $config['file_name']    = uniqid();  
                $this->load->library('upload', $config);
                //$upload_data = $this->upload->data(); //Returns array of containing all of the data related to the file you uploaded.
               

                if ( ! $this->upload->do_upload('file')) {
                   $error = array('error' => $this->upload->display_errors()); 
                    $image = $this->input->post('old_img');
                    
                   // print_r($error);
                   // exit();
                }

                else { 
                    $file_data = $this->upload->data(); 
                   $image = $file_data['file_name'];
                   
                   if($this->input->post('old_img') != "")
                        unlink('./CMS/'.$this->input->post('old_img'));


                }
               
                $field_data = array(
                        'title' => $title,
                    'short_description' =>$short_description,
                        'description' => $description,
                        'image' => $image
                        );
                $result = $this->Admin_model->eidt_details('about', $field_data,1);
                if($result){
                    $succ = "Data Updated Successfully";
                    $data['succ']=$succ;
                   
                    
                }
            
            
        }
 $fetch = $this->Admin_model->fetch_single('about', 1);
                    $data['fetch'] = $fetch;
        $page = "about";
        $data['page'] = $page;
        $data['Admin_model'] = $this->Admin_model;
        $this->load->view('Webadmin/header');
        $this->load->view('Webadmin/leftbar', $data);
        $this->load->view('Webadmin/About');
        $this->load->view('Webadmin/footer');
    }
    
    
    function Company() {


        if ($this->input->post('submit') == "Submit") {
            
            
                $id = $this->input->post('id');
               // $title = $this->input->post('title');
                  //$short_description = $this->input->post('short_description');
                $description = $this->input->post('desc');
              
                
               
                $field_data = array(
                       // 'title' => $title,
                   // 'short_description' =>$short_description,
                        'description' => $description
                       
                        );
                $result = $this->Admin_model->eidt_details('company', $field_data,1);
                if($result){
                    $succ = "Data Updated Successfully";
                    $data['succ']=$succ;
                   
                    
                }
            
            
        }
 $fetch = $this->Admin_model->fetch_single('company', 1);
                    $data['fetch'] = $fetch;
        $page = "company";
        $data['page'] = $page;
        $data['Admin_model'] = $this->Admin_model;
        $this->load->view('Webadmin/header');
        $this->load->view('Webadmin/leftbar', $data);
        $this->load->view('Webadmin/Company');
        $this->load->view('Webadmin/footer');
    }
    
    
    
    
    
    
function Terms() {

if ($this->input->post('submit') == "Submit") {

$id = $this->input->post('id');
$title = $this->input->post('title');
$description = $this->input->post('desc');

$config['upload_path']   = './CMS/'; 
$config['allowed_types'] = 'gif|jpg|png'; 
$config['max_size']      = 2048; 
$config['max_width']     = 3000; 
$config['max_height']    = 2000;  
$config['file_name']    = uniqid();  
$this->load->library('upload', $config);
//$upload_data = $this->upload->data(); //Returns array of containing all of the data related to the file you uploaded.


if ( ! $this->upload->do_upload('file')) {
$error = array('error' => $this->upload->display_errors()); 
$image = $this->input->post('old_img');
}

else { 
$file_data = $this->upload->data(); 
$image = $file_data['file_name'];

if($this->input->post('old_img') != "")
unlink('./CMS/'.$this->input->post('old_img'));


}

$field_data = array(
//'title' => $title,
'description' => $description

);
$result = $this->Admin_model->eidt_details('terms', $field_data,1);

//echo $this->db->last_query();
//exit();

if($result){
$succ = "Data Updated Successfully";
$data['succ']=$succ;


}


}
$fetch = $this->Admin_model->fetch_single('terms', 1);
$data['fetch'] = $fetch;
$page = "terms";
$data['page'] = $page;
$data['Admin_model'] = $this->Admin_model;
$this->load->view('Webadmin/header');
$this->load->view('Webadmin/leftbar', $data);
$this->load->view('Webadmin/Terms');
$this->load->view('Webadmin/footer');
}
    
    
    
    
    function Privacy() {


        if ($this->input->post('submit') == "Submit") {
            
            
                $id = $this->input->post('id');
                $title = $this->input->post('title');
                $description = $this->input->post('desc');
                
                $config['upload_path']   = './CMS/'; 
                $config['allowed_types'] = 'gif|jpg|png'; 
               $config['max_size']      = 2048; 
                $config['max_width']     = 3000; 
                $config['max_height']    = 2000;  
                $config['file_name']    = uniqid();  
                $this->load->library('upload', $config);
                //$upload_data = $this->upload->data(); //Returns array of containing all of the data related to the file you uploaded.
               

                if ( ! $this->upload->do_upload('file')) {
                   $error = array('error' => $this->upload->display_errors()); 
                    $image = $this->input->post('old_img');
                }

                else { 
                    $file_data = $this->upload->data(); 
                   $image = $file_data['file_name'];
                   
                   if($this->input->post('old_img') != "")
                        unlink('./CMS/'.$this->input->post('old_img'));


                }
               
                $field_data = array(
                        //'title' => $title,
                        'description' => $description
                        //'image' => $image
                        );
                $result = $this->Admin_model->eidt_details('privacy_policy', $field_data,1);
                if($result){
                    $succ = "Data Updated Successfully";
                    $data['succ']=$succ;
                    
                     redirect(base_url().'Webadmin/Dashboard/Privacy/1');
                   
                    
                }
            
            
        }
 $fetch = $this->Admin_model->fetch_single('privacy_policy', 1);
                    $data['fetch'] = $fetch;
        $page = "policy";
        $data['page'] = $page;
        $data['Admin_model'] = $this->Admin_model;
        $this->load->view('Webadmin/header');
        $this->load->view('Webadmin/leftbar', $data);
        $this->load->view('Webadmin/Privacy');
       $this->load->view('Webadmin/footer');
        
        
       
    }
    
    
    function Refund() {


        if ($this->input->post('submit') == "Submit") {
            
            
                $id = $this->input->post('id');
                $title = $this->input->post('title');
                $description = $this->input->post('desc');
                
                $config['upload_path']   = './CMS/'; 
                $config['allowed_types'] = 'gif|jpg|png'; 
               $config['max_size']      = 2048; 
                $config['max_width']     = 3000; 
                $config['max_height']    = 2000;  
                $config['file_name']    = uniqid();  
                $this->load->library('upload', $config);
                //$upload_data = $this->upload->data(); //Returns array of containing all of the data related to the file you uploaded.
               

                if ( ! $this->upload->do_upload('file')) {
                   $error = array('error' => $this->upload->display_errors()); 
                    $image = $this->input->post('old_img');
                }

                else { 
                    $file_data = $this->upload->data(); 
                   $image = $file_data['file_name'];
                   
                   if($this->input->post('old_img') != "")
                        unlink('./CMS/'.$this->input->post('old_img'));


                }
               
                $field_data = array(
                        //'title' => $title,
                        'description' => $description
                        //'image' => $image
                        );
                $result = $this->Admin_model->eidt_details('privacy_policy', $field_data,2);
                if($result){
                    $succ = "Data Updated Successfully";
                    $data['succ']=$succ;
                    redirect(base_url().'Webadmin/Dashboard/Refund/2');
                    
                }
            
            
        }
 $fetch = $this->Admin_model->fetch_single('privacy_policy', 2);
                    $data['fetch'] = $fetch;
        $page = "refund";
        $data['page'] = $page;
        $data['Admin_model'] = $this->Admin_model;
        $this->load->view('Webadmin/header');
        $this->load->view('Webadmin/leftbar', $data);
        $this->load->view('Webadmin/Privacy');
        $this->load->view('Webadmin/footer');
    }
    
    
    function Delivery() {


        if ($this->input->post('submit') == "Submit") {
            
            
                $id = $this->input->post('id');
                $title = $this->input->post('title');
                $description = $this->input->post('desc');
                
                $config['upload_path']   = './CMS/'; 
                $config['allowed_types'] = 'gif|jpg|png'; 
               $config['max_size']      = 2048; 
                $config['max_width']     = 3000; 
                $config['max_height']    = 2000;  
                $config['file_name']    = uniqid();  
                $this->load->library('upload', $config);
                //$upload_data = $this->upload->data(); //Returns array of containing all of the data related to the file you uploaded.
               

                if ( ! $this->upload->do_upload('file')) {
                   $error = array('error' => $this->upload->display_errors()); 
                    $image = $this->input->post('old_img');
                }

                else { 
                    $file_data = $this->upload->data(); 
                   $image = $file_data['file_name'];
                   
                   if($this->input->post('old_img') != "")
                        unlink('./CMS/'.$this->input->post('old_img'));


                }
               
                $field_data = array(
                        'title' => $title,
                        'description' => $description
                        //'image' => $image
                        );
                $result = $this->Admin_model->eidt_details('privacy_policy', $field_data,3);
                if($result){
                    $succ = "Data Updated Successfully";
                    $data['succ']=$succ;
                     redirect(base_url().'Webadmin/Dashboard/Delivery/3');
                   
                    
                }
            
            
        }
 $fetch = $this->Admin_model->fetch_single('privacy_policy', 3);
                    $data['fetch'] = $fetch;
        $page = "delivery";
        $data['page'] = $page;
        $data['Admin_model'] = $this->Admin_model;
        $this->load->view('Webadmin/header');
        $this->load->view('Webadmin/leftbar', $data);
        $this->load->view('Webadmin/Privacy');
        $this->load->view('Webadmin/footer');
    }
    
    
    
      function Category()
        {
                if(!$this->session->userdata('is_logged_in'))
            {
            redirect('Webadmin/Login');
            }
          $data['page']="cat";
           
            $fetch = $this->Admin_model->fetch_all('event_category');
            $data['fetch'] = $fetch;
            
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/Category',$data);
            $this->load->view('Webadmin/footer');
        }
	
        
        
        
        function AddCategory() {
             if(!$this->session->userdata('is_logged_in'))
            {
            redirect('Webadmin/Login');
            }
            $page='cat';
            $data['page']=$page;
            if($this->input->post('submit') == 'Submit')
            {
                     
                
             
				
                 $title = stripslashes($this->input->post('title'));
                  $field_data = array(
                        'category' => $title
                      );
                   $result = $this->Admin_model->add_details('event_category', $field_data);
           
                    if($result){
                    $succ = "Data Added Successfully";
                    $data['succ']=$succ;
                }
                   
            }
            
            
            
             $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/AddCategory');
            $this->load->view('Webadmin/footer');
            
        }
        
        
        
        public function EditCategory()
        {   if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
            $page = 'cat';
            $data['page'] = $page;
           
            if($this->input->post('submit') == 'Submit')
            {
                
                $id = $this->input->post('id');
                $title = stripslashes($this->input->post('title'));
            
                
                
                $field_data = array(
                        'category' => $title
                       
                        );
                $result = $this->Admin_model->edit_details('event_category', $field_data,$id);
                if($result){
                    $succ = "Data Updated Successfully";
                    $data['succ']=$succ;
                    $fetch = $this->Admin_model->fetch_single('event_category', $id);
                    $data['fetch'] = $fetch;
                    
                }
           }else{
            
                $id = $this->uri->segment(4);
                $fetch = $this->Admin_model->fetch_single('event_category', $id);
                $data['fetch'] = $fetch;
            
           }
            
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/AddCategory',$data);
            $this->load->view('Webadmin/footer');
        }
        
        
        
        
         public function DelCategory()
	{
            
           $id = $this->input->get('id', TRUE);
           
           $faq = $this->Admin_model->delete_single('event_category', $id);
           if($faq){
               
                echo 'deleted';
           } 
            
	}

}

?>