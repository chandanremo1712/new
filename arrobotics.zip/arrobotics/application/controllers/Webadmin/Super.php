<?php
defined('BASEPATH') OR exit('No Direct Script access allowed');

class Super extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Webadmin/Admin_model');
                $this->load->helper("file");
                
                $this->load->library(array('form_validation')); // load form lidation libaray & session library
                $this->load->helper(array('url','html','form'));  // load url,html,form helpers optional

                
	}
	
	
        public function delete_faq()
	{
            
           $id = $this->input->get('id', TRUE);
           
           $faq = $this->Admin_model->delete_single('nsn_faq', $id);
           if($faq){
               
                echo 'deleted';
           } 
            
	}
        
        public function change_status()
        {
           $tbl = $this->uri->segment(4);
            
           $id = $this->input->get('id', TRUE);
           $val = $this->input->get('val');
            $field_data = array(
                       'Status' => $val
                       );
            $result = $this->Admin_model->edit_details($tbl,$field_data,$id);
            
            if($result)
            {
                
                echo 'Status Changed';
            }
        }
        
        public function change_status1()
        {
            $tbl = $this->uri->segment(4);
            
            $id = $this->input->get('id', TRUE);
            $val = $this->input->get('val');
            $field_data = array(
                       'Status' => $val
                       );
            $result = $this->Admin_model->eidt_details1($tbl,$field_data,$id);
            if($result)
            {
                echo 'Status Changed';
            }
        }
        
             public function change_status_new()
        {
            $tbl = $this->uri->segment(4);
            
            $id = $this->input->get('id', TRUE);
            $val = $this->input->get('val');
            $field_data = array(
                       'deals' => $val
                       );
            $result = $this->Admin_model->eidt_details1($tbl,$field_data,$id);
            if($result)
            {
                echo 'Status Changed';
            }
        }
//--------------------------------------------------------------------------------------------
	
     public function change_password()
     {
         $old_pass = $this->input->post('old_pass');
         $password = $this->input->post('new_pass');
        
         $page = '';
         $data['page'] = $page;
         if($this->input->post('submit') == 'Submit')
         {
            $this->form_validation->set_rules('old_pass', 'Current Password', 'required');
            $this->form_validation->set_rules('new_pass', 'New Password', 'required');
            $this->form_validation->set_rules('conf_pass', 'Confirm Password', 'required');
            if ($this->form_validation->run() == TRUE)
            {
                $where = "password = '".base64_encode($old_pass)."' AND id='1'";
                $result = $this->Admin_model->fetch_row('admin',$where);
                if($result)
                {
                    $field_data = array(
                        'password' => base64_encode($password)
                      );
                    $edit = $this->Admin_model->eidt_details('admin', $field_data, 1);
                    $data['succ'] = "Password Change Successfully";

                }else
                {
                    $data['error'] = "Please Enter Correct Old Password";
                }
            }
         }

        $this->load->view('Webadmin/header');
        $this->load->view('Webadmin/leftbar',$data);
        $this->load->view('Webadmin/change_password',$data);
        $this->load->view('Webadmin/footer');
     }
     
     
       /**********************contact details****************************/
     public function ContactDetails()
     {
         if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
             $page_type = 'settings';
              $page = 'contact';
            $data['page'] = $page;
             $data['page_type'] = $page_type;
            if($this->input->post('submit') == 'Submit')
            {
              
                $id = $this->input->post('id');
                  $address = $this->input->post('address');
                
         
                $phone = $this->input->post('phone');
                $email= $this->input->post('email');
                $fax= $this->input->post('fax');
                $map=$this->input->post('map');
               $website=$this->input->post('website');
             
               
                $field_data = array(
                        'address' => $address,
                        'phone' => $phone,
                        'fax' => $fax,
                        'email' => $email,
                        'website'=>$website,
                        'map'=>$map
                        
                        
                        );
                $result = $this->Admin_model->eidt_details('nsn_contact',$field_data,$id);
                if($result){
                    $succ = "Data Updated Successfully";
                    $data['succ']=$succ;
                    $cms = $this->Admin_model->fetch_single('nsn_contact',$id);
                    $data['cms'] = $cms;
                    //var_dump($data);exit();
                }
           }else{
            
                $id ='1';
                $cms = $this->Admin_model->fetch_single('nsn_contact',$id);
                $data['cms'] = $cms;
            
           }
            
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/Contact',$data);
            $this->load->view('Webadmin/footer');
     }
     
     /****************************end contact details**************************/
	/**********************social details****************************/
      function SocialDetails()
     {
         if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
             $page_type = 'settings';
              $page = 'social';
            $data['page'] = $page;
             $data['page_type'] = $page_type;
            if($this->input->post('submit') == 'Submit')
            {
              
                $id = $this->input->post('id');
                
                
         
                $facebook = $this->input->post('facebook');
                $twitter= $this->input->post('twitter');
                $google= $this->input->post('google');
                $youtube=$this->input->post('youtube');
               $instagram=$this->input->post('instagram');
               $linkedin=$this->input->post('linkedin');
             
               
                $field_data = array(
                        'facebook' => $facebook,
                        'twitter' => $twitter,
                        'google_plus' => $google,
                        'youtube' => $youtube,
                        'instagram' =>$instagram,
                        'linkedin' =>$linkedin
                       
                        
                        
                        );
                $result = $this->Admin_model->eidt_details('nsn_social',$field_data,$id);
                if($result){
                    $succ = "Data Updated Successfully";
                    $data['succ']=$succ;
                    $cms = $this->Admin_model->fetch_single('nsn_social',$id);
                    $data['cms'] = $cms;
                    //var_dump($data);exit();
                }
           }else{
            
                $id ='1';
                $cms = $this->Admin_model->fetch_single('nsn_social',$id);
                $data['cms'] = $cms;
            
           }
            
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/Social',$data);
            $this->load->view('Webadmin/footer');
     }
     
     /****************************end social details**************************/
	
}


?>