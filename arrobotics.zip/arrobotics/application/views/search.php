<form method="post" action="<?=base_url()?>productsearch">

<!--<form method="post" action="#">-->

<div class="col-lg-6 pull-right" style="margin-bottom: 15px;">
<div class="input-group custom-search-form">
<input type="text" name="title" placeholder="Search For products" class="form-control">
<span class="input-group-btn">
<button class="btn btn-success" type="submit" name="submit">
<i class="fa fa-search"></i>
</button>
</span>
</div><!-- /input-group -->
</div>
</form>