<?php
defined('BASEPATH') OR exit('No Direct Script access allowed');

class Tags extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Webadmin/Banner_model');
                $this->load->model('Webadmin/Admin_model');
                $this->load->helper("file");

                
	}
	
	public function index()
        {
            if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
            $page = 'tag';
            $data['page'] = $page;
            
            $fetch = $this->Admin_model->fetch_all_join("select * from tags order by Id desc");
            $data['fetch'] = $fetch;
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/tag');
            $this->load->view('Webadmin/footer');
        }
	
        public function add_banner()
        {
            error_reporting(0);
            if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
             $page = 'banner';
            $data['page'] = $page;
            
            $image = "";
            if($this->input->post('submit') == 'Submit')
            {
                $title = $this->input->post('title');
                $subtitle = $this->input->post('Subtitle');
                $description = $this->input->post('desc');
                
                //$old_image = $this->input->post('old_img');
                $config['upload_path']   = './Banner/'; 
                 $config['allowed_types'] = 'gif|jpg|png|jpeg'; 
                $config['max_size']      = 2048000; 
                $config['max_width']     = 3000000; 
                $config['max_height']    = 2000000;  
                $config['file_name']=  uniqid();
                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('file')) {
                   $error = array('error' => $this->upload->display_errors()); 

                }

                else { 
                   $file_data = $this->upload->data(); 
                   $image = $file_data['file_name'];
                     


                } 
                
                $field_data = array(
                        'BannerTitle' => $title,
                         //'Subtitle' => $subtitle,
                        //'BannerText' => $description,
                        'BannerImage' => $image,
                        'Status' => 'Yes'
                        );
                $result = $this->Banner_model->add_details($field_data);
                if($result){
                    $succ = "Data Added Successfully";
                    $data['succ']=$succ;
                }
           }
            //$cms = $this->Cms_model->fetch_all();
            //$data['cms'] = $cms;
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/banner_details');
            $this->load->view('Webadmin/footer');
        }
        
        public function edit_tag()
        {   if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
             $page = 'tag';
            $data['page'] = $page;
            
            if($this->input->post('submit') == 'Submit')
            {
                
                $id = $this->input->post('id');
                $page = $this->input->post('page');
                $description = $this->input->post('desc');
                $keyword = $this->input->post('keyword');
             
                
              
               
                $field_data = array(
                        'page_name' => $page,
                         'meta_desc' => $description,
                        'meta_keyword' => $keyword
                        );
                
                $result = $this->Admin_model->eidt_details('tags',$field_data,$id);
                if($result){
                    $succ = "Data Updated Successfully";
                    $data['succ']=$succ;
                    $fetch = $this->Admin_model->fetch_single('tags',$id);
                    $data['fetch'] = $fetch;
                    
                }
           }else{
            
                $id = $this->uri->segment(4);
                $fetch = $this->Admin_model->fetch_single('tags',$id);
                $data['fetch'] = $fetch;
            
           }
            
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/tag_details',$data);
            $this->load->view('Webadmin/footer');
        }
	//Start About-------------------------------------------------------------------------------------------
	function view_banner()
	{
            if(!$this->session->userdata('is_logged_in'))
            {
            redirect('Webadmin/Login');
            }
            $page = 'banner';
            $data['page'] = $page;
            
            $id = $this->uri->segment(4);
            $fetch = $this->Banner_model->fetch_single($id);
            $data['fetch'] = $fetch;
            
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/banner_details',$data);
            $this->load->view('Webadmin/footer');
	}
        
        public function delete_banner()
	{
            
           $id = $this->input->get('id', TRUE);
            $fetch = $this->Banner_model->fetch_single($id);
                //print_r( $fetch);exit();
                unlink('./Banner/'.$fetch->BannerImage);
           $banner = $this->Banner_model->delete_single($id);
           if($banner){
               
                echo 'deleted';
           } 
            
	}
//End About---------------------------------------------------------------------------------------------
	

	
}


?>