

<!-- Start main-content -->
<div class="main-content bg-lighter">
<!-- Section: inner-header -->
<section class="inner-header divider parallax layer-overlay overlay-dark-5" data-bg-img="<?=base_url()?>images/bg/bg6.jpg">
<div class="container pt-70 pb-20">
<!-- Section Content -->
<div class="section-content">
<div class="row">
<div class="col-md-12">
<h2 class="title text-white text-center">Login</h2>
<ol class="breadcrumb text-left text-black mt-10">
<li><a href="#">Home</a></li>
<!--<li><a href="#">Pages</a></li>-->
<li class="active text-gray-silver">User Login</li>
</ol>
</div>
</div>
</div>
</div>
</section>



<!-- Section Contact -->
<section id="contact" class="divider bg-lighter">
<div class="container-fluid pt-0 pb-0">
<div class="section-content">
<div class="row">
    <div class="col-sm-12 col-md-3"></div>
<div class="col-sm-12 col-md-6">
<div class="contact-wrapper">
    <span style="color:red;font-size:15px;" id="msg"> <i><?php echo $this->session->flashdata('success_msg'); ?></i></span>
<h3 class="line-bottom mt-0 mb-20">Login To Your Account</h3>
<!--<p class="mb-30">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>-->

<!-- Contact Form -->
<form id="contact_form" name="contact_form" class="form-transparent" action="<?=base_url()?>login" method="post">

<div class="row">
<div class="col-sm-12">
<div class="form-group">
<label for="form_name">Email <small>*</small></label>
<input name="email" class="form-control"  type="text" value="<?= set_value('email')?>" placeholder="Enter Email" required="">
<small><?php echo strip_tags(form_error('email')); ?></small>
</div>
</div>

</div>
    
 <div class="row">
<div class="col-sm-12">
<div class="form-group">
<label for="form_name">Password <small>*</small></label>
<input name="password" class="form-control"  type="password"  placeholder="Enter Password" required="">
<small><?php echo strip_tags(form_error('password')); ?></small>
</div>
</div>

</div>   
    
    
    <!--<a href="<?=base_url()?>forgetpassword" class="btn btn-link pull-right">Forget Password?</a>-->
    
    
<div class="form-group">
<input name="form_botcheck" class="form-control" type="hidden" value="" />
<button type="submit" name="submit" value="submit" class="btn btn-dark btn-theme-colored btn-flat mr-5">Login</button>
<button type="reset" class="btn btn-default btn-flat btn-theme-colored">Reset</button>
</div>


</div>


</form>
<!-- Contact Form Validation-->

</div>
</div>

</div>
</div>
</div>
</section>
</div>
<!-- end main-content -->
