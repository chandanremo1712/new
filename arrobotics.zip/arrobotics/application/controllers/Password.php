<?php

error_reporting(0);
defined('BASEPATH') OR exit('No direct script access allowed');

class Password extends CI_Controller {

    function __construct() {
        parent::__construct();
       
        $this->load->model('Webadmin/Admin_model');
        $this->load->library('form_validation');
        $this->load->helper(array('form', 'url'));
        $this->load->library('email');
        $this->load->library('pagination');
                //$this->load->library('Twitteroauth'); // load twitter library
    }
    
    
    
    function newpassword() {

$data['page'] = 'forgetpassword';

//$this->form_validation->set_rules('email', 'email', 'required|trim|valid_email');
$this->form_validation->set_rules('email_id', 'email', 'required|trim|valid_email');



if ($this->form_validation->run() == False) {
$this->session->set_flashdata('success_msg', 'Email can not be blank');

} else {

// $this->form_validation->set_rules('email', 'email', 'required|trim|valid_email|callback_email_check');
$email = $this->input->post('email_id');
$pass = rand(100000, 999999);
$password = base64_encode($pass);

$field_data = array('password' => $password);

$where = "email='$email'";
$fetch = $this->Admin_model->fetch_row('user', $where);

$result = $this->Admin_model->eidt_single_row('user', $field_data, $where);
//echo $this->db->last_query();exit();
//$result=$this->Signin_model->check_mentor_forgot($this->input->post('username'),$data);
if ($result == TRUE) {
    
 
$htmlContent = "<table align='center' style='width:650px; text-align:center; background:#f7f7f7;'>
<tbody>
<tr style='height:50px;background-color:#f2f2f2;'><td valign='middle' style='color:white;'><img src='" . base_url() . "images/logo.png' alt='Arrobotics' title='Arrobotics'  style='width:210px;height:130px' /></td></tr>
<tr>
<td valign='top' align='center' colspan='2'>
<table align='center' style='height:380px; color:#000; width:600px;'>
<tbody>
<tr>
<td style='width:8px;'>&nbsp;</td> 
<td align='center' style='font-size:28px;border-top:1px dashed #ccc;' colspan='3'>Hello, ". $name ."</td>
</tr>
<tr>
<td valign='top' align='center' colspan='2'>

<p>New Password From Arrobotics</p><br><br>

<table align='center' style='color:#000; width:600px;'>
<tbody>


<tr align='center'><td><strong>EMAIL</strong>&nbsp;:&nbsp;$email</td></tr>

<tr align='center'><td><strong>PASSWORD</strong>&nbsp;:&nbsp;$pass</td></tr>
    
</tbody>
</table>     


<a></a>
<br>
Sincerely,<br>
ArRobotics<br><br>
<strong>Email:</strong>support@arrobotics.in<br><br>

This is an automated response, please DO NOT reply.
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>";

//echo $htmlContent;
//exit();

$config['mailtype'] = 'html';

$this->email->initialize($config);

$this->email->to($email);
$this->email->from('support@arrobotics.in', 'ArRobotics');
$this->email->subject('New Password For ArRobotics');
$this->email->message($htmlContent);
$this->email->send();



$this->session->set_flashdata('success_msg', 'Password Changed! Please Check Your Email For New Password');
} else {

$this->session->set_flashdata('success_msg', 'Invalid Email');
}
}

$this->load->view('header',$data);
$this->load->view('forgetpassword',$data);
$this->load->view('footer',$data);
}


public function contact()
{

$page='contact';
$data['page']=$page;

if ($this->input->post('submit') == 'submit') {

$this->form_validation->set_rules('name', 'name', 'required');
$this->form_validation->set_rules('email', 'email', 'required');
$this->form_validation->set_rules('mobile', 'mobile ', 'required');
$this->form_validation->set_rules('subject', 'subject', 'required');
$this->form_validation->set_rules('message', 'message ', 'required');

if ($this->form_validation->run() == TRUE) {

$name = $this->input->post('name');
$email = $this->input->post('email');

$phone = $this->input->post('mobile');
$subject = $this->input->post('subject');
$message =$this->input->post('message');



   
$htmlContent = "<table align='center' style='width:650px; text-align:center; background:#f7f7f7;'>
<tbody>
<tr style='height:50px;background-color:#f2f2f2;'><td valign='middle' style='color:white;'><img src='" . base_url() . "assets/logo.png' alt='Ersa' title='Greencomputer'  style='width:210px;height:130px' /></td></tr>
<tr>
<td valign='top' align='center' colspan='2'>
<table align='center' style='height:380px; color:#000; width:600px;'>
<tbody>
<tr>
<td style='width:8px;'>&nbsp;</td> 
<td align='center' style='font-size:28px;border-top:1px dashed #ccc;' colspan='3'>Hello, ". $name ."</td>
</tr>
<tr>
<td valign='top' align='center' colspan='2'>

<p>Contacted User Details From Iowa African Market</p><br><br>

<table align='center' style='color:#000; width:600px;'>
<tbody>

<tr align='center'><td><strong>NAME</strong>&nbsp;:&nbsp;$name</td></tr>
<tr align='center'><td><strong>EMAIL</strong>&nbsp;:&nbsp;$email</td></tr>
<tr align='center'><td><strong>PHONE</strong>&nbsp;:&nbsp;$phone</td></tr>
<tr align='center'><td><strong>SUBJECT</strong>&nbsp;:&nbsp;$subject</td></tr>
 <tr align='center'><td><strong>MESSAGE</strong>&nbsp;:&nbsp;$message</td></tr>   
</tbody>
</table>     


<a></a>
<br>
Sincerely,<br>
Iowa African Market<br><br>
<strong>Email:</strong>demo@Iowaafricanmarket.com<br><br>

This is an automated response, please DO NOT reply.
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>";

//echo $htmlContent;
//exit();

$config['mailtype'] = 'html';

$this->email->initialize($config);
$this->email->to($email);
$this->email->from('demo@Iowaafricanmarket.com', 'Iowa African Market');
$this->email->subject('New Password For Iowa African Market');
$this->email->message($htmlContent);
$this->email->send();  


$data = array(
'name' => $name,
'email' => $email,
'subject' => $subject,
'phone' => $phone,
'message' =>$message
);   

$result= $this->Admin_model->add_details('contact',$data);
if($result)
{
$this->session->set_flashdata('success_msg', 'Thankyou For Contacting US....');   
}


redirect(base_url().'contact');

}

else {


//$this->load->view('header', $data);
//   $this->load->view('contact', $data);
//  $this->load->view('footer', $data);
}
}

$this->load->view('header', $data);
$this->load->view('contact', $data);
$this->load->view('footer', $data);

}

    
}
    
    ?>