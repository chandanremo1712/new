 <div class="vd_content-wrapper">
      <div class="vd_container">
        <div class="vd_content clearfix">
          <div class="vd_head-section clearfix">
            <div class="vd_panel-header">
              <ul class="breadcrumb">
                <li><a href="<?php echo base_url()?>Webadmin/Dashboard">Home</a> </li>
                <li><a href="<?php echo base_url()?>Webadmin/Tutor/Event">Event List</a> </li>
                <li class="active"><?php if($this->uri->segment(3) == "edit_event_details"){echo 'Edit';}elseif($this->uri->segment(3) == "add_details"){echo 'Add';}elseif($this->uri->segment(3)=="view_details"){echo 'View';}?> Tutor Details </li>
              </ul>
              <div class="vd_panel-menu hidden-sm hidden-xs" data-intro="<strong>Expand Control</strong><br/>To expand content page horizontally, vertically, or Both. If you just need one button just simply remove the other button code." data-step=5  data-position="left">
    <div data-action="remove-navbar" data-original-title="Remove Navigation Bar Toggle" data-toggle="tooltip" data-placement="bottom" class="remove-navbar-button menu"> <i class="fa fa-arrows-h"></i> </div>
      <div data-action="remove-header" data-original-title="Remove Top Menu Toggle" data-toggle="tooltip" data-placement="bottom" class="remove-header-button menu"> <i class="fa fa-arrows-v"></i> </div>
      <div data-action="fullscreen" data-original-title="Remove Navigation Bar and Top Menu Toggle" data-toggle="tooltip" data-placement="bottom" class="fullscreen-button menu"> <i class="glyphicon glyphicon-fullscreen"></i> </div>
      
</div>
            </div>
          </div>
          <div class="vd_title-section clearfix">
            <div class="vd_panel-header">
              <h1><?php if($this->uri->segment(3) == "edit_event_details"){echo 'Edit';}elseif($this->uri->segment(3) == "add_details"){echo 'Add';}elseif($this->uri->segment(3)=="view_details"){echo 'View';}?> Tutor </h1>
              </div>
          </div>
        <?php if($this->uri->segment(3) == 'edit_event_details'){?>    
          <div class="vd_content-section clearfix">
            <div class="panel widget light-widget">
              <div class="panel-heading no-title"> </div>
              <div class="panel-body">
               <?php if(isset($succ)){?>
                  <div class="alert alert-success alert-dismissable">
                        <button aria-hidden="true" data-dismiss="alert" class="close" type="button"><i class="icon-cross"></i></button>
                        <i class="fa fa-check-circle append-icon"></i><strong>Success!</strong> <?php echo $succ;?> 
                  </div>
               <?php }?>
              <?php if(isset($error)){?>
                  <div class="alert alert-danger alert-dismissable alert-condensed">
                        <button aria-hidden="true" data-dismiss="alert" class="close" type="button"><i class="icon-cross"></i></button>
                         <?php echo $error['error'];?>
                  </div>
              <?php }?>
                <h2 class="mgbt-xs-20">Event Details</h2>
            
                <form class="form-horizontal"  action="<?php echo base_url()?>Webadmin/Tutor/edit_event_details" role="form1" method="post" id="register-form1" enctype="multipart/form-data">
                    <input type="hidden" name="id" value="<?php echo $fetch->id;?>"> 
                  <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Event Title<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <input type="text" placeholder="Event Title" class="width-60 required" name="event_title" value="<?php echo $fetch->event_title;?>" id="event_title" required >
                      </div>
                    </div>
                  </div>
                     
    
                    <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Event Description<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <textarea name="event_description" placeholder="Event Description" data-rel="ckeditor" rows="3" ><?php echo stripslashes($fetch->event_description);?></textarea>
                      </div>
                    </div>
                  </div>
                    
                    
                     <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">From Time<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <input type="text" placeholder="From Time" class="width-60 required" name="from_time" id="from_time" required value="<?php echo $fetch->from_time;?>" >
                      </div>
                    </div>
                  </div>
                    
                     <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">To Time<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <input type="text" placeholder="To Time" class="width-60 required" name="to_time" id="to_time" required value="<?php echo $fetch->to_time;?>" >
                      </div>
                    </div>
                  </div>
                    
                    
                     <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Event Date<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <input type="date" placeholder="date" class="width-60 required" name="date" id="date" required value="<?php echo $fetch->date;?>" >
                      </div>
                    </div>
                  </div>
                    
                    
                    
                   
                  
                  <div id="vd_login-error" class="alert alert-danger hidden"><i class="fa fa-exclamation-circle fa-fw"></i> Please fill the necessary field </div>
                  <div class="form-group">
                    <div class="col-sm-2"></div>
                    <div class="col-md-6 mgbt-xs-10 mgtp-20">
                     
                      <div class="mgtp-10">
                          <input class="btn vd_bg-green vd_white" type="submit" id="submit-register" name="submit" value="Submit">
                      </div>
                    </div>
                    <div class="col-md-12 mgbt-xs-5"> </div>
                  </div>
                </form>
              </div>
            </div>
            
            
          </div>
        <?php }elseif($this->uri->segment(3) == 'add_details'){?>
            <div class="vd_content-section clearfix">
            <div class="panel widget light-widget">
              <div class="panel-heading no-title"> </div>
              <div class="panel-body">
               <?php if(isset($succ)){?>
                  <div class="alert alert-success alert-dismissable">
                        <button aria-hidden="true" data-dismiss="alert" class="close" type="button"><i class="icon-cross"></i></button>
                        <i class="fa fa-check-circle append-icon"></i><strong>Success!</strong> <?php echo $succ;?> 
                  </div>
               <?php }?>
              <?php if(isset($error)){?>
                  <div class="alert alert-danger alert-dismissable alert-condensed">
                        <button aria-hidden="true" data-dismiss="alert" class="close" type="button"><i class="icon-cross"></i></button>
                         <?php echo $error['error'];?>
                  </div>
              <?php }?>
                <h2 class="mgbt-xs-20">Employer Details</h2>
            
                <form class="form-horizontal"  action="<?php echo base_url()?>Webadmin/Tutor/add_details" role="form1" method="post" id="register-form1" enctype="multipart/form-data">
                    <input type="hidden" name="id" value="<?php echo $fetch->id;?>"> 
                  <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Event Title<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <input type="text" placeholder="Event Title" class="width-60 required" name="event_title" value="<?php echo $fetch->event_title;?>" id="event_title" required >
                      </div>
                    </div>
                  </div>
                     
    
                    <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Event Description<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <textarea name="event_description" placeholder="Event Description" data-rel="ckeditor" rows="3" ><?php echo stripslashes($fetch->event_description);?></textarea>
                      </div>
                    </div>
                  </div>
                    
                    
                     <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">From Time<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <input type="text" placeholder="From Time" class="width-60 required" name="from_time" id="from_time" required value="<?php echo $fetch->from_time;?>" >
                      </div>
                    </div>
                  </div>
                    
                     <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">To Time<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <input type="text" placeholder="To Time" class="width-60 required" name="to_time" id="to_time" required value="<?php echo $fetch->to_time;?>" >
                      </div>
                    </div>
                  </div>
                    
                    
                     <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Event Date<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <input type="date" placeholder="date" class="width-60 required" name="date" id="date" required value="<?php echo $fetch->date;?>" >
                      </div>
                    </div>
                  </div>
                    
                    
                    
                   
                  
                  <div id="vd_login-error" class="alert alert-danger hidden"><i class="fa fa-exclamation-circle fa-fw"></i> Please fill the necessary field </div>
                  <div class="form-group">
                    <div class="col-sm-2"></div>
                    <div class="col-md-6 mgbt-xs-10 mgtp-20">
                     
                      <div class="mgtp-10">
                          <input class="btn vd_bg-green vd_white" type="submit" id="submit-register" name="submit" value="Submit">
                      </div>
                    </div>
                    <div class="col-md-12 mgbt-xs-5"> </div>
                  </div>
                </form>
              </div>
            </div>
            
            
          </div>
         
        <?php }else{?>
         <div class="vd_content-section clearfix">
            <div class="panel widget light-widget">
              <div class="panel-heading no-title"> </div>
              <div class="panel-body">
               
                <h2 class="mgbt-xs-20">Event Details</h2>
            
                <form class="form-horizontal"  action="" role="form1" method="post" id="register-form1" enctype="multipart/form-data">
                    <input type="hidden" name="id" value="<?php echo $fetch->id;?>"> 
                  
                   
                   <div class="col-md-10">
                       <div class="form-group">
                            <div class="col-md-12">
                              <label class="control-label  col-sm-3">Event Name <span class="vd_red"></span></label>
                              <div id="first-name-input-wrapper"  class="controls col-sm-9">
                                  <?php echo $fetch->event_title;?>
                              </div>
                            </div>
                           
                           <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-3">Event Details<span class="vd_red"></span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-9">
                       <?php echo $fetch->event_description;?>
                      </div>
                    </div>
                  </div> 
             
                           
<!--                             <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-3">From Time<span class="vd_red"></span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-9">
                       <?php echo $fetch->from_time;?>
                      </div>
                    </div>
                  </div> -->
<!--                             <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-3">To Time<span class="vd_red"></span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-9">
                       <?php echo $fetch->to_time;?>
                      </div>
                    </div>
                  </div> -->
                    
                    <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-3">Event Date<span class="vd_red"></span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-9">
                        <?php echo $fetch->date;?>
                      </div>
                    </div>
                  </div>
                     
        
                        </div>
                  </div> 
                  
                  
                </form>
              </div>
            </div>
            
            
          </div>
            
        <?php }?>
        </div>
       
      </div>
      <!-- .vd_container --> 
    </div>
    <!-- .vd_content-wrapper --> 
    
    <!-- Middle Content End --> 
    
  </div>
  <!-- .container --> 
</div>
<!-- .content -->


<script>
function deleteloc(id)
{
     cnf = confirm("Are you confirm to delete?");
        if(cnf)
		{
                  
                    $('.portlet .tools a.reload').click();
                    $.ajax({
                        type:"GET",
                        url:"<?php echo base_url();?>Webadmin/Employer/DeleteLoc",
                        data:"id="+id,
                        success:function(data)
                        {
                                                      
                           if(data == "deleted")
                            {
                                $('#loc'+id).css('display', 'none');
                            }
                        }
                    });
			
		}
}


</script>