 <div class="vd_content-wrapper">
      <div class="vd_container">
        <div class="vd_content clearfix">
          <div class="vd_head-section clearfix">
            <div class="vd_panel-header">
              <ul class="breadcrumb">
                <li><a href="<?php echo base_url()?>Webadmin/Dashboard">Home</a> </li>
                <li><a href="#">Applied User List</a> </li>
                <li class="active"><?php if($this->uri->segment(3) == "edit_details"){echo 'Edit';}elseif($this->uri->segment(3) == "add_details"){echo 'Add';}elseif($this->uri->segment(3)=="view_details"){echo 'View';}?> User Details </li>
              </ul>
              <div class="vd_panel-menu hidden-sm hidden-xs" data-intro="<strong>Expand Control</strong><br/>To expand content page horizontally, vertically, or Both. If you just need one button just simply remove the other button code." data-step=5  data-position="left">
    <div data-action="remove-navbar" data-original-title="Remove Navigation Bar Toggle" data-toggle="tooltip" data-placement="bottom" class="remove-navbar-button menu"> <i class="fa fa-arrows-h"></i> </div>
      <div data-action="remove-header" data-original-title="Remove Top Menu Toggle" data-toggle="tooltip" data-placement="bottom" class="remove-header-button menu"> <i class="fa fa-arrows-v"></i> </div>
      <div data-action="fullscreen" data-original-title="Remove Navigation Bar and Top Menu Toggle" data-toggle="tooltip" data-placement="bottom" class="fullscreen-button menu"> <i class="glyphicon glyphicon-fullscreen"></i> </div>
      
</div>
            </div>
          </div>
          <div class="vd_title-section clearfix">
            <div class="vd_panel-header">
              <h1><?php if($this->uri->segment(3) == "edit_details"){echo 'Edit';}elseif($this->uri->segment(3) == "add_details"){echo 'Add';}elseif($this->uri->segment(3)=="view_details"){echo 'View';}?> Applied User </h1>
              </div>
          </div>
        <?php if($this->uri->segment(3) == 'edit_details'){?>    
        
        <?php }elseif($this->uri->segment(3) == 'add_details'){?>
          
         
        <?php }else{?>
         <div class="vd_content-section clearfix">
            <div class="panel widget light-widget">
              <div class="panel-heading no-title"> </div>
              <div class="panel-body">
               
                <h2 class="mgbt-xs-20">Applied User Details</h2>
            
                <form class="form-horizontal"  action="" role="form1" method="post" id="register-form1" enctype="multipart/form-data">
<!--                    <input type="hidden" name="id" value="<?php echo $fetch->id;?>"> -->
                  

                   <div class="col-md-10">
                       <div class="form-group">
                            <div class="col-md-12">
                              <label class="control-label  col-sm-3"> Name <span class="vd_red"></span></label>
                              <div id="first-name-input-wrapper"  class="controls col-sm-9">
                                  <?php echo $fetch->name;?>
                              </div>
                            </div>
                           
                           <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-3">Email<span class="vd_red"></span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-9">
                       <?php echo $fetch->email;?>
                      </div>
                    </div>
                  </div> 
                           
                                       <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-3">Phone<span class="vd_red"></span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-9">
                    <?php echo $fetch->phone;?>
                      </div>
                    </div>
                  </div> 
                           
                             <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-3">Position<span class="vd_red"></span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-9">
                       <?php echo $fetch->position;?>
                      </div>
                    </div>
                  </div> 
                 
                    
                    <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-3">Message<span class="vd_red"></span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-9">
                        <?php echo $fetch->message;?>
                      </div>
                    </div>
                  </div>
                           
                                               <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-3">Download Cv<span class="vd_red"></span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-9">
                       <a href="<?=base_url()?>CV/<?=$fetch->cv?>" download=""><img src="<?=base_url()?>images/cv.png" alt="cv" style="height:40px;width:40px;"></a>
                      </div>
                    </div>
                  </div>
                           
                           
                           
      
                        </div>
                  </div> 
                  
                  
                </form>
              </div>
            </div>
            
            
          </div>
            
        <?php }?>
        </div>
       
      </div>
      <!-- .vd_container --> 
    </div>
    <!-- .vd_content-wrapper --> 
    
    <!-- Middle Content End --> 
    
  </div>
  <!-- .container --> 
</div>
<!-- .content -->


<script>
function deleteloc(id)
{
     cnf = confirm("Are you confirm to delete?");
        if(cnf)
		{
                  
                    $('.portlet .tools a.reload').click();
                    $.ajax({
                        type:"GET",
                        url:"<?php echo base_url();?>Webadmin/Employer/DeleteLoc",
                        data:"id="+id,
                        success:function(data)
                        {
                                                      
                           if(data == "deleted")
                            {
                                $('#loc'+id).css('display', 'none');
                            }
                        }
                    });
			
		}
}


</script>