<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	
	function __construct() { 
            parent::__construct(); 
            $this->load->helper('url');  
            $this->load->helper('form'); 
            $this->load->database(); 
            $this->load->model('Webadmin/Admin_model');
            $this->load->library('form_validation');
            
		 
        } 
	
	
	public function index()
	{
            if(!$this->session->userdata('is_logged_in'))
            {
                    $this->load->view('Webadmin/login',@$data);
            }else{
                $page = "home";
                $data['page']=$page;
                $data['Admin_model']=  $this->Admin_model;

               $this->load->view('Webadmin/header');
                $this->load->view('Webadmin/leftbar',$data);
               $this->load->view('Webadmin/dashboard');
           }
		
	}
	
	
	
	
	
	
	function __encrypt_password($password) {
        return base64_encode($password);
    }
	
	function Dashboard()
	{
            $page = "home";
            $data['page']=$page;
		if(!$this->session->userdata('is_logged_in'))
		{
		redirect('Webadmin/Login');
		}
		else
		{
                        $data['Admin_model']=  $this->Admin_model;
                    $this->load->view('Webadmin/header');
                    $this->load->view('Webadmin/leftbar',$data);
                    $this->load->view('Webadmin/dashboard');
                    //$this->load->view('Webadmin/footer');
		}
	}
	
	
//Login-------------------------------------------------------------------------------------------------
	public function login_process()
	{
		
           
		$this->form_validation->set_rules('username', 'Username', 'trim|required');
		$this->form_validation->set_rules('password', 'Password', 'trim|required');
                
		if($this->form_validation->run() == TRUE)
		{
			
		$username = $this->input->post('username');
		$password = $this->__encrypt_password($this->input->post('password'));

		$result = $this->Admin_model->login($username, $password);
		
		if($result == TRUE){
		
			$data = array(
				'username' => $username,
				'is_logged_in' => true
			);
			$this->session->set_userdata($data);
			redirect('Webadmin/Login/Dashboard');
		}
		else // incorrect username or password
		{
			//$data = array('error_message' => 'Invalid Username or Password');
                        
                                  $this->session->set_flashdata('success_msg', 'Invalid Username or Password');
			redirect('Webadmin/Login');
                        
		}
		}
		else
		{
                    //$data = array('error_message' => 'Invalid Username or Password');
                     //$this->session->set_flashdata('success_msg', 'Invalid Username or Password');
			//redirect('Webadmin/Login');
                 
                    $this->load->view('Webadmin/login');
          
		}
	}
	
	
	
	//	Start Change Password-----------------------------------------------------------------------------
	function ChangePassword()
	{
		if(!$this->session->userdata('is_logged_in'))
		{
			redirect('Webadmin/Login');
		}
		$this->load->model('Admin_model');
		$this->form_validation->set_rules('current_password','Current Password','trim|required');
		$this->form_validation->set_rules('new_password','New Password','trim|required');
		$this->form_validation->set_rules('retype_password','Re-Enter Password','trim|required');
		$data[]="";
		if($this->form_validation->run() == TRUE)
		{
			$fetch=$this->Admin_model->fetch_admin();
			$current_pass=base64_decode($fetch->password);
			$error=0;
			if($current_pass!=$this->input->post('current_password'))
			{
				$data['error_currentpass']="Does Not Match Current Password";
				$error=1;
			}
			if($this->input->post('new_password')!=$this->input->post('retype_password'))
			{
				$data['error_confirmpass']="Does Not Match Re-Enter Password";
				$error=1;
			}
			
			if($error!=1)
			{
				$data=array('password'=>$this->__encrypt_password($this->input->post('new_password')));
				$this->Admin_model->upadate_password($data);
				$data['success_msg']="Password Successfully Updated";
			}
		
		}
		$this->load->view('Webadmin/Change-password',$data);
	}

// 	End Change Password--------------------------------------------------------------------------------
	
	
	function logout()
	{
		$this->session->unset_userdata('is_logged_in');
		$this->session->unset_userdata('username');
		redirect('Webadmin/Login');
	}
}
?>