 <div class="vd_content-wrapper">
      <div class="vd_container">
        <div class="vd_content clearfix">
          <div class="vd_head-section clearfix">
            <div class="vd_panel-header">
              <ul class="breadcrumb">
                <li><a href="index.html">Home</a> </li>
                <li><a href="forms-elements.html">Forms</a> </li>
                <li class="active">Form Validation </li>
              </ul>
              <div class="vd_panel-menu hidden-sm hidden-xs" data-intro="<strong>Expand Control</strong><br/>To expand content page horizontally, vertically, or Both. If you just need one button just simply remove the other button code." data-step=5  data-position="left">
    <div data-action="remove-navbar" data-original-title="Remove Navigation Bar Toggle" data-toggle="tooltip" data-placement="bottom" class="remove-navbar-button menu"> <i class="fa fa-arrows-h"></i> </div>
      <div data-action="remove-header" data-original-title="Remove Top Menu Toggle" data-toggle="tooltip" data-placement="bottom" class="remove-header-button menu"> <i class="fa fa-arrows-v"></i> </div>
      <div data-action="fullscreen" data-original-title="Remove Navigation Bar and Top Menu Toggle" data-toggle="tooltip" data-placement="bottom" class="fullscreen-button menu"> <i class="glyphicon glyphicon-fullscreen"></i> </div>
      
</div>
            </div>
          </div>
          <div class="vd_title-section clearfix">
            <div class="vd_panel-header">
              <h1>Form Validation </h1>
              <small class="subtitle">Form validation using jQuery Validation: <a href="http://jqueryvalidation.org/">http://jqueryvalidation.org</a>/</small> </div>
          </div>
          <div class="vd_content-section clearfix">
            <div class="panel widget light-widget">
              <div class="panel-heading no-title"> </div>
              <div class="panel-body">
                <h2 class="mgbt-xs-20">CMS Details</h2>
                <form class="form-horizontal"  action="#" role="form" id="register-form">
                    
                  <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Page Title <span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-6">
                        <input type="text" placeholder="Title" class="width-60 required" name="title" id="title" required >
                      </div>
                    </div>
                  </div> 
                    
                  <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Page Description <span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-6">
                        <textarea name="desc" data-rel="ckeditor" rows="3" ></textarea>
                      </div>
                    </div>
                  </div> 
                   <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Meta Description <span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-6">
                        <input type="text" placeholder="Title" class="width-60 required" name="meta_description" id="meta_description" required >
                      </div>
                    </div>
                  </div> 
                    
                    <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Meta Keyword <span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-6">
                        <input type="text" placeholder="Title" class="width-60 required" name="meta_keyword" id="meta_keyword" required >
                      </div>
                    </div>
                  </div> 
                    
                    <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Page Banner Image<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-6">
                        <input type="file" class="width-60" name="file">
                      </div>
                    </div>
                  </div> 
                   
                    
<!--                <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Name <span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-6">
                        <input type="text" placeholder="John" class="width-60 required" name="name" id="name" required >
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Company Name <span class="vd_red">*</span></label>
                      <div id="company-input-wrapper" class="controls col-sm-6">
                        <input type="text" placeholder="Your Company Co, Ltd." class="width-60 required" required  name="company" id="company">
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label col-sm-2">Website</label>
                      <div id="website-input-wrapper"  class="controls col-sm-6">
                        <input type="text" placeholder="http://www.yourcompany.com" class="width-60"  name="website" id="website">
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label col-sm-2" >Email <span class="vd_red">*</span></label>
                      <div id="email-input-wrapper"  class="controls col-sm-6">
                        <input type="email" placeholder="Email" class="width-60 required" required  name="email" id="email">
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label col-sm-2" >Member Type <span class="vd_red">*</span></label>
                      <div id="email-input-wrapper"  class="controls col-sm-6">
                        <div class="vd_radio radio-success">
                          <input type="radio" checked value="personal" id="optionsRadios3" name="member">
                          <label for="optionsRadios3"> Personal </label>
                          <input type="radio" value="business" id="optionsRadios4" name="member">
                          <label for="optionsRadios4"> Business </label>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label col-sm-2">Password <span class="vd_red">*</span></label>
                      <div id="password-input-wrapper"  class="controls col-sm-6">
                        <input type="password" placeholder="Password" class="width-40 required" required  name="password" id="password">
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label col-sm-2">Confirm Password <span class="vd_red">*</span></label>
                      <div id="confirm-password-input-wrapper" class="controls col-sm-6">
                        <input type="password" placeholder="Password" class="width-40 required" required  name="confirmpass" id="confirmpass">
                      </div>
                    </div>
                  </div>
                  <div id="vd_login-error" class="alert alert-danger hidden"><i class="fa fa-exclamation-circle fa-fw"></i> Please fill the necessary field </div>
                  <div class="form-group">
                    <div class="col-sm-2"></div>
                    <div class="col-md-6 mgbt-xs-10 mgtp-20">
                      <div class="vd_checkbox  checkbox-success">
                        <input type="checkbox" id="checkbox-3" value="1">
                        <label for="checkbox-3"> Send me newsletter about the latest update</label>
                      </div>
                      <div class="vd_checkbox checkbox-success">
                        <input type="checkbox" id="checkbox-4" value="1" required name="checkbox-4">
                        <label for="checkbox-4"> I agree with <a href="#">terms of service</a></label>
                      </div>-->
                      <div class="mgtp-10">
                        <button class="btn vd_bg-green vd_white" type="submit" id="submit-register" name="submit-register">Register</button>
                      </div>
                    </div>
                    <div class="col-md-12 mgbt-xs-5"> </div>
                  </div>
                </form>
              </div>
            </div>
            <!-- Panel Widget -->
            
<!--            <div class="panel widget light-widget">
              <div class="panel-heading no-title"> </div>
              <div class="panel-body">
                <h2 class="mgbt-xs-20">Form Type 2</h2>
                <form class="form-horizontal"  action="#" role="form" id="register-form-2">
                  <div class="alert alert-danger vd_hidden">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="icon-cross"></i></button>
                    <span class="vd_alert-icon"><i class="fa fa-exclamation-circle vd_red"></i></span><strong>Oh snap!</strong> Change a few things up and try submitting again. </div>
                  <div class="alert alert-success vd_hidden">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="icon-cross"></i></button>
                    <span class="vd_alert-icon"><i class="fa fa-check-circle vd_green"></i></span><strong>Well done!</strong>. </div>
                  <div class="form-group">
                    <div class="col-md-6">
                      <div class="label-wrapper">
                        <label class="control-label">First Name <span class="vd_red">*</span></label>
                      </div>
                      <div class="vd_input-wrapper" id="first-name-input-wrapper"> <span class="menu-icon"> <i class="fa fa-user"></i> </span>
                        <input type="text" placeholder="John" class="required" required name="firstname" id="firstname">
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="label-wrapper">
                        <label class="control-label">Last Name <span class="vd_red">*</span></label>
                      </div>
                      <div class="vd_input-wrapper" id="last-name-input-wrapper"> <span class="menu-icon"> <i class="fa fa-user"></i> </span>
                        <input type="text" placeholder="Doe" class="required" required name="lastname" id="lastname">
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-md-12">
                      <div class="label-wrapper">
                        <label class="control-label">Company Name <span class="vd_red">*</span></label>
                      </div>
                      <div class="vd_input-wrapper" id="company-input-wrapper"> <span class="menu-icon"> <i class="fa fa-briefcase"></i> </span>
                        <input type="text" placeholder="Your Company Co, Ltd." class="required" required  name="company" id="company">
                      </div>
                    </div>
                  </div>
                  <div class="form-group ">
                    <div class="col-md-3">
                      <div class="label-wrapper">
                        <label class="control-label">Phone <span class="vd_red">*</span></label>
                      </div>
                      <div class="vd_input-wrapper" id="country-code-input-wrapper"> <span class="menu-icon"> <i class="fa fa-plus"></i> </span>
                        <input type="number" placeholder="Country" class="required" required  name="country" id="country">
                      </div>
                    </div>
                    <div class="col-md-9">
                      <div class="label-wrapper">
                        <label class="control-label">&nbsp;</label>
                      </div>
                      <div class="vd_input-wrapper no-icon" id="phone-input-wrapper">
                        <input type="number" placeholder="Phone Number" class="required" required  name="phone" id="phone">
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-md-12">
                      <div class="label-wrapper">
                        <label class="control-label">Website</label>
                      </div>
                      <div class="vd_input-wrapper" id="website-input-wrapper"> <span class="menu-icon"> <i class="fa fa-globe"></i> </span>
                        <input type="text" placeholder="http://www.yourcompany.com" class=""  name="website" id="website">
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-md-12">
                      <div class="label-wrapper">
                        <label class="control-label">Email <span class="vd_red">*</span></label>
                      </div>
                      <div class="vd_input-wrapper" id="email-input-wrapper"> <span class="menu-icon"> <i class="fa fa-envelope"></i> </span>
                        <input type="email" placeholder="Email" class="required" required  name="email" id="email">
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-md-6">
                      <div class="label-wrapper">
                        <label class="control-label">Password <span class="vd_red">*</span></label>
                      </div>
                      <div class="vd_input-wrapper" id="password-input-wrapper"> <span class="menu-icon"> <i class="fa fa-lock"></i> </span>
                        <input type="password" placeholder="Password" class="required" required  name="password" id="password">
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="label-wrapper">
                        <label class="control-label">Confirm Password <span class="vd_red">*</span></label>
                      </div>
                      <div class="vd_input-wrapper" id="confirm-password-input-wrapper"> <span class="menu-icon"> <i class="fa fa-lock"></i> </span>
                        <input type="password" placeholder="Password" class="required" required  name="confirmpass" id="confirmpass">
                      </div>
                    </div>
                  </div>
                  <div id="vd_login-error" class="alert alert-danger hidden"><i class="fa fa-exclamation-circle fa-fw"></i> Please fill the necessary field </div>
                  <div class="form-group">
                    <div class="col-md-12 mgbt-xs-10 mgtp-20">
                      <div class="vd_checkbox">
                        <input type="checkbox" id="checkbox-1" value="1">
                        <label for="checkbox-1"> Send me newsletter about the latest update</label>
                      </div>
                      <div class="vd_checkbox">
                        <input type="checkbox" id="checkbox-2" value="1" required name="checkbox-2">
                        <label for="checkbox-2"> I agree with <a href="#">terms of service</a></label>
                      </div>
                    </div>
                    <div class="col-md-12 mgbt-xs-5">
                      <button class="btn vd_bg-green vd_white" type="submit" id="submit-register" name="submit-register">Register</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>-->
            
            
          </div>
          
          
        </div>
       
      </div>
      <!-- .vd_container --> 
    </div>
    <!-- .vd_content-wrapper --> 
    
    <!-- Middle Content End --> 
    
  </div>
  <!-- .container --> 
</div>
<!-- .content -->