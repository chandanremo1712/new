
<style>
.pagination>li {
display: inline;
padding:0px !important;
margin:0px !important;
border:none !important;
}
.modal-backdrop {
z-index: -1 !important;
}
/*
Fix to show in full screen demo
*/
iframe
{
height:700px !important;
}

.btn {
display: inline-block;
padding: 6px 12px !important;
margin-bottom: 0;
font-size: 14px;
font-weight: 400;
line-height: 1.42857143;
text-align: center;
white-space: nowrap;
vertical-align: middle;
-ms-touch-action: manipulation;
touch-action: manipulation;
cursor: pointer;
-webkit-user-select: none;
-moz-user-select: none;
-ms-user-select: none;
user-select: none;
background-image: none;
border: 1px solid transparent;
border-radius: 4px;
}

.btn-primary {
color: #fff !important;
background: #428bca !important;
border-color: #357ebd !important;
box-shadow:none !important;
}
.btn-danger {
color: #fff !important;
background: #d9534f !important;
border-color: #d9534f !important;
box-shadow:none !important;
}
</style>

<!--Banner-->


<section >
<div class="csi-banner csi-banner-inner">
<div class="csi-inner">
<div class="container">
<div class="row">
<div class="col-xs-12">
<div class="csi-heading-area">
<h2 class="csi-heading">
    My Orders
</h2>
<!--<ul class="breadcrumb">
<li><a href="<?=base_url()?>"><i class="icon-home6"></i>Home</a></li>
<li class="active">Cart</li>
</ul>-->
</div>
</div>
</div>
</div>

</div>
</div>
</section>


<!--Banner END-->


<div class="container" >
<div class="row profile">
<?php include 'side-bar.php';  ?>
<div class="col-md-8 order-content" style="margin-left: 35px;">




<h4 class="heading"><strong>Order </strong>List <span></span></h4>


<span style="color:green;font-size:20px;" id="msg"> <i><?php echo $this->session->flashdata('success_msg'); ?></i></span>
<div class="form">



<form  method="post" action="#">


<div class="row">
<!--<h2 class="text-center">Bootstrap styling for Datatable</h2>-->
</div>

<div class="row">

<div class="col-md-12">


<table id="table_id" class="table table-condensed table-striped table-hover dataTable">
<thead>
<tr>
  <th style="display:none;" ></th>   
<th>Order Id</th>
<!--<th>Image</th>-->
<!--<th>Name</th>
<th>Quantity</th>-->
<th>Total Amount</th>
<th>Date</th>


<th>Order Status</th>
<!--<th>Cancel Order</th>-->
<th>Invoice</th>
<th>Delete</th>
</tr>
</thead>

<tfoot>
<tr>
    
<th>Order Id</th>
<!--<th>Image</th>
<th>Name</th>
<th>Quantity</th>-->
<th>Total Amount</th>
<th>Invoice</th>
<th>Date</th>


<th>Order Status</th>
<!--<th>Cancel Order</th>-->
<th>Delete</th>
</tr>
</tfoot>

<tbody>
    
  <?php
foreach($order as $orderdetails){
    $product_id=$orderdetails->product_id;
    
    $product_details=$this->Admin_model->fetch_single_join("select * from nsn_product where id='$product_id'");
    
    
    
    //$total_price=$orderdetails->quantity*$product_details->Price;
?>  
    
    
<tr>
     <th style="display:none;" ></th>
<td>
    <a href="<?=base_url()?>Orderdetails/<?=$orderdetails->order_id?>"><u><?=$orderdetails->order_id?></u></a>
</td>

<!--<td><img src="<?=base_url()?>Banner/<?=$product_details->BannerImage;?>" alt="<?=$product_details->BannerTitle?>" style="height:80px;width:80px;"></td>-->
<!--<td>
    <a href="#">
        <?=$product_details->BannerTitle?>
    </a>
</td>-->
<!--<td><?=$orderdetails->quantity?></td>-->


<?php
$total_price_new=0;
$get_order=$this->Admin_model->fetch_all_join("select * from order_details where (order_id='$orderdetails->order_id' and user_id='$this->user_id')");
foreach($get_order as $order_total){
    
     $product_id=$order_total->product_id;
    
    $product_details=$this->Admin_model->fetch_single_join("select * from nsn_product where id='$product_id'");
    
    $total_price=$product_details->price*$order_total->quantity;
    
    $total_price_new=$total_price_new+$total_price;
    

?>

<?php } ?>



<td>$<?=$total_price_new?></td> 



<td><?php echo date("j M y", strtotime($orderdetails->date));?></td>



    
    <!--<p data-placement="top" data-toggle="tooltip" title="Edit"><button class="btn btn-primary btn-xs" data-title="Edit" data-toggle="modal" data-target="#edit" ><span class="glyphicon glyphicon-pencil"></span></button></p>-->
<td class="center">
    <p><?=$orderdetails->order_status?></p>
</td>

<!--<td class="center">
  <select id="status" onchange="changeorderstatus(this.value, '<?=$orderdetails->order_id;?>');">
                                  <option value="<?=$orderdetails->cancel_order?>"><?=$orderdetails->cancel_order?></option>
                                  <option value="Yes">Yes</option>
                                  <option value="No">No</option>
                              </select>
</td>-->

<td>
    
<a href="<?=base_url()?>invoice/<?=$orderdetails->order_id?>" target="_blank"><i class="fa fa-eye btn btn-primary" aria-hidden="true"></i></a>


</td>

<td>
     <a onclick="deleteoneorder('<?php echo $orderdetails->order_id;?>');" data-placement="top" data-toggle="tooltip" title="Delete"><button class="btn btn-danger btn-xs" data-title="Delete"><i class="fa fa-trash" aria-hidden="true"></i></button></a>


</td>


</tr>




<?php } ?>




</tbody>
</table>


</div>
</div>


<div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-labelledby="edit" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
<h4 class="modal-title custom_align" id="Heading">Edit Your Detail</h4>
</div>
<div class="modal-body">
<div class="form-group">
<input class="form-control " type="text" placeholder="Tiger Nixon">
</div>
<div class="form-group">

<input class="form-control " type="text" placeholder="System Architect">
</div>
<div class="form-group">


<input class="form-control " type="text" placeholder="Edinburgh">

</div>
</div>
<div class="modal-footer ">
<button type="button" class="btn btn-warning btn-lg" style="width: 100%;"><span class="glyphicon glyphicon-ok-sign"></span> Update</button>
</div>
</div>
<!-- /.modal-content --> 
</div>
<!-- /.modal-dialog --> 
</div>



<div class="modal fade" id="delete" tabindex="-1" role="dialog" aria-labelledby="edit" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
<h4 class="modal-title custom_align" id="Heading">Delete this entry</h4>
</div>
<div class="modal-body">

<div class="alert alert-danger"><span class="glyphicon glyphicon-warning-sign"></span> Are you sure you want to delete this Record?</div>

</div>
<div class="modal-footer ">
<button type="button" class="btn btn-success" ><span class="glyphicon glyphicon-ok-sign"></span> Yes</button>
<button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> No</button>
</div>
</div>
<!-- /.modal-content --> 
</div>
<!-- /.modal-dialog --> 
</div>              




</form>






</div>



</div>


</div>
</div>
    
  

 