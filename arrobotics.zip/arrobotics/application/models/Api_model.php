<?php 
	
	class Api_model extends CI_Model
	{
		public function insertUsers($data)
		{
			return $this->db->insert('user',$data);
		}
		public function checkLogin($data)
		{
			$query = $this->db->select('*')
								->from('user')
								->where($data)
								->get();
			if($query->num_rows() > 0){
				return $query->result();
			}
		}
		public function getId($query)
		{
			$query = $this->db->query($query);
			return $query->row();
		}
		public function getPostCode($post_code)
		{
			$query = $this->db->select('postcode')
								->from('servicelist')
								// ->where(array('postcode' => $post_code,'status' => 'active'))
								->where('postcode',$post_code)
								->where('status','active')
								->get();
			return $query->result();
		}
		public function getAboutus()
		{
			$query = $this->db->select('*')
								->from('about')
								->get();
			return $query->result();
		}
		public function contactUs($data)
		{
			return $this->db->insert(' contact',$data);
		}
		public function termsCondition()
		{
			$query = $this->db->select('*')
								->get('terms');
			return $query->result();
		}
		public function policy()
		{
			$query = $this->db->select('*')
								->get(' privacy_policy');
			return $query->result();
		}
		public function priceList()
		{
			$query = $this->db->select('prods.title,prods.image,prods.category,prods.price,
								prods.quantity,prods.subtitle,prods.description,
								prods.Status,cate.category,cate.status')
								->from('category as cate')
								->join('nsn_product as prods', 'prods.category = cate.id')
								->where('cate.status','Active')
								->where('prods.Status','Yes')
								->get();
			return $query->result();
		}
		public function productList()
		{
			$query = $this->db->select('prods.id,prods.title,prods.image,prods.price,prods.subtitle,
								prods.description,prods.Status,cate.category,cate.status')
						 	->from('category as cate')
							->join('nsn_product as prods', 'prods.category = cate.id')
							->where('cate.status','Active')
							->where('prods.Status','Yes')
							->get();
			return $query->result();
		}
		public function categoryList()
		{
			$query = $this->db->select('*')
								->where('status','Active')
								->get('category');
			return $query->result();
		}
		public function fetch_row($tbl, $where)
		{
			$this->db->select('*');
			$this->db->where($where);
			$query=$this->db->get($tbl);
			return $query->row();
		}
		public function changePassword($user_id,$old_pass)
		{
			$query = $this->db->select('*')
								->where('id',$user_id)
								->where('password',$old_pass)
								->get('user');
			return $query->result();
		}
		public function updatePass($user_id,$pass)
		{
			return $this->db->set('password',$pass)
								->where('id',$user_id)
								->update('user');
		}
		public function chkUserId($id)
		{
			$query = $this->db->select('*')
								->where('user_id',$id)
								->get('user');
			return $query->row();
		}
		public function edit_profile($tbl,$data, $id)
		{
			$this->db->where('user_id', $id);
			$this->db->update($tbl,$data);
			return true;
		}
		public function orderList($prod_id)
		{
			$query = $this->db->select('prods.id,prods.title,prods.image,prods.price,prods.subtitle,
								prods.description,prods.Status,c.user_id,c.product_id,c.quantity,c.date')
						 	->from('cart as c')
							->join('nsn_product as prods', 'prods.Id = c.id')
							->where('c.product_id',$prod_id)
							->where('prods.Status','Yes')
							->get();
			return $query->result();
		}
		public function cartInsert($value)
		{
			return $this->db->insert('cart',$value);
		}
		public function orderInsert($data)
		{
			$query = $this->db->insert('order_details',$data);
			return $query;
		}
		public function referFriend($data)
		{
			$query = $this->db->insert('refer_friend',$data);
			return $query;
		}
		public function orderSummary($id)
		{
			$query = $this->db->select('*')
								->group_by('order_id')
								->where('user_id',$id)
								->where('delete_order','No')
								->get('order_details ');
			return $query->result();
		}
	}
 ?>