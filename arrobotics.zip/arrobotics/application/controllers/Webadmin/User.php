<?php

ob_start();
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->database();

        $this->load->library('email');
        $this->load->library('form_validation');
        $this->load->model('Webadmin/Admin_model');
        $this->load->helper("file");

        $this->load->library('image_lib');
        $this->load->helper("url");
    }

    function index() {

        $page = 'tutor';
        $data['page'] = $page;

        $page_type = 'user';
        $data['page_type'] = $page_type;

        $data['Admin_model'] = $this->Admin_model;
        $fetch = $this->Admin_model->fetch_all_join('select * from user order by id desc');
        $data['fetch'] = $fetch;
        $this->load->view('Webadmin/header');
        $this->load->view('Webadmin/leftbar', $data);
        $this->load->view('Webadmin/Tutor', $data);
        $this->load->view('Webadmin/footer');
    }
    
  /*********************for show user concersation List****************************/ 
    
    function friends() {
        

        $page = 'tutor';
        $data['page'] = $page;

        $page_type = 'user';
        $data['page_type'] = $page_type;

        $data['Admin_model'] = $this->Admin_model;
        
        // $fetch = $this->Admin_model->fetch_all('user');
       
        $this->load->view('Webadmin/header');
        $this->load->view('Webadmin/leftbar', $data);
        $this->load->view('Webadmin/friends', $data);
        $this->load->view('Webadmin/footer');
    }
    
    
    function conversasion() {
        $user_id=$this->uri->segment(4);
          $friend_id=$this->uri->segment(5);

        $page = 'tutor';
        $data['page'] = $page;

        $page_type = 'user';
        $data['page_type'] = $page_type;

        $data['Admin_model'] = $this->Admin_model;
        
        // $fetch = $this->Admin_model->fetch_all('user');
       
        $this->load->view('Webadmin/header');
        $this->load->view('Webadmin/leftbar', $data);
        $this->load->view('Webadmin/conversasion', $data);
        $this->load->view('Webadmin/footer');
    }
    
     /*********************for show user concersation List ends here ****************************/ 
    

    public function view_details() {
        if (!$this->session->userdata('is_logged_in')) {
            redirect('Webadmin/Login');
        }
        $page = 'tutor';
        $data['page'] = $page;

        $page_type = 'user';
        $data['page_type'] = $page_type;

        $id = $this->uri->segment(4);
        $fetch = $this->Admin_model->fetch_single('user', $id);
        $data['fetch'] = $fetch;
        $data['Admin_model'] = $this->Admin_model;
        $this->load->view('Webadmin/header');
        $this->load->view('Webadmin/leftbar', $data);
        $this->load->view('Webadmin/tutor_details', $data);
        $this->load->view('Webadmin/footer');
    }

    function edit_details() {
        if (!$this->session->userdata('is_logged_in')) {
            redirect('Webadmin/Login');
        }
        $page = 'tutor';
        $data['page'] = $page;

        $page_type = 'user';
        $data['page_type'] = $page_type;

        if ($this->input->post('submit') == "Submit") {

            $this->form_validation->set_rules('skype', 'skype', 'required|trim');  //name , message 
            $this->form_validation->set_rules('phone', 'phone', 'required|trim');

          

            $this->form_validation->set_rules('password', 'password', 'required');


if($this->form_validation->run() == TRUE)
{


            $id = $this->input->post('id');
            $skype = $this->input->post('skype');
         
            $phone = $this->input->post('phone');
            
            //$password=  base64_encode($this->input->post('password'));
 $facebook = $this->input->post('facebook');
  $twitter = $this->input->post('twitter');
   $google_plus = $this->input->post('google_plus');
      $linkedin = $this->input->post('linkedin');


            $field_data = array(
                'skype' => $skype,
                'password' => base64_encode($this->input->post('password')),
               
                'phone' => $phone,
              
                'facebook'=>$facebook,
                  'twitter'=>$twitter,
                   'google_plus'=>$google_plus,
                   'linkedin'=>$linkedin
                
            );








            $result = $this->Admin_model->eidt_details('user', $field_data, $id);
            
          //  echo $this->db->last_query();exit();
            
            if ($result) {
                $succ = "Data Updated Successfully";
                $data['succ'] = $succ;
                $fetch = $this->Admin_model->fetch_single('user', $id);
                $data['fetch'] = $fetch;

                redirect(base_url() . 'Webadmin/User/index/usucc');
            }
            
}
else{ 
    
    
     $id = $this->uri->segment(4);


            $fetch = $this->Admin_model->fetch_single('user', $id);
            $data['fetch'] = $fetch;
}
            
            
            
        } else {
            $id = $this->uri->segment(4);


            $fetch = $this->Admin_model->fetch_single('user', $id);
            $data['fetch'] = $fetch;
        }
        $data['Admin_model'] = $this->Admin_model;
        $this->load->view('Webadmin/header');
        $this->load->view('Webadmin/leftbar', $data);
        $this->load->view('Webadmin/tutor_details', $data);
        $this->load->view('Webadmin/footer');
    }

    function add_details() {
        if (!$this->session->userdata('is_logged_in')) {
            redirect('Webadmin/Login');
        }

        $page = 'employee';
        $data['page'] = $page;

        $page_type = 'user';
        $data['page_type'] = $page_type;


        if ($this->input->post('submit') == "Submit") {


            $rn = "SELECT LAST_INSERT_ID(id) as id From sos_user_register order by id desc limit 1";
            $fetch = $this->Admin_model->fetch_single_join($rn);

            @$id = $fetch->id;

            $user_id = "SOSEMP10" . ($id + 1);



            $name = $this->input->post('fullname');
            $nm = explode(' ', $name);
            $cnt = count($nm);
            if ($cnt > 1) {
                $firstname = $nm[0];
                $lastname = $nm[1];
            } else {
                $firstname = $nm[0];
                $lastname = "";
            }
            $mobile = $this->input->post('mobile');
            $business_name = addslashes($this->input->post('business_name'));
            $about_business = addslashes($this->input->post('about_business'));
            $email = addslashes($this->input->post('email'));
            $pass = rand(1000, 99999);
            $password = base64_encode($pass);
            $location = $this->input->post('location');

//                if($location==1)
//                {
//                    $sub=2;
//                }
//                elseif($location>=2 && $location<=5)
//                    
//                {
//                  $sub=3;  
//                }
//                
//                 elseif($location>=6 && $location<=10)
//                    
//                {
//                  $sub=4;  
//                }
//                  elseif($location>=11 && $location<=20)
//                    
//                {
//                  $sub=5;  
//                }
//                else{$sub=6;}
            //-------new image upload-----------//
            //$old_image = $this->input->post('old_img');
            $config['upload_path'] = 'profile/medium/';
            $config['allowed_types'] = 'gif|jpg|png';
            $config['max_size'] = 2048;
            $config['max_width'] = 3000;
            $config['max_height'] = 2000;
            $config['file_name'] = uniqid();
            $this->load->library('upload', $config);

            if (!$this->upload->do_upload('file')) {
                $error = array('error' => $this->upload->display_errors());
                $image = "";
            } else {
                $file_data = $this->upload->data();
                $image = $file_data['file_name'];
            }


            //--------new image upload end---------//

            $field_data = array(
                'ip' => $_SERVER['REMOTE_ADDR'],
                'user_id' => $user_id,
                'first_name' => $firstname,
                'email' => $email,
                'password' => $password,
                'last_name' => $lastname,
                'mobile' => $mobile,
                'business_name' => $business_name,
                'about_business' => $about_business,
                'profile' => $image,
                'register_date' => date('Y-m-d'),
                'register_time' => date('Y-m-d H:i:s'),
                'status' => 'Active',
                'verification_status' => 1
            );



            // $fetch_sub= $this->Admin_model->fetch_single('sos_subscription_rate', $sub);     

            $data_sub = array(
                'user_id' => $user_id,
                'user' => $email,
                'start_date' => date('Y-m-d'),
                'end_date' => date('Y-m-d', strtotime("+30 days")),
                'max_subscription' => $location
            );


            $resultloc = $this->Admin_model->add_details('sos_user_subscribed', $data_sub);


            $result = $this->Admin_model->add_details('sos_user_register', $field_data);

            //  echo $this->db->last_query();exit();

            if ($result) {
                $succ = "Data Updated Successfully";
                $data['succ'] = $succ;
                $fetch = $this->Admin_model->fetch_single('sos_user_register', $id);
                $data['fetch'] = $fetch;


                $htmlContent = "<table align='center' style='width:650px; text-align:center; background:#f7f7f7;'>
						<tbody>
						<tr style='height:50px;background-color:#f2f2f2;'><td valign='middle' style='color:white;'><img src='" . base_url() . "frontend/image/logo.png' alt='SOS' title='SOS' /></td></tr>
						<tr>
						<td valign='top' align='center' colspan='2'>
						<table align='center' style='height:380px; color:#000; width:600px;'>
						<tbody>
						<tr>
						<td style='width:8px;'>&nbsp;</td> 
						<td align='center' style='font-size:28px;border-top:1px dashed #ccc;' colspan='3'>Hello, " . $firstname . "&nbsp;" . $lastname . "</td>
						</tr>
						<tr>
						<td valign='top' align='center' colspan='2'>
						<br>
						
						
                                                     <p>Thank you for signing up to Short on staff. Please find your login details below</p><br>
                                                      <p> Login Username/Email : " . $email . "</p><br/>
                                                    <p>Login Password : " . $pass . "</p><br/>    
                                            
						<br>
						Sincerely,<br>
						SOS Team<br><br>
						<strong>Email:</strong>info@shortonstaff.com<br><br>
						
						This is an automated response, please DO NOT reply.
						</td>
						</tr>
						</tbody>
						</table>
						</td>
						</tr>
						</tbody>
						</table>";

                $config['mailtype'] = 'html';
                $config['smtp_host'] = 'smtp-pulse.com';
                $config['smtp_user'] = 'info@shortonstaff.com';
                $config['smtp_pass'] = '5LsDXg2Drn';
                $config['smtp_port'] = '2525';

                $this->email->initialize($config);
                $this->email->to($email);
                $this->email->from('info@shortonstaff.com', 'SOS');
                $this->email->subject('Employer Verification From SOS');
                $this->email->message($htmlContent);

                $this->email->send();








                /*                 * ***********email send to admin [cn]******************* */

                $adminhtml = "<table align='center' style='width:650px; text-align:center; background:#f7f7f7;'>
<tbody>
<tr style='height:50px;'><td valign='middle'><img src='" . base_url() . "frontend/image/logo.png' alt='SOS' title='SOS' /></td></tr>
<tr>
<td valign='top' align='center' colspan='2'>
<table align='center' style='height:380px; color:#000; width:600px;'>
<tbody>
<tr>
<td style='width:8px;'>&nbsp;</td>               
<td align='center' style='font-size:28px;border-top:1px dashed #ccc;' colspan='3'>Hello Admin,</td>
</tr>
<tr>
<td valign='top' align='center' colspan='2'>
A New Employer Has Registered From Short on Staff Website.<br><br>
We have sent  a verification link to activate the account.<br><br>
Registration Details of $user_id.<br><br>
<table align='center' style='color:#000; width:600px;'>
<tbody>
<tr align='center'><td><strong>ID</strong>&nbsp;:&nbsp;$user_id</td></tr>

<tr align='center'><td><strong>EMAIL</strong>&nbsp;:&nbsp;$email</td></tr>
<tr align='center'><td><strong>MOBILE</strong>&nbsp;:&nbsp;$mobile</td></tr>
<tr align='center'><td><strong>PASSWORD</strong>&nbsp;:&nbsp;$password</td></tr>
<tr align='center'><td><strong>FIRST NAME</strong>&nbsp;:&nbsp;$firstname</td></tr>
<tr align='center'><td><strong>LAST NAME</strong>&nbsp;:&nbsp;$lastname</td></tr>
<tr align='center'><td><strong>BUSINESS NAME</strong>&nbsp;:&nbsp;$business_name</td></tr>

<tr align='center'><td><strong>ABOUT BUSINESS</strong>&nbsp;:&nbsp;$about_business</td></tr>
</tbody>
</table>
<br>
Sincerely,<br>
Short on Staff Support Team<br>
This is an automated response, please DO NOT reply.
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>";



                $config['mailtype'] = 'html';

                $this->email->initialize($config);
                $this->email->to('registrations@shortonstaff.com');
                $this->email->from('info@shortonstaff.com', 'SOS');
                $this->email->subject('Employer Registration From SOS');
                $this->email->message($adminhtml);

                $this->email->send();




                /*                 * **************email send to admin [cn]*************** */
            }
        }





        $data['Admin_model'] = $this->Admin_model;
        $this->load->view('Webadmin/header');
        $this->load->view('Webadmin/leftbar', $data);
        $this->load->view('Webadmin/user_details', $data);
        $this->load->view('Webadmin/footer');
    }

    function DeleteEmp() {

        $user_id = $this->input->get('id', TRUE);
        // $fetch = $this->Admin_model->fetch_single('sos_user_register',$id);
        //print_r( $fetch);exit();

        $banner = $this->Admin_model->delete_single_con('user',"user_id='$user_id'");  
        
        $banner1 = $this->Admin_model->delete_single_con('order_details',"user_id='$user_id'"); 
        
        if ($banner) {

            echo 'deleted';
        }
    }
    
    


    public function tutor_email_check($email) {

        $email = $email;
        $fetch_row = $this->Admin_model->fetch_row('tutor', "email='$email'");
        // echo $this->db->last_query();exit();




        if ($fetch_row>0) {
            $this->form_validation->set_message('tutor_email_check', 'Email Already Exists');

            return FALSE;
        }

        return TRUE;
    }
    
    public function tutor_username_check($email) {

        $username = $username;
        $fetch_row = $this->Admin_model->fetch_row('tutor', "username='$username'");
        // echo $this->db->last_query();exit();




        if ($fetch_row >0) {
            $this->form_validation->set_message('tutor_username_check', 'Username Already Exists');

            return FALSE;
        }

        return TRUE;
    }
    
    
    
    
    
    

}
