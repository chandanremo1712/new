<?php
defined('BASEPATH') OR exit('No Direct Script access allowed');

class WeeklyMenu extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Webadmin/Admin_model');
                $this->load->helper("file");

                
	}
	
	public function index()
        {
            if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
            $page = 'weekly_menu';
            $data['page'] = $page;
            
            $fetch = $this->Admin_model->fetch_all('nsn_weekly_menu');
            $data['fetch'] = $fetch;
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/weekly_menu');
            $this->load->view('Webadmin/footer');
        }
	
        public function add_menu()
        {
            if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
            $page = 'weekly_menu';
            $data['page'] = $page;
            
            $image = "";
            if($this->input->post('submit') == 'Submit')
            {
                $title = $this->input->post('title');
              //  print_r($title);exit();
               // $description = $this->input->post('desc');
                
               foreach ($title as $key => $value) {
                   
               
                $field_data = array(
                        'MenuName' => addslashes($value),
                        //'Description' => addslashes($description),
                        );
                $result = $this->Admin_model->add_details('nsn_weekly_menu', $field_data);
               }
                
                
                if($result){
                    $succ = "Data Added Successfully";
                    $data['succ']=$succ;
                }
           }
            //$cms = $this->Cms_model->fetch_all();
            //$data['cms'] = $cms;
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/weekly_menu_details');
            $this->load->view('Webadmin/footer');
        }
        
        public function weekly_regular_menu()
        {   if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
            $page = 'weekly_menu';
            $data['page'] = $page;
            
            $title = "Regular";
            $data['title']=$title;
            
            $menulist = $this->Admin_model->fetch_all('nsn_weekly_regular_menu');
            $data['menulist'] = $menulist;
      
            $fetch = $this->Admin_model->fetch_all('nsn_menu');
            $data['fetch'] = $fetch;
            
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/weekly_menu_details',$data);
            $this->load->view('Webadmin/footer');
        }
        
        public function weekly_special_menu()
        {   if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
            $page = 'weekly_menu';
            $data['page'] = $page;
            
            $title = "Special";
            $data['title']=$title;
            
            $menulist = $this->Admin_model->fetch_all('nsn_weekly_special_menu');
            $data['menulist'] = $menulist;
      
            $fetch = $this->Admin_model->fetch_all('nsn_menu');
            $data['fetch'] = $fetch;
            
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/weekly_menu_details',$data);
            $this->load->view('Webadmin/footer');
        }
        
        public function edit_weekly_special_menu()
        {   if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
            $page = 'weekly_menu';
            $data['page'] = $page;
            
            $title = "Special";
            $data['title']=$title;
            
            if($this->input->post('submit') == 'Submit')
            {
                for($i=1; $i<=7;$i++){
                    $menus = $this->input->post('menu'.$i);
                    $menu_list = @implode(',',$menus);
                    //print_r($menu_list);exit();
                    
                    //print_r($title);
                    $id = $this->input->post('id'.$i);
                    
                    $field_data = array(
                            'MenuList' => $menu_list
                            );
                    $result = $this->Admin_model->edit_details('nsn_weekly_special_menu', $field_data,$id);
                   //echo $this->db->last_query();exit();
                }
                if($result){
                    $succ = "Data Updated Successfully";
                    $data['succ']=$succ;
                    $menulist = $this->Admin_model->fetch_all('nsn_weekly_special_menu');
                    $data['menulist'] = $menulist;
                    
                    $fetch = $this->Admin_model->fetch_all('nsn_menu');
                    $data['fetch'] = $fetch;
                    
                }
           }
           
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/weekly_menu_details',$data);
            $this->load->view('Webadmin/footer');
        }
        
        public function edit_weekly_regular_menu()
        {   if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
            $page = 'weekly_menu';
            $data['page'] = $page;
            
            $title = "Regular";
            $data['title']=$title;
            
            if($this->input->post('submit') == 'Submit')
            {
                for($i=1; $i<=7;$i++){
                    $menus = $this->input->post('menu'.$i);
                    $menu_list = @implode(',',$menus);
                    //print_r($menu_list);exit();
                    
                    //print_r($title);
                    $id = $this->input->post('id'.$i);
                    
                    $field_data = array(
                            'MenuList' => $menu_list
                            );
                    $result = $this->Admin_model->edit_details('nsn_weekly_regular_menu', $field_data,$id);
                   //echo $this->db->last_query();exit();
                }
                if($result){
                    $succ = "Data Updated Successfully";
                    $data['succ']=$succ;
                    $menulist = $this->Admin_model->fetch_all('nsn_weekly_regular_menu');
                    $data['menulist'] = $menulist;
                    
                    $fetch = $this->Admin_model->fetch_all('nsn_menu');
                    $data['fetch'] = $fetch;
                    
                }
           }
           
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/weekly_menu_details',$data);
            $this->load->view('Webadmin/footer');
        }
	//Start About-------------------------------------------------------------------------------------------
	function view_menu()
	{
            if(!$this->session->userdata('is_logged_in'))
            {
            redirect('Webadmin/Login');
            }
            $page = 'menu';
            $data['page'] = $page;
            
            $id = $this->uri->segment(4);
            $fetch = $this->Admin_model->fetch_single('nsn_menu', $id);
            $data['fetch'] = $fetch;
            
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/menu_details',$data);
            $this->load->view('Webadmin/footer');
	}
        
        public function delete_menu()
	{
            
           $id = $this->input->get('id', TRUE);
           
           $faq = $this->Admin_model->delete_single('nsn_menu', $id);
           if($faq){
               
                echo 'deleted';
           } 
            
	}
        
        public function change_status()
        {
            $tbl = $this->uri->segment(4);
            echo $tbl;exit();
            $id = $this->input->get('id', TRUE);
            $val = $this->input->get('val');
            $field_data = array(
                       'Status' => $val
                       );
            $result = $this->Admin_model->eidt_details('nsn_menu', $field_data,$id);
            if($result)
            {
                echo 'Status Changed';
            }
        }
//End About---------------------------------------------------------------------------------------------
	

	
}


?>