<?php
defined('BASEPATH') OR exit('No Direct Script access allowed');

class Category extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Webadmin/Admin_model');
                $this->load->helper("file");

                
	}
	
	public function index()
        {
            if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
            $page = 'category';
            $data['page'] = $page;
              $data['category'] = $this->Admin_model->fetch_all('category');
            
            $fetch = $this->Admin_model->fetch_all_join('select * from category order by id desc');
            $data['fetch'] = $fetch;
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/wash_category');
            $this->load->view('Webadmin/footer');
        }
	
          function Category()
        {
                if(!$this->session->userdata('is_logged_in'))
            {
            redirect('Webadmin/Login');
            }
          $data['page']="category";
           
            $fetch = $this->Admin_model->fetch_all('category');
            $data['fetch'] = $fetch;
            
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/wash_category_details',$data);
            $this->load->view('Webadmin/footer');
        }
	
        
        
        
        function AddCategory() {
             if(!$this->session->userdata('is_logged_in'))
            {
            redirect('Webadmin/Login');
            }
            $page='category';
            $data['page']=$page;
            if($this->input->post('submit') == 'Submit')
            {
                     
                
             
				
                 $title = stripslashes($this->input->post('title'));
                  $field_data = array(
                        'category' => addslashes($title)
                      );
                   $result = $this->Admin_model->add_details('category', $field_data);
           
                    if($result){
                    $succ = "Data Added Successfully";
                    $data['succ']=$succ;
                }
                   
            }
            
            
            
             $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/wash_category_details');
            $this->load->view('Webadmin/footer');
            
        }
        
        
        
        public function EditCategory()
        {   if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
            $page = 'category';
            $data['page'] = $page;
           
            if($this->input->post('submit') == 'Submit')
            {
                
                $id = $this->input->post('id');
                $title = stripslashes($this->input->post('title'));
            
                
                
                $field_data = array(
                        'category' => addslashes($title)
                       
                        );
                $result = $this->Admin_model->edit_details('category', $field_data,$id);
                if($result){
                    $succ = "Data Updated Successfully";
                    $data['succ']=$succ;
                    $fetch = $this->Admin_model->fetch_single('category', $id);
                    $data['fetch'] = $fetch;
                    
                }
           }else{
            
                $id = $this->uri->segment(4);
                $fetch = $this->Admin_model->fetch_single('category', $id);
                $data['fetch'] = $fetch;
            
           }
            
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/wash_category_details',$data);
            $this->load->view('Webadmin/footer');
        }
        
        
        
        
         public function DelCategory()
	{
            
           $id = $this->input->get('id', TRUE);
           
           $del_product = $this->Admin_model->delete_single_con('nsn_product',"category=$id");
           
           $faq = $this->Admin_model->delete_single('category', $id);
           
            
            
            
           if($faq){
               
                echo 'deleted';
           } 
            
	}
//End About---------------------------------------------------------------------------------------------
	

	
}


?>