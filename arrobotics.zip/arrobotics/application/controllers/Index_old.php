<?php
//error_reporting(0);
defined('BASEPATH') OR exit('No direct script access allowed');
class Index extends CI_Controller {


function __construct() { 
parent::__construct(); 

//$this->load->model('Users_signup');
//$this->load->model('Signin_model');

$this->load->model('Webadmin/Admin_model');
$this->load->library('form_validation');
$this->load->library('upload');
$this->load->helper(array('form', 'url'));
$this->load->library('email');
$this->load->library("pagination");



} 

public function index()
{
$page='home';
$data['page']=$page;

$data['page_name']='Home';

$data['about']=$this->Admin_model->fetch_single('about','1');

//$data['our_experts']=  $this->Admin_model->fetch_all_join("select * from tbl_cms where Status='Yes' order by id desc");
//$data['services']=  $this->Admin_model->fetch_all_join("select * from itservices where Status='Yes' order by Sl_no asc");

$this->load->view('header',$data);
$this->load->view('index',$data);
$this->load->view('footer',$data);

}

public function about()
{
$data['page_name']='About';

$page='about';
$data['page']=$page;

$data['about']=$this->Admin_model->fetch_single('about','1');

//$data['our_experts']=  $this->Admin_model->fetch_all_join("select * from tbl_cms where Status='Yes' order by id desc");

$this->load->view('header',$data);
$this->load->view('about',$data);
$this->load->view('footer',$data);

}


public function services() {
    
    $data['page_name']='Services';

$page='services';
$data['page']=$page;

$this->load->view('header',$data);
$this->load->view('services',$data);
$this->load->view('footer',$data);

}

public function servicedetails() {

$page='services';
$data['page']=$page;
$id=$this->uri->segment(2);  
//$data['about']=$this->Admin_model->fetch_single("about_program",'1');
$data['service_info']=$service_info=  $this->Admin_model->fetch_single_join("select * from courses where Status='Yes' and id='".$id."'");


$data['page_name']=$service_info->CourseTitle;

$this->load->view('header',$data);
$this->load->view('servicedetails',$data);
$this->load->view('footer',$data);

}

public function ourteam()
{
$page='team';
$data['page']=$page;

$data['page_name']='Our Team';

//$data['contact']=$this->Admin_model->fetch_single("nsn_contact",'1');

$this->load->view('header', $data);
$this->load->view('team', $data);
$this->load->view('footer', $data);

}


/*public function contact()
{
$page='contact';
$data['page']=$page;
//$data['contact']=$this->Admin_model->fetch_single("nsn_contact",'1');
$this->load->view('header', $data);
$this->load->view('contact', $data);
$this->load->view('footer', $data);
}*/

 public function contact()
{ 
$data['page_name']='Contact Us';
if($this->input->post('submit')=='submit')

{

$htmlContent = "<table align='center' style='width:650px; text-align:center; background:#f7f7f7;'>

<tbody>

<tr style='height:50px;background-color:white;'><td valign='middle' style='color:white;'><img src='".base_url()."images/logo-108x40.png' alt='Devonetech' title='Devonetech' /></td></tr>

<tr>

<td valign='top' align='center' colspan='2'>

<table align='center' style='height:380px; color:#000; width:600px;'>

<tbody>

<tr>

<td style='width:8px;'>&nbsp;</td> 

<td align='center' style='font-size:28px;border-top:1px dashed #ccc;' colspan='3'>Hello Admin,</td>

</tr>

<tr>

<td valign='top' align='center' colspan='2'>

Contacted User Details .<br><br>



Name:&nbsp;".$this->input->post('name').".<br><br>

Email:&nbsp;".$this->input->post('email').".<br><br>

Phone:&nbsp;".$this->input->post('phone').".<br><br>

Message:&nbsp;".$this->input->post('message').".<br><br>

<br>

Sincerely,<br>

Devonetech<br><br>

<strong>Email:</strong>sales@devone.tech<br><br>



This is an automated response, please DO NOT reply.

</td>

</tr>

</tbody>

</table>

</td>

</tr>

</tbody>

</table>";

//  echo $htmlContent;    
// exit();

$config['mailtype'] = 'html';

$this->email->initialize($config);

$this->email->to('sales@devone.tech');

$this->email->from('sales@devone.tech','Devonetech');

$this->email->subject('Contacted User Details');

$this->email->message($htmlContent);

//$this->email->send();

$data2 = array(

'name' => $this->input->post('name'),
'email' => $this->input->post('email'),
'phone' => $this->input->post('phone'),
'message' =>$this->input->post('message')

);   


$result=$this->Admin_model->add_details('contact',$data2); 

//echo $this->db->last_query();
//exit();

//Send mail 

if($result)
{
$this->session->set_flashdata("success_msg","Thankyou for contacting us."); 
} 
else
{
$this->session->set_flashdata("success_msg","Error in sending Email."); 

}

}


$page='contact';

$data['page']=$page;

$this->load->view('header',$data);

$this->load->view('contact',$data);

$this->load->view('footer');



 }


 public function career()
{ 
$page='career';
$data['page']=$page;

  $data['page_name']='Career';


if($this->input->post('submit')=='submit')

{

$config['upload_path']   = './CV/'; 

$config['allowed_types'] = 'doc|docx|pdf'; 

$config['max_size']      = 204800; 

$config['max_width']     = 300000; 

$config['max_height']    = 200000; 

//

$this->load->library('upload', $config);
$this->upload->initialize($config);

if (!$this->upload->do_upload('file')) {
 $error = array('error' => $this->upload->display_errors()); 
// print_r($error);
}
else { 
    
$file_data = $this->upload->data();

$cv = $file_data['file_name'];

} 

$data2 = array(

'name' => $this->input->post('name'),
'email' => $this->input->post('email'),
'phone' => $this->input->post('phone'),
'message' =>$this->input->post('message'),
'position'=> $this->input->post('position'),
'cv'=>$cv

);   

$result=$this->Admin_model->add_details('career',$data2); 

//echo $this->db->last_query();
//exit();

//Send mail 

if($result)
{
    
$htmlContent = "<table align='center' style='width:650px; text-align:center; background:#f7f7f7;'>

<tbody>

<tr style='height:50px;background-color:white;'><td valign='middle' style='color:white;'><img src='".base_url()."images/logo-108x40.png' alt='Devonetech' title='Devonetech' /></td></tr>

<tr>

<td valign='top' align='center' colspan='2'>

<table align='center' style='height:380px; color:#000; width:600px;'>

<tbody>

<tr>

<td style='width:8px;'>&nbsp;</td> 

<td align='center' style='font-size:28px;border-top:1px dashed #ccc;' colspan='3'>Hello Admin,</td>

</tr>

<tr>

<td valign='top' align='center' colspan='2'>

Contacted User Details .<br><br>



Name:&nbsp;".$this->input->post('name').".<br><br>

Email:&nbsp;".$this->input->post('email').".<br><br>

Phone:&nbsp;".$this->input->post('phone').".<br><br>

Message:&nbsp;".$this->input->post('message').".<br><br>

<br>

Sincerely,<br>

Devonetech<br><br>

<strong>Email:</strong>sales@devone.tech<br><br>



This is an automated response, please DO NOT reply.

</td>

</tr>

</tbody>

</table>

</td>

</tr>

</tbody>

</table>";

//  echo $htmlContent;    
// exit();

$config['mailtype'] = 'html';

$this->email->initialize($config);

$this->email->to('sales@devone.tech');

$this->email->from('sales@devone.tech','Devonetech');

$this->email->subject('Contacted User Details');

$this->email->message($htmlContent);

//$this->email->send();


$this->session->set_flashdata("success_msg","Thankyou for showing interest in Devone Technology...We will get back to you shortly."); 
} 
else
{
$this->session->set_flashdata("success_msg","Error in sending Email."); 

}

}




$this->load->view('header',$data);
$this->load->view('career',$data);
$this->load->view('footer');
 }



public function partnership()
{
$page='partnership';
$data['page']=$page;

$data['page_name']='Partnership';



if($this->input->post('submit')=='submit')

{
    
    $config['upload_path']   = './CV/'; 

$config['allowed_types'] = 'doc|docx|pdf'; 

$config['max_size']      = 204800; 

$config['max_width']     = 300000; 

$config['max_height']    = 200000; 

//

$this->load->library('upload', $config);
$this->upload->initialize($config);

if (!$this->upload->do_upload('file')) {
 $error = array('error' => $this->upload->display_errors()); 
// print_r($error);
}
else { 
    
$file_data = $this->upload->data();

$document = $file_data['file_name'];

} 

$date=date('Y-m-d');
    
$data2 = array(

'name' => $this->input->post('name'),
'email' => $this->input->post('email'),
'phone' => $this->input->post('phone'),
'company'=>$this->input->post('company'),    
'relation'=>$this->input->post('relation'), 
'website'=> $this->input->post('website'),  
 'budget'=>$this->input->post('budget'),   
'message' =>$this->input->post('message'),
 'document'=>$document   
    
);   

$result=$this->Admin_model->add_details('partner',$data2); 
 

if($result)
{
    
$htmlContent = "<table align='center' style='width:650px; text-align:center; background:#f7f7f7;'>

<tbody>

<tr style='height:50px;background-color:white;'><td valign='middle' style='color:white;'><img src='".base_url()."images/logo-108x40.png' alt='Devonetech' title='Devonetech' /></td></tr>

<tr>

<td valign='top' align='center' colspan='2'>

<table align='center' style='height:380px; color:#000; width:600px;'>

<tbody>

<tr>

<td style='width:8px;'>&nbsp;</td> 

<td align='center' style='font-size:28px;border-top:1px dashed #ccc;' colspan='3'>Hello Admin,</td>

</tr>

<tr>

<td valign='top' align='center' colspan='2'>

Contacted User Details .<br><br>



Name:&nbsp;".$this->input->post('name').".<br><br>

Email:&nbsp;".$this->input->post('email').".<br><br>

Phone:&nbsp;".$this->input->post('phone').".<br><br>

Message:&nbsp;".$this->input->post('message').".<br><br>

<br>

Sincerely,<br>

Devonetech<br><br>

<strong>Email:</strong>sales@devone.tech<br><br>



This is an automated response, please DO NOT reply.

</td>

</tr>

</tbody>

</table>

</td>

</tr>

</tbody>

</table>";

//  echo $htmlContent;    
// exit();

$config['mailtype'] = 'html';

$this->email->initialize($config);

$this->email->to('sales@devone.tech');

$this->email->from('sales@devone.tech','Devonetech');

$this->email->subject('Prtnership User Details');

$this->email->message($htmlContent);

//$this->email->send();


$this->session->set_flashdata("success_msg","Thankyou for showing interest in Devone Technology...We will get back to you shortly."); 

redirect(base_url().'partnership');

} 
else
{
$this->session->set_flashdata("success_msg","Error in sending Email."); 

redirect(base_url().'partnership');

}

}




$this->load->view('header',$data);
$this->load->view('partnership',$data);
$this->load->view('footer',$data);
}

public function process()
{
$page='process';
$data['page']=$page;


$data['page_name']='Partnership';

$this->load->view('header',$data);
$this->load->view('process',$data);
$this->load->view('footer',$data);
}
 
 
    function ourblog() {
        
  
$data['page_name']='Blog';

        $data['page'] = "blog";
        $fetch = $this->Admin_model->fetch_all_join("select * from nsn_blog where Status='Yes' order by id desc");

         //$data['fetch_category'] = $this->Admin_model->fetch_all('event_category');

        //pagination settings

        $config['base_url'] = base_url() . 'ourblog';

        $config['total_rows'] = count($fetch);

        $config['per_page'] = "6";

        $config["uri_segment"] = 2;

        $choice = $config["total_rows"] / $config["per_page"];

        $config["num_links"] = floor($choice);



        //config for bootstrap pagination class integration

        $config['full_tag_open'] = '<ul class="pagination">';

        $config['full_tag_close'] = '</ul>';

        $config['first_link'] = false;

        $config['last_link'] = false;

        $config['first_tag_open'] = '<li>';

        $config['first_tag_close'] = '</li>';

        $config['prev_link'] = '&laquo';

        $config['prev_tag_open'] = '<li class="prev">';

        $config['prev_tag_close'] = '</li>';

        $config['next_link'] = '&raquo';

        $config['next_tag_open'] = '<li>';

        $config['next_tag_close'] = '</li>';

        $config['last_tag_open'] = '<li>';

        $config['last_tag_close'] = '</li>';

        $config['cur_tag_open'] = '<li class="active"><a href="#">';

        $config['cur_tag_close'] = '</a></li>';

        $config['num_tag_open'] = '<li>';

        $config['num_tag_close'] = '</li>';



        $this->pagination->initialize($config);

        $data['page1'] = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;



        //call the model function to get the department data

        $pquery = "select * from nsn_blog where Status='Yes' order by id desc limit " . $data['page1'] . "," . $config['per_page'];

        $data['deptlist'] = $this->data['result'] = $this->Admin_model->fetch_all_join($pquery);

        //$data['deptlist'] = $this->department_model->get_department_list($config["per_page"], $data['page']);           

        $data['pagination'] = $this->pagination->create_links();

        $data['blog'] = $fetch;

        $this->load->view('header', $data);

        $this->load->view('blog', $data);

        $this->load->view('footer', $data);

    }

    
public function blogdetails() {

$page='blog';
$data['page']=$page;
$id=$this->uri->segment(2);  


$data['blog_info']= $blog_info= $this->Admin_model->fetch_single_join("select * from nsn_blog where Status='Yes' and id='".$id."'");


$data['page_name']=$blog_info->BlogTitle;

$this->load->view('header',$data);
$this->load->view('blogdetails',$data);
$this->load->view('footer',$data);

}

public function terms()
{

$page='terms';
$data['page']=$page;
$data['terms']=$this->Admin_model->fetch_single('terms','1');
$this->load->view('header',$data);
$this->load->view('terms',$data);
$this->load->view('footer',$data);

}


public function privacy()
{

$page='privacy';
$data['page']=$page;
$data['privacy']=$this->Admin_model->fetch_single('privacy_policy','1');
$this->load->view('header',$data);
$this->load->view('privacy-policy',$data);
$this->load->view('footer',$data);

}


public function refund()
{

$page='refund';
$data['page']=$page;

$data['refund']=$this->Admin_model->fetch_single('privacy_policy','2');

$this->load->view('header',$data);
$this->load->view('refund-policy',$data);
$this->load->view('footer',$data);

}


public function delivery()
{

$page='delivery';
$data['page']=$page;

$data['delivery']=$this->Admin_model->fetch_single('privacy_policy','3');

$this->load->view('header',$data);
$this->load->view('delivery-policy',$data);
$this->load->view('footer',$data);

}

public function ourpricing()
{


$page='ourpricing';
$data['page']=$page;

$data['page_name']='Our Pricing';

$this->load->view('header',$data);
$this->load->view('ourpricing',$data);

$this->load->view('footer',$data);
}

public function portfolio()
{


$page='portfolio';
$data['page']=$page;

$data['page_name']='Portfolio';

$this->load->view('header',$data);
$this->load->view('portfolio',$data);
$this->load->view('footer',$data);


}

public function careers() {

$page='careers';
$data['page']=$page;

$data['page_name']='Career';

$this->load->view('header',$data);
$this->load->view('careers',$data);
$this->load->view('footer',$data);

}

public function properties()
{

$page='properties';
$data['page']=$page;
$data['fetch_property']=  $this->Admin_model->fetch_all_join("select * from property where Status='Yes' order by Id desc");      
$this->load->view('header',$data);
$this->load->view('properties');

$this->load->view('footer',$data);

}


public function gallery()
{

$page='gallery';
$data['page']=$page;
$data['gallery_image']=  $this->Admin_model->fetch_all_join("select * from gallery order by id desc");     


$this->load->view('header',$data);
$this->load->view('gallery');

$this->load->view('footer',$data);



}

public function products()
{
  $cat=  base64_decode($this->uri->segment(2));
$page='shop';
$data['page']=$page;
$data['products']=  $this->Admin_model->fetch_all_join("select * from nsn_product where Category='$cat' order by Id");     


$this->load->view('header',$data);
$this->load->view('store',$data);

$this->load->view('footer',$data);

}

public function productdetails()
{

$page='shop';
$data['page']=$page;
$id=  base64_decode($this->uri->segment(2));

$data['products']=  $this->Admin_model->fetch_single_data('nsn_product',$id);     


$this->load->view('header',$data);
$this->load->view('store-details',$data);

$this->load->view('footer',$data);



}

public function cart()
{

$page='shop';
$data['page']=$page;

$this->load->view('header',$data);
$this->load->view('cart',$data);

$this->load->view('footer',$data);

}



public function giftcard()
{
$page='giftcard';
$data['page']=$page;

//$data['contact']=$this->Admin_model->fetch_single("nsn_contact",'1');

$this->load->view('header', $data);
$this->load->view('giftcard', $data);
$this->load->view('footer', $data);

}

public function advertiser()
{
$page='advertiser';
$data['page']=$page;

//$data['contact']=$this->Admin_model->fetch_single("nsn_contact",'1');
$this->load->view('header', $data);
$this->load->view('advertiser', $data);
$this->load->view('footer', $data);

}


function register()
{
    $data['page']='user';
    
 $this->load->view('header', $data);
$this->load->view('register', $data);
$this->load->view('footer', $data);

}

function programs()
{
    $data['page']='programs';
    
 $this->load->view('header', $data);
$this->load->view('programs', $data);
$this->load->view('footer', $data);

}

function partners(){
$data['page']='partners';


$this->load->view('header', $data);
$this->load->view('partners', $data);
$this->load->view('footer', $data);
}

function register1() {
// $data['page'] = 'studentregistration';
$data['page'] = 'user';


if($this->input->post('submit')=='submit'){

$this->form_validation->set_rules('name', 'name', 'required');
$this->form_validation->set_rules('username', 'username', 'required');
$this->form_validation->set_rules('email', 'Email', 'required|callback_user_email_check');

$this->form_validation->set_rules('confirm_email', 'Confirm Email', 'required|matches[email]');

$this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
$this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required|matches[password]');
$this->form_validation->set_rules('age', 'age', 'required');
$this->form_validation->set_rules('gender', 'gender', 'required');
$this->form_validation->set_rules('find_us', 'find_us', 'required');



if ($this->form_validation->run() == FALSE) {
$data['page'] = 'register';

//$this->session->set_flashdata('success_msg', 'Fill all the fields properly....');

$this->load->view('header', $data);
$this->load->view('register', $data);
$this->load->view('footer', $data);

} else {
//Setting values for tabel columns
$rn = "SELECT LAST_INSERT_ID(id) as id From user order by id desc limit 1";
$fetch = $this->Admin_model->fetch_single_join($rn);

@$id = $fetch->id;

$user_id = "USR10" . ($id + 1);
$ip = $_SERVER['REMOTE_ADDR'];

$email=  $this->input->post('email');

// $ip = $_SERVER['REMOTE_ADDR'];
$name = $this->input->post('name');
$username = $this->input->post('username');
$password = $this->input->post('password');

$age=$this->input->post('age');
$gender=$this->input->post('gender');

$find_us=$this->input->post('find_us');

$date=date('Y-m-d');

$userdata = array(
'ip'=>$ip,
'user_id'=>$user_id,
'name' => $this->input->post('name'),
'username' => $this->input->post('username'),
'email' => $this->input->post('email'),  
'password' => base64_encode($this->input->post('password')),
 'age' => $this->input->post('age'),
'gender' => $this->input->post('gender'), 
'find_us'=>$this->input->post('find_us'), 
'user_points'=>5000,    
'status' =>'Active',
'date' => $date
);

$result1 = $this->Users_signup->register($userdata);

//echo $this->db->last_query();
//exit();


if ($result1 == TRUE) {


/**************mail*****************/

/*$htmlContent = "<table align='center' style='width:650px; text-align:center; background:#f7f7f7;'>
<tbody>
<tr style='height:50px;background-color:#1a1a1a;'><td valign='middle' style='color:white;'><img src='" . base_url() . "img/starflic.png' alt='Starflic' title='Starflic'  style='width:210px;height:130px' /></td></tr>
<tr>
<td valign='top' align='center' colspan='2'>
<table align='center' style='height:380px; color:#000; width:600px;'>
<tbody>
<tr>
<td style='width:8px;'>&nbsp;</td> 
<td align='center' style='font-size:28px;border-top:1px dashed #ccc;' colspan='3'>Hello, ". $name ."</td>
</tr>
<tr>
<td valign='top' align='center' colspan='2'>

<p>Thank you for registered with  us, Use The Details For Login</p><br><br>

<table align='center' style='color:#000; width:600px;'>
<tbody>


<tr align='center'><td><strong>EMAIL</strong>&nbsp;:&nbsp;$email</td></tr>

<tr align='center'><td><strong>PASSWORD</strong>&nbsp;:&nbsp;$password</td></tr>


</tbody>
</table>     


<a></a>
<br>
Sincerely,<br>
Starflic<br><br>
<strong>Email:</strong>starflic@gmail.com<br><br>

This is an automated response, please DO NOT reply.
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>";



$config['mailtype'] = 'html';

$this->email->initialize($config);

$this->email->to($email);
$this->email->from('starflic@gmail.com', 'Starflic');
$this->email->subject('Registered With Starflic');
$this->email->message($htmlContent);

$this->email->send();*/


/*                 * ************end mail**************** */

$data['message'] = 'Successfully Registered';
$this->session->set_flashdata('success_msg', 'Thankyou..!Successfully registered with us...');




}
//Loading View

$data['page'] = 'register';
$this->load->view('header', $data);
$this->load->view('register', $data);
$this->load->view('footer', $data);
}
}
else
{
   $data['page'] = 'register';
$this->load->view('header', $data);
$this->load->view('register', $data);
$this->load->view('footer', $data); 
    
    
}
}


public function user_email_check($email) {

$email = $email;
$fetch_row = $this->Admin_model->fetch_row('user', "email='$email'");
// echo $this->db->last_query();exit();




if (count($fetch_row)> 0) {
$this->form_validation->set_message('user_email_check', 'Email id already exists');

return FALSE;
}

return TRUE;
}




public function login()
{

$data['page'] = 'login';

 // echo 'outside';exit();

if ($this->input->post('submit') == 'submit') {
    
    
   
    
$this->form_validation->set_error_delimiters('<div class="error">', '</div>');

$this->form_validation->set_rules('username', 'username', 'trim|required');
$this->form_validation->set_rules('password', 'password', 'required');


if ($this->form_validation->run() == FALSE) {
    
//$this->load->view('Menu', $data);
//$this->load->view('studentlogin', $data);
//$this->load->view('Footer', $data);
       
} else {

$username = $this->input->post('username');
$password = base64_encode($this->input->post('password'));
$result = $this->Admin_model->fetch_single_join("SELECT * FROM user WHERE username='$username'  and password='$password' and status='Active'");



$where = "username='$username'";

$fetch = $this->Admin_model->fetch_row('user', $where);

if ($result == TRUE) {

$setdata = array(
'username' => $username,
'user_id' => $fetch->user_id,
'is_logged_in' => true

);

$this->session->set_userdata($setdata);
redirect(base_url() . 'User');

//$this->session->set_flashdata('success_msg', 'login successfully...');
//redirect(base_url() . 'login');


} else {

$this->session->set_flashdata('success_msg', 'Invalid Username or Password...');

redirect(base_url() . 'login');
}
}
}
$this->load->view('header', $data);
$this->load->view('login', $data);
$this->load->view('footer', $data);

}

public function checkout()
{

$page='register';
$data['page']=$page;

$this->load->view('header',$data);
$this->load->view('checkout',$data);

$this->load->view('footer',$data);

}

function forgetpassword() {

$data['page'] = 'forgetpassword';


$this->load->view('header', $data);
$this->load->view('forget-password', $data);
$this->load->view('footer', $data);


}





/************reset password function*************/

public function changepass()
    {
        $data['page'] = 'changepassword';
        //$encodeemail=$this->uri->segment(3);
        
        $encodeemail=$this->input->post('email');
         $email= urldecode(base64_decode($encodeemail));
      //  echo $email;
        if($this->input->post('submit')=='submit'){
            
            $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
            $this->form_validation->set_rules('new_pass', 'New Password', 'required|min_length[6]');
            $this->form_validation->set_rules('con_pass', 'Confirm Password', 'required|matches[new_pass]');
if ($this->form_validation->run() == FALSE) {
  
                   
                  $this->load->view('header', $data);
                $this->load->view('changepassword', $data);
                  $this->load->view('footer', $data);
                  
} else {
            
            $userdata = array('password' => base64_encode($this->input->post('new_pass')) );
            $where = "email='$email'";
            $result = $this->Admin_model->eidt_single_row('user', $userdata, $where);
            echo $this->db->last_query(); exit();
                if($result)
                {
                   $this->session->set_flashdata('success_msg', 'Reset Password Succesfully');
                   redirect(base_url().'login');
                }else{
                  $this->session->set_flashdata('success_msg', 'Password Not Reset');
                   redirect(base_url().'Index/changepass');
                }
}
        }else
        {
        
        $this->load->view('header', $data);
        $this->load->view('changepassword', $data);
        $this->load->view('footer', $data);
        }
    }





}
?>