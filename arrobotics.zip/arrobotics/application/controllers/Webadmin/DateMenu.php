<?php
defined('BASEPATH') OR exit('No Direct Script access allowed');

class DateMenu extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Webadmin/Admin_model');
                $this->load->helper("file");

                
	}
	
	public function index()
        {
            if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
            $page = 'weekly_menu';
            $data['page'] = $page;
            
            $fetch = $this->Admin_model->fetch_all('nsn_weekly_menu');
            $data['fetch'] = $fetch;
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/weekly_menu');
            $this->load->view('Webadmin/footer');
        }
	
        public function add_menu()
        {
            if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
            $page = 'weekly_menu';
            $data['page'] = $page;
            
            $image = "";
            if($this->input->post('submit') == 'Submit')
            {
                $title = $this->input->post('title');
              //  print_r($title);exit();
               // $description = $this->input->post('desc');
                
               foreach ($title as $key => $value) {
                   
               
                $field_data = array(
                        'MenuName' => addslashes($value),
                        //'Description' => addslashes($description),
                        );
                $result = $this->Admin_model->add_details('nsn_weekly_menu', $field_data);
               }
                
                
                if($result){
                    $succ = "Data Added Successfully";
                    $data['succ']=$succ;
                }
           }
            //$cms = $this->Cms_model->fetch_all();
            //$data['cms'] = $cms;
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/weekly_menu_details');
            $this->load->view('Webadmin/footer');
        }
        
        
        
        public function daily_special_menu()
        {   if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
            $page = 'daily_menu';
            $data['page'] = $page;
            
            $title = "Special Menu";
            $data['title']=$title;
            
            $day = date('l');
            $data['day'] = $day;
            $where = "MenuDate = '".date('Y-m-d')."'";
            $result = $this->Admin_model->fetch_row('nsn_special_menu', $where);
            if($result){
                $data['menulist'] = $result;
                
            }else {
                $result = $this->Admin_model->fetch_row('nsn_weekly_special_menu', "WeekDay='".$day."'");
                $data['menulist'] = $result;
            }
           $fetch = $this->Admin_model->fetch_all('nsn_menu');
           $data['fetch'] = $fetch;
            
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/daily_menu_list',$data);
            $this->load->view('Webadmin/footer');
        }
        
        public function daily_regular_menu()
        {   if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
            $page = 'daily_menu';
            $data['page'] = $page;
            
            $title = "Regular Menu";
            $data['title']=$title;
            
           $day = date('l');
            $data['day'] = $day;
            $where = "MenuDate = '".date('Y-m-d')."'";
            $result = $this->Admin_model->fetch_row('nsn_regular_menu', $where);
            if($result){
                $data['menulist'] = $result;
                
            }else {
                $result = $this->Admin_model->fetch_row('nsn_weekly_regular_menu', "WeekDay='".$day."'");
                $data['menulist'] = $result;
            }
           $fetch = $this->Admin_model->fetch_all('nsn_menu');
           $data['fetch'] = $fetch;
            
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/daily_menu_list',$data);
            $this->load->view('Webadmin/footer');
        }
       
        public function check_menu_list()
        {
            $date = $this->input->get('date');
            $type = $this->input->get('type');
            
            if($type == "Special Menu"){
                $tbl = "nsn_special_menu";
                $table = "nsn_weekly_special_menu";
            }else {
                $tbl = "nsn_regular_menu";
                $table = "nsn_weekly_regular_menu";
            }
           
            $day = date('l', strtotime($date));
            
            $where = "MenuDate = '".date('Y-m-d',strtotime($date))."'";
            
            $result = $this->Admin_model->fetch_row($tbl, $where);
            //echo $this->db->last_query();exit();
            $fetch = $this->Admin_model->fetch_all('nsn_menu');
            $data['fetch'] = $fetch;
            if($result)
            {
                
                
                $i=1;
                 //foreach($menulist as $list){
                     
                     $menus = explode(',',$result->MenuList);
                   
                 
               
                
             echo  '<input type="hidden" name="day" value="'.$day.'"> 
               <input type="hidden" name="id" value="'.$result->id.'">
                   <input type="hidden" name="date" value="'.date('Y-m-d',strtotime($date)).'">
                   <input type="hidden" name="type" value="'.$type.'">
                 <div class="panel widget">
                  <div class="panel-heading vd_bg-red">
                      <h3 class="panel-title" style="color: #FFF;"> <span class="menu-icon"> <i class="icon-pie"></i> </span>'.$day.' </h3>
                    <div class="vd_panel-menu">
                        <div data-action="minimize" data-original-title="Minimize" data-toggle="tooltip" data-placement="bottom" class=" menu entypo-icon"> <i class="icon-minus3"></i> </div>
                    </div>

 
                  </div>
                  <div class="panel-body">';
                    
                   
                    foreach($fetch as $fetchz)
                        {
                       
                       echo  '<label style="width: 23%;"> <input type="checkbox" name="menu[]"'; if(in_array($fetchz->id, $menus)){echo 'checked="checked"';} echo 'value="'.$fetchz->id.'">&nbsp;'. $fetchz->MenuName.'</label>';
                    }
                 echo '</div>
                </div>';
                    
                 
                   
                 echo '<div id="vd_login-error" class="alert alert-danger hidden"><i class="fa fa-exclamation-circle fa-fw"></i> Please fill the necessary field </div>
                  <div class="form-group">
                    
                    <div class="col-md-6 mgbt-xs-10 mgtp-20">
                     
                      <div class="mgtp-10">
                          <input class="btn vd_bg-green vd_white" type="submit" id="submit-register" name="submit" value="Submit">
                      </div>
                    </div>
                    <div class="col-md-12 mgbt-xs-5"> </div>
                  </div>';
                
            }else{
                
                $result = $this->Admin_model->fetch_row($table, "WeekDay='".$day."'");
                //echo $this->db->last_query();exit();
                     $menus = explode(',',$result->MenuList);
                     
                     
               
                
             echo  '<input type="hidden" name="day" value="'.$result->WeekDay.'"> 
               <input type="hidden" name="id" value="'.$result->id.'">
                    <input type="hidden" name="date" value="'.date('Y-m-d',strtotime($date)).'">
                   <input type="hidden" name="type" value="'.$type.'">
                 <div class="panel widget">
                  <div class="panel-heading vd_bg-red">
                      <h3 class="panel-title" style="color: #FFF;"> <span class="menu-icon"> <i class="icon-pie"></i> </span>'.$result->WeekDay.' </h3>
                    <div class="vd_panel-menu">
                        <div data-action="minimize" data-original-title="Minimize" data-toggle="tooltip" data-placement="bottom" class=" menu entypo-icon"> <i class="icon-minus3"></i> </div>
                    </div>

 
                  </div>
                  <div class="panel-body">';
                    
                   
                    foreach($fetch as $fetchz)
                        {
                       //print_r($menus);
                       echo  '<label style="width: 23%;"> <input type="checkbox" name="menu[]"'; if(in_array($fetchz->id, $menus)){echo 'checked="checked"';} echo 'value="'.$fetchz->id.'">&nbsp;'. $fetchz->MenuName.'</label>';
                    }
                 echo '</div>
                </div>';
                    
                 
                   
                 echo '<div id="vd_login-error" class="alert alert-danger hidden"><i class="fa fa-exclamation-circle fa-fw"></i> Please fill the necessary field </div>
                  <div class="form-group">
                    
                    <div class="col-md-6 mgbt-xs-10 mgtp-20">
                     
                      <div class="mgtp-10">
                          <input class="btn vd_bg-green vd_white" type="submit" id="submit-register" name="submit" value="Submit">
                      </div>
                    </div>
                    <div class="col-md-12 mgbt-xs-5"> </div>
                  </div>';
                
            }
        }
        
        
        
        public function edit_menulist()
        {   if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
            $page = 'daily_menu';
            $data['page'] = $page;
            
            $day = $this->input->post('day');
            $data['day'] = $day;
            
            $title = $this->input->post('type');
            
            $data['title']=$title;
           $date = $this->input->post('date');
            if($title == "Special Menu"){
                $tbl = "nsn_special_menu";
                $table = "nsn_weekly_spacial_menu";
            }else {
                $tbl = "nsn_regular_menu";
                $table = "nsn_weekly_regular_menu";
            }
            $title = $this->input->post('type');
            
            
             
            
            //$data['title']=$title;
            
            if($this->input->post('submit') == 'Submit')
            {
                
                    $menus = $this->input->post('menu');
                    $menu_list = @implode(',',$menus);
                    //print_r($menu_list);exit();
                    
                    //print_r($title);
                    $id = $this->input->post('id');
                    
                    
                    $fet = $this->Admin_model->fetch_row($tbl,"MenuDate='".$date."'");
                    if($fet){
                        $field_data = array(
                            'MenuList' => $menu_list
                            );
                        $result = $this->Admin_model->eidt_single_row($tbl, $field_data,"MenuDate='".$date."'");
                    }else{
                        $field_data1 = array(
                              'MenuList' => $menu_list,
                               'MenuDate' => $date
                                );
                        
                        $result = $this->Admin_model->add_details($tbl, $field_data1);
                    }
                   //echo $this->db->last_query();exit();
               
                if($result){
                    $succ = "Data Updated Successfully";
                    $data['succ']=$succ;
                    $menulist = $this->Admin_model->fetch_row($tbl,"MenuDate='".$date."'");
                    $data['menulist'] = $menulist;
                    
                    $fetch = $this->Admin_model->fetch_all('nsn_menu');
                    $data['fetch'] = $fetch;
                    
                }
           }
          
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/daily_menu_list',$data);
            $this->load->view('Webadmin/footer');
        }
        
        public function edit_regular_menu()
        {   if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
            $page = 'daily_menu';
            $data['page'] = $page;
            
            $title = "Regular Menu";
            $data['title']=$title;
            
            if($this->input->post('submit') == 'Submit')
            {
               
                    $menus = $this->input->post('menu');
                    $menu_list = @implode(',',$menus);
                    //print_r($menu_list);exit();
                    
                    //print_r($title);
                    $id = $this->input->post('id');
                    
                    $field_data = array(
                            'MenuList' => $menu_list
                            );
                    $result = $this->Admin_model->edit_details('nsn_regular_menu', $field_data,$id);
                   //echo $this->db->last_query();exit();
               
                if($result){
                    $succ = "Data Updated Successfully";
                    $data['succ']=$succ;
                    $menulist = $this->Admin_model->fetch_single('nsn_regular_menu');
                    $data['menulist'] = $menulist;
                    
                    $fetch = $this->Admin_model->fetch_all('nsn_menu');
                    $data['fetch'] = $fetch;
                    
                }
           }
           
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/daily_menu_list',$data);
            $this->load->view('Webadmin/footer');
        }
	//Start About-------------------------------------------------------------------------------------------
	function view_menu()
	{
            if(!$this->session->userdata('is_logged_in'))
            {
            redirect('Webadmin/Login');
            }
            $page = 'menu';
            $data['page'] = $page;
            
            $id = $this->uri->segment(4);
            $fetch = $this->Admin_model->fetch_single('nsn_menu', $id);
            $data['fetch'] = $fetch;
            
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/menu_details',$data);
            $this->load->view('Webadmin/footer');
	}
        
        public function delete_menu()
	{
            
           $id = $this->input->get('id', TRUE);
           
           $faq = $this->Admin_model->delete_single('nsn_menu', $id);
           if($faq){
               
                echo 'deleted';
           } 
            
	}
        
        public function change_status()
        {
            $tbl = $this->uri->segment(4);
            echo $tbl;exit();
            $id = $this->input->get('id', TRUE);
            $val = $this->input->get('val');
            $field_data = array(
                       'Status' => $val
                       );
            $result = $this->Admin_model->eidt_details('nsn_menu', $field_data,$id);
            if($result)
            {
                echo 'Status Changed';
            }
        }
//End About---------------------------------------------------------------------------------------------
	

	
}


?>