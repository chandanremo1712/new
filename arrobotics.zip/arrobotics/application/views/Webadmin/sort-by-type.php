<?php include 'config/connect.php';
$job_type = $_REQUEST['jobCategory'];
$job_type = implode(',', $job_type);

$job_loc = $_REQUEST['jobLocation'];
$job_loc = implode(',', $job_loc);

$job_cat = $_REQUEST['category'];
$job_cat = implode(',', $job_cat);


    $salary = $_REQUEST['sal']; 

 $minsal=$_REQUEST['minsal'];
 $maxsal=$_REQUEST['maxsal'];
        
?> 
<!--count total number of jobs starts-->
 

<div class="job_list" id="data_list">
<ul class="all_list">
                  	<?php
                   
                        
                        
$ctn = 1;

$where = "job_status = 'ACTIVE'";
if($job_type!="")
{
   $where .= " AND job_type IN ($job_type)"; 
}

/*for job location*/
if($job_loc=='993')
{
    
  $where .= " AND job_location between 993 and 1002"; 
}
elseif($job_loc=='1003')
{
     
 $where .= " AND job_location between 1003 and  1009";
}
elseif($job_loc=='1010')
{
    
 $where .= " AND job_location between 1010 and  1037";
}
elseif($job_loc=='1038')
{
     
  $where .= " AND job_location between 1038 and  1047";
}
elseif($job_loc=='1047')
{
     
  $where .= " AND job_location between 1047 and  1054";
}
elseif($job_loc=='1054')
{
    
  $where .= " AND job_location between  1054 and  1080";
}
elseif($job_loc=='1080')
{
    
 $where .= " AND job_location between  1080 and  1112";
}
elseif($job_loc=='1112')
{
    
 $where .= " AND job_location between  1112 and  1124";
}
elseif($job_loc=='1124')
{
    
   $where .= " AND job_location between  1124 and  1136";
}
elseif($job_loc=='1136')
{
     
   $where .= " AND job_location between  1136 and  1160";
}
elseif($job_loc=='1160')
{
     
 $where .= " AND job_location between  1160 and  1172";
}
elseif($job_loc=='1172')
{
    
 $where .= " AND job_location between  1172 and  1179";
}

elseif($job_loc != "")
{
    $where .= " AND job_location IN ($job_loc)"; 
}
/*for job location ends */








if($job_cat != "")
{
    $where .= " AND job_category IN ($job_cat)"; 
}
if($salary!= "")
{
   $where .=" AND job_salary_per='$salary'"; 
}  
if($minsal!="" && $maxsal!="")
{
    $where .=" AND job_salary_from>= $minsal AND job_salary_to<=$maxsal";
}



     $GetUserSql = "SELECT * FROM job_vacancy WHERE $where ORDER BY job_auto_id DESC ";  


 $GetQuery = mysql_query($GetUserSql) or die(mysql_error());
  $num_value=  mysql_num_rows($GetQuery);
if($num_value>0)
{
while($rowdest = mysql_fetch_array($GetQuery))
{ 
          //-------------------image view-------------------//
  if ($rowdest['job_recruiter_id'] == "admin" && $rowdest['job_company_image'] != "") {

        $pic = "Banner/extbig/" . $rowdest['job_company_image'];
    } elseif ($rowdest['job_recruiter_id'] == "Broadbean" && $rowdest['job_company_image'] != "") {
        $a = $rowdest['job_company_image'];
        $pic = "$a";
    }
    elseif ($rowdest['job_recruiter_id'] != "Broadbean" && $rowdest['job_recruiter_id'] != "admin" ) 
        {
        if($rowdest['job_company_image'] != "")
        {
            
          $pic = "Banner/extbig/" . $rowdest['job_company_image'];
        
        }
        else{
        
        $fetch_image = mysql_fetch_array(mysql_query("select image from recruiter where recruiter_id='" . $rowdest['job_recruiter_id'] . "'"));

        if ($fetch_image['image'] == "") {
            $pic = "images/nopic.jpg";
        } else if (!is_file("Banner/medium/" . $fetch_image['image'])) {
            $pic = "images/nopic.jpg";
        } else {
            $pic = "Banner/medium/" . $fetch_image['image'];
        }
        }
        
        
    } else {
        $pic = "images/nopic.jpg";
    }

?>   
                  
             <li class="wow">
                  <div class="row">
                    <div class="col-sm-3 col-xs-12">
                      <div class="company_logo"> <img src="<?=$pic?>" class="img-responsive" > </div>
                    </div>
                    <div class="col-sm-6 col-xs-12">
<!--                      <h3 class="jobtitle"><a class="jobTitleLink" href="details.php?id=<?php echo $rowdest['job_auto_id']?>" title="Social Worker - Family Intervention 0"><?=$rowdest['job_title'];?></a></h3>-->
                        <h3 class="jobtitle"><a class="jobTitleLink" href="details.php?job_auto_id=<?php echo $rowdest['job_auto_id']?>" title="Social Worker - Family Intervention 0"><?=$rowdest['job_title'];?></a></h3>
                        <p><?=substr(stripslashes(strip_tags($rowdest['job_description'])),0,160);?></p>
                    </div>
                    <div class="col-sm-3 col-xs-12">
                        <?php
                        $sql_job=mysql_query("select * from job_type where id='".$rowdest['job_type']."'");
                        $job=mysql_fetch_array($sql_job);
                        ?>
                      <div class="about_job"> <a href="javascript:void(0);"><i class="fa fa-briefcase" aria-hidden="true"></i><?=$job['job_type'];?></a> 
                         <?php
                         $sql_loc=mysql_query("select * from job_location where id='".$rowdest['job_location']."'");
                         $location=  mysql_fetch_array($sql_loc);
                         ?>
                          
                          <a href="javascript:void(0);"><i class="fa fa-map-marker"></i><?=$location['name'];?></a>
                          
                          
                          <?php
                          $sql_query=mysql_query("select * from job_salary_currency where id='".$rowdest[job_salary_currency]."'");
                          $sql_result=  mysql_fetch_array($sql_query)
                          ?>
                          <a href="javascript:void(0);"><i class="fa fa-money" aria-hidden="true"></i><?=$sql_result['symbol'];?> <?=$rowdest['job_salary_from'];?>-<?=$rowdest['job_salary_to'];?></a> </div>
                          
                      <span class="n_tag">New</span> </div>
                  </div>
                </li>
<?php } }
 else
{
     echo '<li align="center"><font size="5"><i>No job found</i></font></li>';
     //echo '<li style="text-align:center;"><font size="5"><i>No job found</i></font></li>';
    // break;
}
                                                                        
                                                                        
                                                                
                                                                        
                                                                        ?>
                

              </ul>
     </div>                
                                                                  
             