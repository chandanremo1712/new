<?php

$about=$this->Admin_model->fetch_single('about','1');
$social=$this->Admin_model->fetch_single('nsn_social','1');

?>


<footer id="footer" class="footer bg-black-222" data-bg-img="<?=base_url()?>images/footer-bg.png">
<div class="container pt-70 pb-40">
<div class="row">
<div class="col-sm-6 col-md-3">
<div class="widget dark">
<img class="mt-10 mb-15" alt="" src="<?=base_url()?>images/logo.png" style="height:80px;">
<p class="font-16 mb-10"><?=substr($about->description,0,150)?>.</p>
<a class="font-14" href="<?=base_url()?>about"><i class="fa fa-angle-double-right text-theme-colored"></i> Read more</a>
<ul class="styled-icons icon-dark mt-20">
    
<li class="wow fadeInLeft" data-wow-duration="1.5s" data-wow-delay=".1s" data-wow-offset="10">
    <a href="<?=$social->facebook?>" target="_blank" data-bg-color="#3B5998"><i class="fa fa-facebook"></i></a></li>

<li class="wow fadeInLeft" data-wow-duration="1.5s" data-wow-delay=".2s" data-wow-offset="10">
    <a href="<?=$social->twitter?>" target="_blank" data-bg-color="#02B0E8"><i class="fa fa-twitter"></i></a></li>

<li class="wow fadeInLeft" data-wow-duration="1.5s" data-wow-delay=".4s" data-wow-offset="10">
    <a href="<?=$social->google_plus?>" target="_blank" data-bg-color="#A11312"><i class="fa fa-google-plus"></i></a></li>

<li class="wow fadeInLeft" data-wow-duration="1.5s" data-wow-delay=".5s" data-wow-offset="10">
    <a href="<?=$social->linkedin?>" target="_blank" data-bg-color="#C22E2A"><i class="fa fa-linkedin"></i></a></li>

</ul>
</div>
</div>
    
    
<div class="col-sm-6 col-md-3">
<div class="widget dark">
<h5 class="widget-title line-bottom">Latest Blog</h5>
<div class="latest-posts">
<?php
$news=$this->Admin_model->fetch_all_join("select * from nsn_news where Status='Yes' order by id desc limit 4");
foreach($news as $newsz){
    
       
if($newsz->NewsImage!='')
{
    $pic=base_url().'News/'.$newsz->NewsImage;
}
else{
    $pic=base_url().'News/noimg.png';
}
?>
    
<article class="post media-post clearfix pb-0 mb-10">
<a href="<?=base_url()?>newsdetails/<?=$newsz->id?>" class="post-thumb"><img alt="" src="<?=$pic?>" style="height:50px;"></a>
<div class="post-right">
<h5 class="post-title mt-0 mb-5"><a href="<?=base_url()?>newsdetails/<?=$newsz->id?>"><?=$newsz->NewsTitle?></a></h5>
<p class="post-date mb-0 font-12"><?php echo date("j M y", strtotime($newsz->NewsDate));?></p>
</div>
</article>
    
 <?php } ?>   

</div>
</div>
</div>
    
    
    
    
<div class="col-sm-6 col-md-3">
<div class="widget dark">
<h5 class="widget-title line-bottom">Useful Links</h5>
<ul class="list angle-double-right list-border">
<li><a href="#">Privacy Policy</a></li>
<li><a href="#">Donor Privacy Policy</a></li>
<li><a href="#">Disclaimer</a></li>
<li><a href="#">Terms of Use</a></li>
<li><a href="#">Media Center</a></li>
</ul>
</div>
</div>
    

  <?php
$info=$this->Admin_model->fetch_single_join("select * from nsn_contact where id=1");

?>     
    
    
<div class="col-sm-6 col-md-3">
<div class="widget dark">
<h5 class="widget-title line-bottom">Quick Contact</h5>
<ul class="list-border">
<li><a href="#"><?=$info->phone?></a></li>
<li><a href="#"><?=$info->email?></a></li>
<li><a href="#" class="lineheight-20">
      <?=$info->address?>
    </a></li>
</ul>



<p class="font-16 text-white mb-5 mt-15">Subscribe to our newsletter</p>
<form id="footer-mailchimp-subscription-form" class="newsletter-form mt-10">
<label class="display-block" for="mce-EMAIL"></label>
<div class="input-group">
<input type="email" value="" name="EMAIL" placeholder="Your Email"  class="form-control" data-height="37px" id="mce-EMAIL">
<span class="input-group-btn">
<button type="submit" class="btn btn-colored btn-theme-colored m-0"><i class="fa fa-paper-plane-o text-white"></i></button>
</span>
</div>
</form>

<!-- Mailchimp Subscription Form Validation-->
<script type="text/javascript">
$('#footer-mailchimp-subscription-form').ajaxChimp({
callback: mailChimpCallBack,
url: '//thememascot.us9.list-manage.com/subscribe/post?u=a01f440178e35febc8cf4e51f&amp;id=49d6d30e1e'
});

function mailChimpCallBack(resp) {
// Hide any previous response text
var $mailchimpform = $('#footer-mailchimp-subscription-form'),
$response = '';
$mailchimpform.children(".alert").remove();
if (resp.result === 'success') {
$response = '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' + resp.msg + '</div>';
} else if (resp.result === 'error') {
$response = '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' + resp.msg + '</div>';
}
$mailchimpform.prepend($response);
}
</script>
</div>
</div>
</div>
</div>
<div class="footer-bottom bg-black-333">
<div class="container pt-20 pb-20">
<div class="row">
<div class="col-md-6">
<p class="font-11 text-black-777 m-0">Copyright &copy;<?php echo date('Y');?> ArRobotics. All Rights Reserved</p>
</div>
<div class="col-md-6 text-right">
<div class="widget no-border m-0">
<ul class="list-inline sm-text-center mt-5 font-12">
<li>
<a href="#">FAQ</a>
</li>
<li>|</li>
<li>
<a href="#">Help Desk</a>
</li>
<li>|</li>
<li>
<a href="#">Support</a>
</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</footer>
<a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>
<!-- end wrapper --> 

<!-- Footer Scripts --> 
<!-- JS | Custom script for all pages --> 
<script src="<?=base_url()?>js/custom.js"></script>


<script type="text/javascript" src="<?=base_url()?>js/revolution-slider/js/extensions/revolution.extension.actions.min.js"></script> 
<script type="text/javascript" src="<?=base_url()?>js/revolution-slider/js/extensions/revolution.extension.carousel.min.js"></script> 
<script type="text/javascript" src="<?=base_url()?>js/revolution-slider/js/extensions/revolution.extension.kenburn.min.js"></script> 
<script type="text/javascript" src="<?=base_url()?>js/revolution-slider/js/extensions/revolution.extension.layeranimation.min.js"></script> 
<script type="text/javascript" src="<?=base_url()?>js/revolution-slider/js/extensions/revolution.extension.migration.min.js"></script> 
<script type="text/javascript" src="<?=base_url()?>js/revolution-slider/js/extensions/revolution.extension.navigation.min.js"></script> 
<script type="text/javascript" src="<?=base_url()?>js/revolution-slider/js/extensions/revolution.extension.parallax.min.js"></script> 
<script type="text/javascript" src="<?=base_url()?>js/revolution-slider/js/extensions/revolution.extension.slideanims.min.js"></script> 
<script type="text/javascript" src="<?=base_url()?>js/revolution-slider/js/extensions/revolution.extension.video.min.js"></script>


<script src="<?=base_url()?>js/upload.js"></script>
<script src="<?=base_url()?>js/jquery.form.js"></script>
<!--image upload ends--> 
    <script>
            
         function uploadProfle()
        {
          //  alert(1);
         
		$('#upload-image').ajaxForm({
			target:'#profile_image',
                        beforeSend:function(e){
				//alert(1);
                                 
                                      $("#loader").show();
			},
			success:function(e){
                           // alert(e);
                            
                            //$('#prof_img').html(e);
                            
                             $('#old_img').val("");
                            $("#loader").hide();
                           // window.location.reload();
                            
                           // $('#profile_image').html(e);
			},
			error:function(e){
                            
			}
		}).submit();
	
        }
   
        </script>

<script>
        function getproductid(id)
    {
      
                  
                  //  $('.portlet .tools a.reload').click();
                    $.ajax({
                        type:"GET",
                        url:"<?php echo base_url();?>User/addtocart/",
                        data:"id="+id,
                        success:function(data)
                        {
                                                      
                         window.location.reload();
                         
                        }
                    });
		
    }
    
    function deletecart(id)
    {
        //alert(id);
        cnf = confirm("Are you confirm to delete?");
        if(cnf)
		{
                  
                    $('.portlet .tools a.reload').click();
                    $.ajax({
                        type:"GET",
                        url:"<?php echo base_url();?>User/Deletecart",
                        data:"id="+id,
                        success:function(data)
                        {
                            
                            window.location.reload();
                            
                           
                                                      

                               // $('#blog'+id).css('display', 'none');

                        }
                    });
			
		}
    }

    
    </script>


<script>
$(document).ready(function(){
$("#msg").delay(8000).fadeOut();
});
</script>

  <script>
        function deleteoneorder(id)
{
 alert(id);
cnf = confirm("Are you confirm to delete?");
if(cnf)
{

//$('.portlet .tools a.reload').click();
$.ajax({
type:"GET",
url:"<?php echo base_url();?>User/delete_user_order/",
data:"id="+id,
success:function(data)
{
window.location.reload();

   // alert(data);
 }
}

    );
}
}
 
        
           function changeorderstatus(val,id)
    {
        //alert(id);
          cnf = confirm("Are you confirm to change order status?");
        if(cnf)
		{
        $.ajax({
            type:"GET",
            url:"<?php echo base_url();?>User/change_order_status",
            data:"id="+id+"&val="+val,
            success:function(data)
            {
               alert(data);
            }
        });
        
        }
			
    }
    </script>


</body>
</html>