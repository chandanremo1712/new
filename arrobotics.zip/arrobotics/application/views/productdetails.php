
<!-- Start main-content -->
<div class="main-content">

<!-- Section: inner-header -->
<section class="inner-header divider parallax layer-overlay overlay-dark-5" data-bg-img="<?=base_url()?>images/bg/bg3.jpg">
<div class="container pt-70 pb-20">
<!-- Section Content -->
<div class="section-content">
<div class="row">
<div class="col-md-12">
<h2 class="title text-white text-center">Product Details</h2>
<ol class="breadcrumb text-left text-black mt-10">
<li><a href="#">Home</a></li>
<!--<li><a href="#">Pages</a></li>-->
<li class="active text-gray-silver">Product Details</li>
</ol>
</div>
</div>
</div>
</div>
</section>

<section>
<div class="container">
<div class="section-content">

<div class="row">

<?php

$id= base64_decode($this->uri->segment(2));    
$product=$this->Admin_model->fetch_single_join("select * from nsn_product where Id='$id'");

if($product->image != "")
$pic = base_url().'Banner/'.$product->image;
else
$pic =  base_url()."Banner/noimg.png";

?>



<div class="product">
<span style="color:green;font-size:20px;" id="msg"> <i><?php echo $this->session->flashdata('success_msg'); ?></i></span>
<div class="col-md-5">
<div class="product-image">
<div class="zoom-gallery">
<a href="<?=$pic?>" title="<?=$product->title?>">
<img src="<?=$pic?>" alt=""></a>
</div>
</div>
</div>

<div class="col-md-7">
<div class="product-summary">
<h2 class="product-title"><?=$product->title?></h2>
<div class="price">

<ins><span class="amount">$<?=$product->price?></span></ins> 

</div>


<div class="short-description">
<?=$product->description?>
</div>
<?php
$cat=$this->Admin_model->fetch_single_join("select * from category where id='$product->category'");

?>

<div class="category"><strong>Category:</strong> <a href="javascript:void(0);"><?=$cat->category?></a></div>
<div class="cart-form-wrapper mt-30">

<form method="post" action="<?=base_url()?>User/movetocart" class="cart">

<input type="hidden" value="<?=$id?>" name="product_id">

<table class="table variations no-border">
<tbody>

<tr>
<td class="name">Quantity</td>
<td class="value">
<div class="quantity buttons_added">
<input type="button" class="minus" value="-">
<input type="number" id="qty" size="4" class="input-text qty text" title="Qty" value="1" name="quantity" min="1" step="1">
<input type="button" class="plus" value="+">
</div>
</td>
</tr>

</tbody>
</table>
<button class="single_add_to_cart_button btn btn-theme-colored" type="submit" >Add to cart</button>
</form>  
</div>
</div>
</div>    
</div>


<div class="col-md-12">
<h3 class="line-bottom">Related Products</h3>
<div class="row multi-row-clearfix">
<div class="products related">

<?php
$product=$this->Admin_model->fetch_all_join("select * from nsn_product where Status='Yes' and category='$cat->id' order by Id desc limit 4");
foreach($product as $productz){

if($productz->image != "")
$pic = base_url().'Banner/'.$productz->image;
else
$pic =  base_url()."Banner/noimg.png";

?>   

<div class="col-sm-6 col-md-3 col-lg-3 mb-sm-30">   
<div class="product">


<?php
if($productz->deals=='Yes'){
?>

<span class="tag-sale">Sale!</span>
<?php } else { ?>

<?php } ?>


<div class="product-thumb"> 
<img alt="" src="<?=$pic?>" class="img-responsive img-fullwidth" style="height:250px;">
<div class="overlay">
<!--<div class="btn-add-to-cart-wrapper">
<a class="btn btn-theme-colored btn-sm btn-flat pl-20 pr-20 btn-add-to-cart text-uppercase font-weight-700" href="#">Add To Cart</a>
</div>-->
<div class="btn-product-view-details">
<a class="btn btn-default btn-theme-colored btn-sm btn-flat pl-20 pr-20 btn-add-to-cart text-uppercase font-weight-700" href="<?=base_url()?>productdetails/<?= base64_encode($productz->Id)?>">View detail</a>
</div>
</div>
</div>
<div class="product-details text-center">
<a href="<?=base_url()?>productdetails/<?= base64_encode($productz->Id)?>"><h5 class="product-title"><?=$productz->title?></h5></a>

<div class="price">
    
<!--<del><span class="amount">$165.00</span> </del>-->
    
<ins><span class="amount">$<?=$productz->price?></span></ins>
</div>

</div>
</div>
</div>

<?php } ?> 


</div>
</div>
</div>
</div>
</div>
</div>
</section>
</div>
<!-- end main-content -->
