<?php
defined('BASEPATH') OR exit('No Direct Script access allowed');

class Weoffer extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Webadmin/Job_model');
                $this->load->model('Webadmin/Admin_model');
                $this->load->helper("file");

                
	}
	
	public function index()
        {
            if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
            $page = 'offer';
            $data['page'] = $page;
            
            $cms = $this->Admin_model->fetch_all('offer');
            $data['cms'] = $cms;
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/offer');
            $this->load->view('Webadmin/footer');
        }
	
        public function add_job()
        {
            if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
             $page = 'offer';
            $data['page'] = $page;
            
            $image = "";
            if($this->input->post('submit') == 'Submit')
            {
                $job_id=$this->input->post('job_id');
                $title = $this->input->post('title');
                
                $desc = $this->input->post('desc');
                
               // $meta_description = $this->input->post('meta_description');
               // $meta_keywords = $this->input->post('meta_keywords');
                
                //$old_image = $this->input->post('old_img');
                $config['upload_path']   = './CMS/'; 
                $config['allowed_types'] = 'gif|jpg|png'; 
                $config['max_size']      = 2048; 
                $config['max_width']     = 3000; 
                $config['max_height']    = 2000;  
                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('file')) {
                   $error = array('error' => $this->upload->display_errors()); 

                }

                else { 
                   $file_data = $this->upload->data(); 
                   $image = $file_data['file_name'];
                     


                } 
                $date=date('y-m-d');
                $field_data = array(
                        'job_id' => $job_id,
                        'jobtitle' => $title,
                    'job_description' =>$desc,
                    'date' =>$date,
                        'status' => 'Active'
                        );
                
                $result = $this->Job_model->add_cms($field_data);
                
              //  echo $this->db->last_query();
                
                if($result){
                    $succ = "Data Added Successfully";
                    $data['succ']=$succ;
                }
           }
            //$cms = $this->Job_model->fetch_all();
            //$data['cms'] = $cms;
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/job_details');
            $this->load->view('Webadmin/footer');
        }
        
        
        
        public function edit_offer()
        {  
            if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
             $page = 'offer';
            $data['page'] = $page;
            
             // $data['statelist']=  $this->Admin_model->fetch_all('state');
            
            if($this->input->post('submit') == 'Submit')
            {
                
                $id = $this->input->post('id');
                 
                $title = $this->input->post('title');
                $price=$this->input->post('price');
                $description = $this->input->post('description');
   
                $field_data = array(
                    'id' =>$id,
                        'title' => $title,
                    'price'=>$price,
                        'description' => $description,
                     
                        );
                $result = $this->Admin_model->eidt_details("offer",$field_data,$id);
                if($result){
                    $succ = "Data Updated Successfully";
                    $data['succ']=$succ;
                    $cms = $this->Admin_model->fetch_single("offer",$id);
                    $data['cms'] = $cms;
                    //var_dump($data);exit();
                }
           }else{
            
                $id = $this->uri->segment(4);
                $cms = $this->Admin_model->fetch_single("offer",$id);
                $data['cms'] = $cms;
            
           }
            
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/offer_details',$data);
            $this->load->view('Webadmin/footer');
        }
        
        
	//Start About-------------------------------------------------------------------------------------------
	function view_job()
	{
            if(!$this->session->userdata('is_logged_in'))
            {
                redirect('Webadmin/Login');
            }
            $page = 'job';
            $data['page'] = $page;
            
            $id = $this->uri->segment(4);
            $cms = $this->Job_model->fetch_single($id);
            $data['cms'] = $cms;
            
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/job_details',$data);
            $this->load->view('Webadmin/footer');
	}
        
        public function delete_job()
	{
            
           $id = $this->input->get('id', TRUE);
            $fetch = $this->Job_model->fetch_single($id);
            if($fetch->cmsimg != "")
                unlink('./CMS/'.$fetch->cmsimg);
            $cms = $this->Job_model->delete_single($id);
            
            if($cms){
                echo 'deleted';
            }
            
	}
}
?>