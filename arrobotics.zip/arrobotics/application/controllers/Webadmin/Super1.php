<?php
defined('BASEPATH') OR exit('No Direct Script access allowed');

class Super extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Webadmin/Admin_model');
                $this->load->helper("file");

                
	}
	
	
        public function delete_faq()
	{
            
           $id = $this->input->get('id', TRUE);
           
           $faq = $this->Admin_model->delete_single('nsn_faq', $id);
           if($faq){
               
                echo 'deleted';
           } 
            
	}
        
        public function change_status()
        {
            $tbl = $this->uri->segment(4);
            
            $id = $this->input->get('id', TRUE);
            $val = $this->input->get('val');
            $field_data = array(
                       'Status' => $val
                       );
            $result = $this->Admin_model->eidt_details($tbl, $field_data,$id);
            if($result)
            {
                echo 'Status Changed';
            }
        }
        
        public function change_status1()
        {
            $tbl = $this->uri->segment(4);
            
            $id = $this->input->get('id', TRUE);
            $val = $this->input->get('val');
            $field_data = array(
                       'Status' => $val
                       );
            $result = $this->Admin_model->eidt_details1($tbl, $field_data,$id);
            if($result)
            {
                echo 'Status Changed';
            }
        }
//End About---------------------------------------------------------------------------------------------
	

	
}


?>