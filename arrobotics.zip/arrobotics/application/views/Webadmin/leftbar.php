<style>
   .badge1 {
   position:relative;
}
.badge1[data-badge]:after {
    content: attr(data-badge);
    position: absolute;
    top: -26px;
    right: -10px;
    font-size: 1.7em;
    background: #f13308;
    color: white;
    width: 33px;
    height: 31px;
    text-align: center;
    line-height: 27px;
    border-radius: 52%;
    box-shadow: 0 0 1px #333;
}
</style>


<div class="navbar-menu clearfix">
<div class="vd_panel-menu hidden-xs">
<span data-original-title="Expand All" data-toggle="tooltip" data-placement="bottom" data-action="expand-all" class="menu" data-intro="<strong>Expand Button</strong><br/>To expand all menu on left navigation menu." data-step=4 >
<i class="fa fa-sort-amount-asc"></i>
</span>                   
</div>
<h3 class="menu-title hide-nav-medium hide-nav-small">Admin Features</h3>
<div class="vd_menu">
<ul>
    
<li <?php if($page == 'home'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Login/Dashboard">
<span class="menu-icon"><i class="fa fa-dashboard"></i></span> 
<span class="menu-text">Dashboard</span>  
<!--<span class="menu-badge"><span class="badge vd_bg-black-30"><i class="fa fa-angle-down"></i></span></span>-->
</a>
</li>  


<!--<li <?php if(@$page_type == 'user'){echo 'class="active"';}?>>
<a href="javascript:void(0);" data-action="click-trigger <?php  if(@$page_type == 'user'){echo 'class="open"';}?>" >
<span class="menu-icon"><i class="fa fa-users"></i></span> 
<span class="menu-text">User Mgmt</span>  
<span class="menu-badge"><span class="badge vd_bg-black-30"><i class="fa fa-angle-down"></i></span></span>
</a>
<div class="child-menu"  data-action="click-target" style="<?php  if(@$page_type == 'user'){echo 'display:block';}?>">
<ul>
<li <?php if($page == 'tutor'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Tutor">
<span class="menu-text">Tutor</span>  
</a>
</li> 

<li <?php if($page == 'student'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Student">
<span class="menu-text">Student</span>  
</a>
</li> 
</ul>   
</div>
</li>-->



<li <?php if(@$page_type == 'user'){echo 'class="active"';}?>>
<a href="javascript:void(0);" data-action="click-trigger <?php  if(@$page_type == 'user'){echo 'class="open"';}?>" >
    <span class="menu-icon"><i class="fa fa-users"></i></span> 
    <span class="menu-text">User Mgmt</span>  
    <span class="menu-badge"><span class="badge vd_bg-black-30"><i class="fa fa-angle-down"></i></span></span>
</a>
<div class="child-menu"  data-action="click-target" style="<?php  if(@$page_type == 'user'){echo 'display:block';}?>">
<ul>
    <li <?php if($page == 'tutor'){echo 'class="active"';}?>>
        <a href="<?php echo base_url();?>Webadmin/User">
            <span class="menu-text">User</span>  
        </a>
    </li> 

    
</ul>   
</div>
</li>

<!-- <li <?php if($page == 'menu'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Menu/">
<span class="menu-icon"><i class="fa fa-sliders"></i></span> 
<span class="menu-text">Menu Mgmt</span>  
</a> 
</li>-->


<!--<li <?php if($page == 'notify'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Notification/">
<span class="menu-icon"><i class="fa fa-sliders"></i></span> 
<span class="menu-text">Notification Mgmt</span>  
</a> 
</li>-->

<!--<li <?php if($page == 'tag'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Tags/">
<span class="menu-icon"><i class="fa fa-sliders"></i></span> 
<span class="menu-text">Meta Tags Mgmt</span>  
</a> 
</li>-->

<li <?php if($page == 'banner'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Banner/">
<span class="menu-icon"><i class="fa fa-sliders"></i></span> 
<span class="menu-text">Banner Mgmt</span>  
</a> 
</li>


<li <?php if($page == 'about'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Dashboard/About">
<span class="menu-icon"><i class="fa fa-sliders"></i></span> 
<span class="menu-text">About Page</span>  
</a> 
</li>


<li <?php if($page == 'gallery'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Gallery/">
<span class="menu-icon"><i class="fa fa-sliders"></i></span> 
<span class="menu-text">Gallery Mgmt</span>  
</a> 
</li> 

<li <?php if($page == 'course'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Courses/">
<span class="menu-icon"><i class="fa fa-sliders"></i></span> 
<span class="menu-text">Service Mgmt</span>  
</a> 
</li>

<li <?php if($page == 'category'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Category">
<span class="menu-icon"><i class="fa fa-sliders"></i></span> 
<span class="menu-text">Product Category</span>  

</a> 
</li>

<li <?php if($page == 'product'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Product">
<span class="menu-icon"><i class="fa fa-sliders"></i></span> 
<span class="menu-text">Product List</span>  
</a> 
</li>



<!--
<li <?php if($page=='servicearea'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Contacteduser/servicelist">
<span class="menu-icon"><i class="fa fa-bookmark"></i></span> 
<span class="menu-text">Service Area List</span>  

</a> 
</li>-->


<!--<li <?php if(@$page_type == 'orderlist'){echo 'class="active"';}?>>
<a href="javascript:void(0);" data-action="click-trigger <?php  if(@$page_type == 'settings'){echo 'class="open"';}?>" >
<span class="menu-icon"><i class="fa fa-sort-amount-asc"></i></span> 
<span class="menu-text">Order List</span>  
<span class="menu-badge"><span class="badge vd_bg-black-30"><i class="fa fa-angle-down"></i></span></span>
</a>
<div class="child-menu"  data-action="click-target" style="<?php  if(@$page_type == 'settings'){echo 'display:block';}?>">
<ul>
<li <?php if($page == 'orderlist'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Contacteduser/orderlist">
<span class="menu-text">Order List</span>  
</a>
</li> 
<li <?php if($page == 'orderlist'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Contacteduser/notassignlist">
<span class="menu-text">Not Assign to Service Outlets</span>  
</a>
</li> 
<li <?php if($page == 'orderlist'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Contacteduser/assignlist">
<span class="menu-text">Assign to Service Outlets</span>  
</a>
</li> 


</ul>   
</div>
</li>-->



<!--<li <?php if($page == 'banner'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Banner/">
<span class="menu-icon"><i class="fa fa-sliders"></i></span> 
<span class="menu-text">Banner Mgmt</span>  

</a> 
</li>-->


<!--<li <?php if($page == 'offer'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Weoffer">
<span class="menu-icon"><i class="fa fa-sliders"></i></span> 
<span class="menu-text">Our Pricing</span>  

</a> 
</li>-->


<!-- <li <?php if($page == 'cat'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Dashboard/Category">
<span class="menu-icon"><i class="fa fa-calendar"></i></span> 
<span class="menu-text">Blog Category</span>  
</a> 
</li>-->


<!--<li <?php if($page == 'blog'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Blog/">
<span class="menu-icon"><i class="fa fa-sliders"></i></span> 
<span class="menu-text">Blog Mgmt</span>  
</a> 
</li>-->


<!--<li <?php if($page == 'job'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Job/">
<span class="menu-icon"><i class="fa fa-envelope"></i></span> 
<span class="menu-text">Job Mgmt</span>  
</a> 
</li> -->

<li <?php if($page == 'team'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Team/">
<span class="menu-icon"><i class="fa fa-sliders"></i></span> 
<span class="menu-text">Team Mgmt</span>  
</a> 
</li>

<?php
$career_count=$this->Admin_model->fetch_all_join("select * from career where view='No'");

$get_career=count($career_count);

?>

<!--<li <?php if($page == 'career'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Career/">
<span class="menu-icon"><i class="fa fa-sliders"></i></span> 
<span class="menu-text">Career <div class="badge1" data-badge="<?=$get_career?>"></div></span>  
</a> 
</li>-->

<!--<li <?php if($page == 'partner'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Partner/">
<span class="menu-icon"><i class="fa fa-sliders"></i></span> 
<span class="menu-text">Partner</span>  
</a> 
</li>-->


<!--<li <?php if($page == 'client'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Client/">
<span class="menu-icon"><i class="fa fa-sliders"></i></span> 
<span class="menu-text">Our Clients</span>  
</a> 
</li>-->

<!--<li <?php if($page =='company'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Dashboard/Company">
<span class="menu-icon"><i class="fa fa-sliders"></i></span> 
<span class="menu-text">Company</span>  
</a> 
</li>-->




<li <?php if($page == 'news'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/News/">
<span class="menu-icon"><i class="fa fa-sliders"></i></span> 
<span class="menu-text">News Mgmt</span>  

</a> 
</li>  


<li <?php if($page == 'cms'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Cms/">
<span class="menu-icon"><i class="fa fa-envelope"></i></span> 
<span class="menu-text">Testimonial</span>  

</a> 
</li> 

<!--<li <?php if($page == 'quickmessage'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Contacteduser/quickmessage">
<span class="menu-icon"><i class="fa fa-calendar"></i></span> 
<span class="menu-text">Quick Message List</span>  

</a> 
</li>-->
<?php
$contacteduser_count=$this->Admin_model->fetch_all_join("select * from contact where view='No'");

$get_user=count($contacteduser_count);

?>

<li <?php if($page == 'contacteduser'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Contacteduser">
<span class="menu-icon"><i class="fa fa-users"></i></span> 
<span class="menu-text">Contacted User<div class="badge1" data-badge="<?=$get_user?>"></div></span>  

</a> 
</li>

<!--
<li <?php if($page =='subscribeuser'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Contacteduser/subscriber">
<span class="menu-icon"><i class="fa fa-users"></i></span> 
<span class="menu-text">Subscribed User</span>  

</a> 
</li>-->


<!--<li <?php if($page == 'terms'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Dashboard/Terms">
<span class="menu-icon"><i class="fa fa-sliders"></i></span> 
<span class="menu-text">Terms & Conditions </span>  

</a> 
</li>-->
                
                
                
<!--<li <?php if($page == 'policy'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Dashboard/Privacy/1">
<span class="menu-icon"><i class="fa fa-sliders"></i></span> 
<span class="menu-text">Privacy Policy</span>  

</a> 
</li> -->


<!--<li <?php if($page == 'refund'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Dashboard/Refund/2">
<span class="menu-icon"><i class="fa fa-sliders"></i></span> 
<span class="menu-text">Refund Policy</span>  
</a> 
</li>-->


<!--<li <?php if($page == 'delivery'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Dashboard/Delivery/3">
<span class="menu-icon"><i class="fa fa-sliders"></i></span> 
<span class="menu-text">Delivery Policy</span>  
</a> 
</li>-->
                
                
<!--<li>
<li <?php if($page == 'faq'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Faq/">
<span class="menu-icon"><i class="fa fa-sliders"></i></span> 
<span class="menu-text">FAQ Mgmt</span>  
</a> 
</li>
<li>-->


<li <?php if(@$page_type == 'settings'){echo 'class="active"';}?>>
<a href="javascript:void(0);" data-action="click-trigger <?php  if(@$page_type == 'settings'){echo 'class="open"';}?>" >
<span class="menu-icon"><i class="fa fa-cogs"></i></span> 
<span class="menu-text">Settings</span>  
<span class="menu-badge"><span class="badge vd_bg-black-30"><i class="fa fa-angle-down"></i></span></span>
</a>
<div class="child-menu"  data-action="click-target" style="<?php  if(@$page_type == 'settings'){echo 'display:block';}?>">

    
    
<ul>   
<li <?php if($page == 'contact'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Super/ContactDetails">
<span class="menu-text">Contact</span>  
</a>
</li> 


<li <?php if($page == 'social'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Super/SocialDetails">
<span class="menu-text">Social</span>  
</a>
</li> 


</ul>   
</div>
</li>






<!--    <li <?php if($page == 'product'){echo 'class="active"';}?>>
<a href="javascript:void(0);" data-action="click-trigger <?php if($page == 'product'){echo 'class="open"';}?>" >
<span class="menu-icon"><i class="fa fa-table"></i></span> 
<span class="menu-text">Product Mgmt</span>  
<span class="menu-badge"><span class="badge vd_bg-black-30"><i class="fa fa-angle-down"></i></span></span>
</a>
<div class="child-menu"  data-action="click-target" style="<?php if($page == 'product'){echo 'display:block';}?>">
<ul>
<li <?php if(@$sub_menu == 'category'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Product/category_list">
<span class="menu-text">Category List</span>  
</a>
</li> 
<li <?php if(@$sub_menu == 'subcategory'){echo 'class="active"';}?>>
<a href="<?php echo base_url();?>Webadmin/Product/subcategory_list">
<span class="menu-text">Sub Category List</span>  
</a>
</li> 
<li>
<a href="listtables-tables-variation.html">
<span class="menu-text">Tables Variation</span>  
</a>
</li>              
<li>
<a href="listtables-data-tables.html">
<span class="menu-text">Data Tables</span>  
</a>
</li> 

</ul>   
</div>
</li>
<li>



<a href="javascript:void(0);" data-action="click-trigger">
<span class="menu-icon"><i class="fa fa-th-list"></i></span> 
<span class="menu-text">Forms</span>  
<span class="menu-badge"><span class="badge vd_bg-black-30"><i class="fa fa-angle-down"></i></span></span>
</a>
<div class="child-menu"  data-action="click-target">
<ul>
<li>
<a href="forms-elements.html">
<span class="menu-text">Form Elements</span>  
</a>
</li>              
<li>
<a href="forms-layouts.html">
<span class="menu-text">Form Layouts</span>  
</a>
</li>                
<li>
<a href="forms-wizard.html">
<span class="menu-text">Form Wizard</span>  
</a>
</li> 
<li>
<a href="forms-validation.html">
<span class="menu-text">Form Validation</span>  
</a>
</li>                   
<li>
<a href="forms-sliders.html">
<span class="menu-text">Form Slider</span>  
</a>
</li>                 
<li>
<a href="forms-multiple-file-upload.html">
<span class="menu-text">Form Multiple File Upload</span>  
</a>
</li>                                                                                      
<li>
<a href="forms-inline-editing.html">
<span class="menu-text">Form Inline Editing</span>  
<span class="menu-badge"><span class="badge vd_bg-yellow">NEW</span></span>
</a>
</li>                 
</ul>   
</div>
</li>  

<li>
<a href="javascript:void(0);" data-action="click-trigger">
<span class="menu-icon"><i class="fa fa-table"></i></span> 
<span class="menu-text">List &amp; Tables</span>  
<span class="menu-badge"><span class="badge vd_bg-black-30"><i class="fa fa-angle-down"></i></span></span>
</a>
<div class="child-menu"  data-action="click-target">
<ul>
<li>
<a href="listtables-data-tables.html">
<span class="menu-text">Data Tables</span>  
</a>
</li> 
<li>
<a href="listtables-tables-variation.html">
<span class="menu-text">Tables Variation</span>  
</a>
</li>              
<li>
<a href="listtables-data-tables.html">
<span class="menu-text">Data Tables</span>  
</a>
</li> 

</ul>   
</div>
</li>


<li>
<a href="http://themeforest.net/item/vendroid-super-flexible-multipurpose-admin-theme/7717536?ref=Venmond">
<span class="menu-icon"><i class="fa fa-shopping-cart"></i></span> 
<span class="menu-text">Buy This Theme</span>  
<span class="menu-badge"><span class="badge vd_bg-red"><i class="fa fa-exclamation"></i></span></span>
</a>
</li>   -->

</ul>
<!-- Head menu search form ends -->         </div>             
</div>
<div class="navbar-spacing clearfix">
</div>
<div class="vd_menu vd_navbar-bottom-widget">
<ul>
<li>
<a href="<?php echo base_url();?>Webadmin/Login/logout">
<span class="menu-icon"><i class="fa fa-sign-out"></i></span>          
<span class="menu-text">Logout</span>             
</a>

</li>
</ul>
</div>     
</div>    