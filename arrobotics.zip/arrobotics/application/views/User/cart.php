

<!--Banner-->


<section>
<div class="csi-banner csi-banner-inner">
<div class="csi-inner">
<div class="container">
<div class="row">
<div class="col-xs-12">
<div class="csi-heading-area">
<h2 class="csi-heading">
    My Shopping Cart
</h2>
<!--<ul class="breadcrumb">
<li><a href="<?=base_url()?>"><i class="icon-home6"></i>Home</a></li>
<li class="active">Cart</li>
</ul>-->
</div>
</div>
</div>
</div>

</div>
</div>
</section>


<!--Banner END-->

<!-- ============================================== HEADER : END ============================================== -->


<div class="body-content outer-top-xs" style="margin-top:50px;">
<div class="container">
<div class="row ">
<div class="shopping-cart">
<div class="shopping-cart-table ">
<div class="table-responsive">
    
    
    <form method="post" action="<?=base_url()?>User/Viewcart">  
        
       
    
<table class="table">
<thead>
<tr>
           <span style="color:green;font-size:20px;" id="msg"> <i><?php echo $this->session->flashdata('success_msg'); ?></i></span>
<th class="cart-romove item">Remove</th>
<th class="cart-description item">Image</th>
<th class="cart-product-name item">Product Name</th>
<!--<th class="cart-edit item">Edit</th>-->
<th class="cart-qty item">Quantity</th>
<th class="cart-sub-total item">Price</th>
<th class="cart-total last-item">Subtotal</th>
</tr>
</thead><!-- /thead -->

<tbody>
    
        <?php
        $i=1;
  $data['Admin_model']=$this->Admin_model;

$count=$this->Admin_model->fetch_all_join("select * from cart where user_id='".$this->session->userdata('user_id')."'");

$total=0;
$count_product=count($count);


foreach($count as $product_list){
    $list=$this->Admin_model->fetch_single_join("select * from nsn_product where Id='$product_list->product_id'");
    
$quantity=$list->price*$product_list->quantity;
 $total=$total+$quantity;
?> 
    
<tr id="blog<?=$list->product_id?>">
<input type="hidden" name="row" value="<?=$count_product?>">
<input type="hidden" name="product_id<?=$i?>" value="<?=$product_list->product_id?>">


<!--<input type="text" name="product_quantity<?=$i?>" value="<?=$product_list->quantity?>">-->
    
    
    
<td class="romove-item"><a href="#" onclick="deletecart('<?=$product_list->id?>');" title="cancel" class="icon">
        <i class="fa fa-trash-o"></i></a>
</td>

<td class="cart-image">
<a class="entry-thumbnail" href="#">
    <img src="<?=base_url()?>Banner/<?=$list->image;?>" alt="image" style="height: 80px;">
</a>
</td>
<td class="cart-product-name-info">
<h4 class='cart-product-description'><a href="#"><?=$list->title?></a></h4>
</td>

<!--<td class="cart-product-edit"><a href="#" class="product-edit">Edit</a></td>-->

<td class="cart-product-quantity">

<div class="col-sm-2">
    <input type="number" id="quantity" name="quantity<?=$i?>" value="<?=$product_list->quantity;?>"  min="1" max="<?=$list->Quantity;?>" style="margin-top: 4px;width: 60px;margin-left:-40px;" >

    </div>
    
</td>

<td class="cart-product-sub-total"><span class="cart-sub-total-price">$<?=$list->price?></span></td>
<td class="cart-product-grand-total"><span class="cart-grand-total-price">$<?=$quantity?></span></td>
</tr>

<?php $i++;} ?>




</tbody>

<tfoot>
<tr>
<td colspan="7">
<div class="shopping-cart-btn">
<span class="">
<a href="<?=base_url()?>product" class="btn btn-upper btn-primary outer-left-xs">Continue Shopping</a>

<!--<a href="#" class="btn btn-upper btn-primary pull-right outer-right-xs">Update shopping cart</a>-->

<button type="submit" name="submit" value="submit" class="btn btn-upper btn-primary pull-right outer-right-xs">Update shopping cart</button>

</span>
</div>
</td>
</tr>
</tfoot>
</table>
    
    </form>
</div>
</div>	



<div class="col-md-4 col-sm-12 cart-shopping-total"></div>
<div class="col-md-4 col-sm-12 cart-shopping-total"></div>
<div class="col-md-4 col-sm-12 cart-shopping-total">
<table class="table">
<thead>
<tr>
<th>
    
<!--<div class="cart-sub-total">
Subtotal<span class="inner-left-md">$<?=$total?></span>
</div>-->
    
<div class="cart-grand-total">
    Grand Total  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="inner-left-md">$<?=$total?></span>
</div>
</th>
</tr>
</thead>

<tbody>
<tr>
<td>
<div class="cart-checkout-btn pull-right">
    
    
<form method="post" action="<?=base_url()?>User/Checkout">

<?php
$i=1;
$data['Admin_model']=$this->Admin_model;

$count=$this->Admin_model->fetch_all_join("select * from cart where user_id='".$this->session->userdata('user_id')."'");

$total=0;
$count_product=count($count);


foreach($count as $product_list){  
    
      $p_list=$this->Admin_model->fetch_single_join("select * from nsn_product where Id='$product_list->product_id'");

    ?> 

<input type="hidden" name="row" value="<?=$count_product?>">
<input type="hidden" name="product_id<?=$i?>" value="<?=$product_list->product_id?>">
<input type="hidden" name="product_quantity<?=$i?>" value="<?=$product_list->quantity?>">

<input type="hidden" name="product_price<?=$i?>" value="<?=$p_list->price?>">


<?php $i++;} ?>

<button type="submit" name="submit" value="submit" class="btn btn-primary checkout-btn">PROCCED TO CHEKOUT</button>  
</form>
    
    
    
    
<!--<span class="">Checkout with multiples address!</span>-->
</div>
</td>
</tr>
</tbody>
</table>
</div>			
</div>
</div>
<!-- ============================================== BRANDS CAROUSEL ============================================== -->



<!-- /.logo-slider -->
<!-- ============================================== BRANDS CAROUSEL : END ============================================== -->	</div><!-- /.container -->
</div><!-- /.body-content -->
<script>
    function deletecart(id)
    {
        //alert(id);
        cnf = confirm("Are you confirm to delete?");
        if(cnf)
		{
                  
                    $('.portlet .tools a.reload').click();
                    $.ajax({
                        type:"GET",
                        url:"<?php echo base_url();?>User/Deletecart",
                        data:"id="+id,
                        success:function(data)
                        {
                            
                            window.location.reload();
                            
                           
                                                      

                               // $('#blog'+id).css('display', 'none');

                        }
                    });
			
		}
    }

</script>