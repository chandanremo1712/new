
<!-- Start main-content -->
<div class="main-content">
<!-- Section: inner-header -->
<section class="inner-header divider parallax layer-overlay overlay-dark-8" data-bg-img="<?=base_url()?>images/bg/bg6.jpg">
<div class="container pt-60 pb-60">
<!-- Section Content -->
<div class="section-content">
<div class="row">
<div class="col-md-12 text-center">
<h2 class="title text-white">News & Events Details</h2>
<ol class="breadcrumb text-center text-black mt-10">
<li><a href="#">Home</a></li>
<li class="active text-white">News & Events Details Page</li>
</ol>
</div>
</div>
</div>
</div>
</section>
<?php
$id=$this->uri->segment('2');
if($newsz->NewsImage!='')
{
    $pic=base_url().'News/'.$newsz->NewsImage;
}
else{
    $pic=base_url().'News/noimg.png';
}




?>

<!-- Section: Blog -->
<section>
<div class="container mt-30 mb-30 pt-30 pb-30">
<div class="row">
<div class="col-md-9">
<div class="blog-posts single-post">
<article class="post clearfix mb-0">
<div class="entry-header">
<div class="post-thumb thumb"> <img src="<?=$pic?>" alt="" class="img-responsive img-fullwidth"> </div>
</div>
<div class="entry-content">
<div class="entry-meta media no-bg no-border mt-15 pb-20">
<div class="entry-date media-left text-center flip bg-theme-colored pt-5 pr-15 pb-5 pl-15">
<ul>
<li class="font-16 text-white font-weight-600"><?php echo date("j", strtotime($newsz->NewsDate));?></li>
<li class="font-12 text-white text-uppercase"><?php echo date("M", strtotime($newsz->NewsDate));?></li>
</ul>
</div>
<div class="media-body pl-15">
<div class="event-content pull-left flip">
<h3 class="entry-title text-white text-uppercase pt-0 mt-0"><a href="#"><?=$newsz->NewsTitle?></a></h3>

</div>
</div>
</div>
    
<?=$newsz->NewsDesc?>


</div>
</article>
    

</div>
</div>
    
<div class="col-md-3">
<div class="sidebar sidebar-right mt-sm-30">
   
    
<div class="widget">
<h5 class="widget-title line-bottom">Latest News & Events</h5>
<div class="latest-posts">
 <?php
 $allnews= $this->Admin_model->fetch_all_join("select * from nsn_news where Status='Yes' and id!=$id order by id desc limit 5");
foreach($allnews as $newsz){
    
    
if($newsz->NewsImage!='')
{
    $pic=base_url().'News/'.$newsz->NewsImage;
}
else{
    $pic=base_url().'News/noimg.png';
}

?>   
    
<article class="post media-post clearfix pb-0 mb-10">
<a class="post-thumb" href="<?=base_url()?>newsdetails/<?=$newsz->id?>"><img src="<?=$pic?>" alt="" style="height:70px;"></a>
<div class="post-right">
<h5 class="post-title mt-0"><a href="<?=base_url()?>newsdetails/<?=$newsz->id?>"><?=$newsz->NewsTitle?></a></h5>
<p><?php echo date("j M y", strtotime($newsz->NewsDate));?></p>

</div>
</article>
    
<?php } ?>
    
</div>
</div>
    
 
    
    
</div>
</div>
</div>
</div>
</section> 
</div>  
<!-- end main-content -->
