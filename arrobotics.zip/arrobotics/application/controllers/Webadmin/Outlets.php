<?php

ob_start();
defined('BASEPATH') OR exit('No direct script access allowed');

class Outlets extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->database();

        $this->load->library('email');
        $this->load->library('form_validation');
        $this->load->model('Webadmin/Admin_model');
        $this->load->helper("file");

        $this->load->library('image_lib');
        $this->load->helper("url");
    }

    function index() {

        $page = 'outlets';
        $data['page'] = $page;

        $page_type = 'user';
        $data['page_type'] = $page_type;

        $data['Admin_model'] = $this->Admin_model;
        $fetch = $this->Admin_model->fetch_all_join('select * from service_outlets order by id desc');
        $data['fetch'] = $fetch;
        $this->load->view('Webadmin/header');
        $this->load->view('Webadmin/leftbar', $data);
        $this->load->view('Webadmin/outlets', $data);
        $this->load->view('Webadmin/footer');
    }
    
  /*********************for show user concersation List****************************/ 
    
    function friends() {
        

        $page = 'outlets';
        $data['page'] = $page;

        $page_type = 'user';
        $data['page_type'] = $page_type;

        $data['Admin_model'] = $this->Admin_model;
        
        // $fetch = $this->Admin_model->fetch_all('user');
       
        $this->load->view('Webadmin/header');
        $this->load->view('Webadmin/leftbar', $data);
        $this->load->view('Webadmin/friends', $data);
        $this->load->view('Webadmin/footer');
    }
    
    
    function conversasion() {
        $user_id=$this->uri->segment(4);
          $friend_id=$this->uri->segment(5);

        $page = 'outlets';
        $data['page'] = $page;

        $page_type = 'user';
        $data['page_type'] = $page_type;

        $data['Admin_model'] = $this->Admin_model;
        
        // $fetch = $this->Admin_model->fetch_all('user');
       
        $this->load->view('Webadmin/header');
        $this->load->view('Webadmin/leftbar', $data);
        $this->load->view('Webadmin/conversasion', $data);
        $this->load->view('Webadmin/footer');
    }
    
     /*********************for show user concersation List ends here ****************************/ 
    

    public function view_details() {
        if (!$this->session->userdata('is_logged_in')) {
            redirect('Webadmin/Login');
        }
        $page = 'outlets';
        $data['page'] = $page;

        $page_type = 'user';
        $data['page_type'] = $page_type;

        $id = $this->uri->segment(4);
        $fetch = $this->Admin_model->fetch_single('service_outlets', $id);
        $data['fetch'] = $fetch;
        $data['Admin_model'] = $this->Admin_model;
        $this->load->view('Webadmin/header');
        $this->load->view('Webadmin/leftbar', $data);
        $this->load->view('Webadmin/outlets_details', $data);
        $this->load->view('Webadmin/footer');
    }

    function edit_details() {
        if (!$this->session->userdata('is_logged_in')) {
            redirect('Webadmin/Login');
        }
        $page = 'outlets';
        $data['page'] = $page;

        $page_type = 'user';
        $data['page_type'] = $page_type;

        if ($this->input->post('submit') == "Submit") {

        


if(1)
{


$id = $this->input->post('id');
$name = $this->input->post('name');
      $username = $this->input->post('username');

$email=$this->input->post('email');
//$password=  base64_encode($this->input->post('password'));
$phone = $this->input->post('mobile');
$address = $this->input->post('address');
$wash_to_tumble_dry=  $this->input->post('wash_to_tumble_dry');
$wash_and_iron=  $this->input->post('wash_and_iron');
$dry_clean=  $this->input->post('dry_clean');
$ironing=  $this->input->post('ironing');
$bedding=  $this->input->post('bedding');

            $field_data = array(
                'name' => $name,
                'username'=>$username,
                'email' =>$email,
                'password' => base64_encode($this->input->post('password')),
               
                'phone' => $phone,
                 'address' =>$address,
                    'wash_to_tumble_dry'=>$wash_to_tumble_dry,
                 'wash_and_iron'=>$wash_and_iron,
                 'dry_clean'=>$dry_clean,
                 'ironing'=>$ironing,
                 'bedding'=>$bedding
                
            );








            $result = $this->Admin_model->eidt_details('service_outlets', $field_data, $id);
            
            //echo $this->db->last_query();exit();
            
            if ($result) {
                $succ = "Data Updated Successfully";
                $data['succ'] = $succ;
                $fetch = $this->Admin_model->fetch_single('service_outlets', $id);
                $data['fetch'] = $fetch;

                redirect(base_url() . 'Webadmin/Outlets/index/usucc');
            }
            
}
else{ 
    
    
     $id = $this->uri->segment(4);


            $fetch = $this->Admin_model->fetch_single('service_outlets', $id);
            $data['fetch'] = $fetch;
}
            
            
            
        } else {
            $id = $this->uri->segment(4);


            $fetch = $this->Admin_model->fetch_single('service_outlets', $id);
            $data['fetch'] = $fetch;
        }
        $data['Admin_model'] = $this->Admin_model;
        $this->load->view('Webadmin/header');
        $this->load->view('Webadmin/leftbar', $data);
        $this->load->view('Webadmin/outlets_details', $data);
        $this->load->view('Webadmin/footer');
    }

    
    
    
    
    function add_details() {
        if (!$this->session->userdata('is_logged_in')) {
            redirect('Webadmin/Login');
        }

        $page = 'employee';
        $data['page'] = $page;

        $page_type = 'user';
        $data['page_type'] = $page_type;
        
         $this->form_validation->set_rules('name', 'name', 'required');

$this->form_validation->set_rules('username', 'Username', 'required|callback_username_check');
$this->form_validation->set_rules('email', 'Email', 'required|callback_user_email_check');


        if ($this->input->post('submit') == "Submit") {

if ($this->form_validation->run() == FALSE) {
    
      $succ = "Username or Email Already Exists";
                $data['succ'] = $succ;
 
//$data['page'] = 'register';

 
  $this->load->view('Webadmin/header');
        $this->load->view('Webadmin/leftbar', $data);
        $this->load->view('Webadmin/outlets_details', $data);
        $this->load->view('Webadmin/footer');
    
              //  redirect(base_url().'Webadmin/Outlets/add_details');
} else {

            $rn = "SELECT LAST_INSERT_ID(id) as id From service_outlets order by id desc limit 1";
            $fetch = $this->Admin_model->fetch_single_join($rn);

            @$id = $fetch->id;

            $user_id = "SOL10" . ($id + 1);


          $name = $this->input->post('name');
      $username = $this->input->post('username');

$email=$this->input->post('email');
$pass=$this->input->post('password');
//$password=  base64_encode($this->input->post('password'));
$phone = $this->input->post('mobile');
$address = $this->input->post('address');
$wash_to_tumble_dry=  $this->input->post('wash_to_tumble_dry');
$wash_and_iron=  $this->input->post('wash_and_iron');
$dry_clean=  $this->input->post('dry_clean');
$ironing=  $this->input->post('ironing');
$bedding=  $this->input->post('bedding');

            $field_data = array(
                    'ip' => $_SERVER['REMOTE_ADDR'],
                'user_id' => $user_id,
                'name' => $name,
                'username'=>$username,
                'email' =>$email,
                'password' => base64_encode($this->input->post('password')),
               
                'phone' => $phone,
                 'address' =>$address,
                 'date' => date('Y-m-d H:i:s'),
                'status' => 'Active',
                'wash_to_tumble_dry'=>$wash_to_tumble_dry,
                 'wash_and_iron'=>$wash_and_iron,
                 'dry_clean'=>$dry_clean,
                 'ironing'=>$ironing,
                 'bedding'=>$bedding
                
            );
            

            //-------new image upload-----------//
            //$old_image = $this->input->post('old_img');
         /*   $config['upload_path'] = 'profile/medium/';
            $config['allowed_types'] = 'gif|jpg|png';
            $config['max_size'] = 2048;
            $config['max_width'] = 3000;
            $config['max_height'] = 2000;
            $config['file_name'] = uniqid();
            $this->load->library('upload', $config);

            if (!$this->upload->do_upload('file')) {
                $error = array('error' => $this->upload->display_errors());
                $image = "";
            } else {
                $file_data = $this->upload->data();
                $image = $file_data['file_name'];
            }*/


            //--------new image upload end---------//



            $result = $this->Admin_model->add_details('service_outlets', $field_data);

            //  echo $this->db->last_query();exit();

            if ($result) {
                $succ = "Data Updated Successfully";
                $data['succ'] = $succ;
                $fetch = $this->Admin_model->fetch_single('service_outlets', $id);
                $data['fetch'] = $fetch;


$htmlContent = "<table align='center' style='width:650px; text-align:center; background:#f7f7f7;'>
<tbody>
<tr style='height:50px;background-color:#252424;'><td valign='middle' style='color:#252424;'><img src='" . base_url() . "images/footer_logo.png' alt='laundrytorun' title='laundrytorun' /></td></tr>
<tr>
<td valign='top' align='center' colspan='2'>
<table align='center' style='height:380px; color:#000; width:600px;'>
<tbody>
<tr>
<td style='width:8px;'>&nbsp;</td> 
<td align='center' style='font-size:28px;border-top:1px dashed #ccc;' colspan='3'>Hello, $name</td>
</tr>
<tr>
<td valign='top' align='center' colspan='2'>



     <p>You account has been created by laundrytorun Administrator.</p>
     <p>Use the following details for login</p>
      <p> Username : " . $username . "</p>
      <p>  Email : " . $email . "</p>
    <p> Password : " . $pass . "</p>   

<br>
Sincerely,<br>
Laundrytorun Team<br><br>
<strong>Email:</strong>support@laundrytorun.com<br><br>

This is an automated response, please DO NOT reply.
<br>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>";


//echo $htmlContent;
//exit();

$config['mailtype'] = 'html';
//$config['smtp_host'] = 'smtp-pulse.com';
//$config['smtp_user'] = 'info@shortonstaff.com';
//$config['smtp_pass'] = '5LsDXg2Drn';
//$config['smtp_port'] = '2525';

$this->email->initialize($config);
$this->email->to($email);
$this->email->from('support@laundrytorun.com', 'Laundrytorun');
$this->email->subject('Account Has Been Created By Laundrytorun Admin');
$this->email->message($htmlContent);

$this->email->send();








                /*                 * ***********email send to admin [cn]******************* */

               /* $adminhtml = "<table align='center' style='width:650px; text-align:center; background:#f7f7f7;'>
<tbody>
<tr style='height:50px;'><td valign='middle'><img src='" . base_url() . "frontend/image/logo.png' alt='SOS' title='SOS' /></td></tr>
<tr>
<td valign='top' align='center' colspan='2'>
<table align='center' style='height:380px; color:#000; width:600px;'>
<tbody>
<tr>
<td style='width:8px;'>&nbsp;</td>               
<td align='center' style='font-size:28px;border-top:1px dashed #ccc;' colspan='3'>Hello Admin,</td>
</tr>
<tr>
<td valign='top' align='center' colspan='2'>
A New Employer Has Registered From Short on Staff Website.<br><br>
We have sent  a verification link to activate the account.<br><br>
Registration Details of $user_id.<br><br>
<table align='center' style='color:#000; width:600px;'>
<tbody>
<tr align='center'><td><strong>ID</strong>&nbsp;:&nbsp;$user_id</td></tr>

<tr align='center'><td><strong>EMAIL</strong>&nbsp;:&nbsp;$email</td></tr>
<tr align='center'><td><strong>MOBILE</strong>&nbsp;:&nbsp;$mobile</td></tr>
<tr align='center'><td><strong>PASSWORD</strong>&nbsp;:&nbsp;$password</td></tr>
<tr align='center'><td><strong>FIRST NAME</strong>&nbsp;:&nbsp;$firstname</td></tr>
<tr align='center'><td><strong>LAST NAME</strong>&nbsp;:&nbsp;$lastname</td></tr>
<tr align='center'><td><strong>BUSINESS NAME</strong>&nbsp;:&nbsp;$business_name</td></tr>

<tr align='center'><td><strong>ABOUT BUSINESS</strong>&nbsp;:&nbsp;$about_business</td></tr>
</tbody>
</table>
<br>
Sincerely,<br>
Short on Staff Support Team<br>
This is an automated response, please DO NOT reply.
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>";



                $config['mailtype'] = 'html';

                $this->email->initialize($config);
                $this->email->to('registrations@shortonstaff.com');
                $this->email->from('info@shortonstaff.com', 'SOS');
                $this->email->subject('Employer Registration From SOS');
                $this->email->message($adminhtml);

                $this->email->send();*/
                
                




                /*                 * **************email send to admin [cn]*************** */
            }
        }
        }





        $data['Admin_model'] = $this->Admin_model;
        $this->load->view('Webadmin/header');
        $this->load->view('Webadmin/leftbar', $data);
        $this->load->view('Webadmin/outlets_details', $data);
        $this->load->view('Webadmin/footer');
    }
    
    
    
    
public function user_email_check($email) {

$email = $email;
$fetch_row = $this->Admin_model->fetch_row('service_outlets', "email='$email'");
// echo $this->db->last_query();exit();

if (count($fetch_row)> 0) {
$this->form_validation->set_message('user_email_check', 'Email id already exists');

return FALSE;
}

return TRUE;
}

public function username_check($username) {

$username = $username;
$fetch_row = $this->Admin_model->fetch_row('service_outlets', "username='$username'");
// echo $this->db->last_query();exit();

if (count($fetch_row)> 0) {
$this->form_validation->set_message('username_check', 'Username already exists');

return FALSE;
}

return TRUE;
}
     




    function DeleteEmp() {

        $id = $this->input->get('id', TRUE);
        // $fetch = $this->Admin_model->fetch_single('sos_user_register',$id);
        //print_r( $fetch);exit();

        $banner = $this->Admin_model->delete_single('service_outlets', $id);
        if ($banner) {

            echo 'deleted';
        }
    }
    
    


    public function tutor_email_check($email) {

        $email = $email;
        $fetch_row = $this->Admin_model->fetch_row('tutor', "email='$email'");
        // echo $this->db->last_query();exit();




        if ($fetch_row>0) {
            $this->form_validation->set_message('tutor_email_check', 'Email Already Exists');

            return FALSE;
        }

        return TRUE;
    }
    
    public function tutor_username_check($email) {

        $username = $username;
        $fetch_row = $this->Admin_model->fetch_row('tutor', "username='$username'");
        // echo $this->db->last_query();exit();




        if ($fetch_row >0) {
            $this->form_validation->set_message('tutor_username_check', 'Username Already Exists');

            return FALSE;
        }

        return TRUE;
    }
    
    
    
    
    
    

}
