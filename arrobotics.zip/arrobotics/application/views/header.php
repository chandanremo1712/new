<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>

<!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="ArRobotics | Education & Courses HTML Template" />
<meta name="keywords" content="academy, course, education, education html theme, elearning, learning," />
<meta name="author" content="ThemeMascot" />

<!-- Page Title -->
<title>AR ROBOTICS</title>

<!-- Favicon and Touch Icons -->
<link href="<?=base_url()?>images/favicon.png" rel="shortcut icon" type="image/png">
<link href="<?=base_url()?>images/apple-touch-icon.png" rel="apple-touch-icon">
<link href="<?=base_url()?>images/apple-touch-icon-72x72.png" rel="apple-touch-icon" sizes="72x72">
<link href="<?=base_url()?>images/apple-touch-icon-114x114.png" rel="apple-touch-icon" sizes="114x114">
<link href="<?=base_url()?>images/apple-touch-icon-144x144.png" rel="apple-touch-icon" sizes="144x144">

<!-- Stylesheet -->
<link href="<?=base_url()?>css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="<?=base_url()?>css/jquery-ui.min.css" rel="stylesheet" type="text/css">
<link href="<?=base_url()?>css/animate.css" rel="stylesheet" type="text/css">
<link href="<?=base_url()?>css/css-plugin-collections.css" rel="stylesheet"/>
<!-- CSS | menuzord megamenu skins -->
<link id="menuzord-menu-skins" href="<?=base_url()?>css/menuzord-skins/menuzord-rounded-boxed.css" rel="stylesheet"/>
<!-- CSS | Main style file -->
<link href="<?=base_url()?>css/style-main.css" rel="stylesheet" type="text/css">
<!-- CSS | Preloader Styles -->
<link href="<?=base_url()?>css/preloader.css" rel="stylesheet" type="text/css">
<!-- CSS | Custom Margin Padding Collection -->
<link href="<?=base_url()?>css/custom-bootstrap-margin-padding.css" rel="stylesheet" type="text/css">
<!-- CSS | Responsive media queries -->
<link href="<?=base_url()?>css/responsive.css" rel="stylesheet" type="text/css">
<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
<!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->

<!-- Revolution Slider 5.x CSS settings -->
<link  href="<?=base_url()?>js/revolution-slider/css/settings.css" rel="stylesheet" type="text/css"/>
<link  href="<?=base_url()?>js/revolution-slider/css/layers.css" rel="stylesheet" type="text/css"/>
<link  href="js/revolution-slider/css/navigation.css" rel="stylesheet" type="text/css"/>

<!-- CSS | Theme Color -->
<link href="<?=base_url()?>css/colors/theme-skin-color-set-1.css" rel="stylesheet" type="text/css">

<!-- external javascripts -->
<script src="<?=base_url()?>js/jquery-2.2.4.min.js"></script>
<script src="<?=base_url()?>js/jquery-ui.min.js"></script>
<script src="<?=base_url()?>js/bootstrap.min.js"></script>
<!-- JS | jquery plugin collection for this theme -->
<script src="<?=base_url()?>js/jquery-plugin-collection.js"></script>

<!-- Revolution Slider 5.x SCRIPTS -->
<script src="<?=base_url()?>js/revolution-slider/js/jquery.themepunch.tools.min.js"></script>
<script src="<?=base_url()?>js/revolution-slider/js/jquery.themepunch.revolution.min.js"></script>
</head>
<body class="">
<div id="wrapper" class="clearfix">
<!-- preloader -->
<!--<div id="preloader">
<div id="spinner">
<img alt="" src="images/preloaders/5.gif">
</div>
<div id="disable-preloader" class="btn btn-default btn-sm">Disable Preloader</div>
</div>-->

<!-- Header -->
<style>
    .txt_color{color:#000 !important;}
    
    .form-control{color:#000 !important;}
</style>
<style>
    small{color:red;};
    .dl{color:red!important;};
    
    .new{position: absolute!important;
    width: 30px!important;
    height: 30px!important;
    top: -4px!important;
    background: #fff!important;}
</style>



 <?php
$info=$this->Admin_model->fetch_single_join("select * from nsn_contact where id=1");

?>  

<header id="header" class="header">
<div class="header-top bg-theme-color-2 sm-text-center">
<div class="container">
<div class="row">
<div class="col-md-8">
<div class="widget no-border m-0">
<ul class="list-inline">
<li class="m-0 pl-10 pr-10"> <i class="fa fa-phone text-white"></i> <a class="text-white" href="#"><?=$info->phone?></a> </li>
<li class="text-white m-0 pl-10 pr-10"> <i class="fa fa-clock-o text-white"></i> Mon-Fri 8:00 to 2:00 </li>
<li class="m-0 pl-10 pr-10"> <i class="fa fa-envelope-o text-white"></i> <a class="text-white" href="#"><?=$info->email?></a> </li>
</ul>
</div>
</div>
<div class="col-md-4">
<div class="widget no-border m-0">
<ul class="list-inline text-right sm-text-center">
<li>
    <?php
    if($this->session->userdata('user_id')!=''){
    ?>
<a href="<?=base_url()?>User" class="text-white">Profile</a>
    <?php } else{  ?>
<a href="<?=base_url()?>register" class="text-white">Register</a>
    <?php } ?>
</li>
<li class="text-white">|</li>
<li>
    <?php
    if($this->session->userdata('user_id')!=''){
    ?>  
<a href="<?=base_url()?>User/logout" class="text-white">Logout</a>
    <?php } else { ?>
<a href="<?=base_url()?>login" class="text-white">Login</a>
    <?php } ?>

</li>


<!--<li class="text-white">|</li>
<li>
<a href="#" class="text-white">Support</a>
</li>-->

</ul>
</div>
</div>
</div>
</div>
</div>
<div class="header-nav">
<div class="header-nav-wrapper navbar-scrolltofixed bg-white">
<div class="container">
<nav id="menuzord-right" class="menuzord default">
<a class="menuzord-brand pull-left flip" href="<?=base_url()?>">
<img src="<?=base_url()?>images/logo.png" alt="" >
</a>
    
    
<ul class="menuzord-menu">   
<li class="<?php if($page=='home'){echo 'active';}?>"><a  href="<?=base_url()?>"><i class="fa fa-home" style="<?php if($page=='home'){echo 'color:red';}?>"></i>Home</a>
</li>

<li class="<?php if($page=='about'){echo 'active';}?>"><a href="<?=base_url()?>about"><i class="fa fa-users" style="<?php if($page=='about'){echo 'color:red';}?>"></i>About Us</a> </li>

<!--<li class="<?php if($page=='lab'){echo 'active';}?>"><a href="#"><i class="fa fa-lightbulb-o"></i>Innovation Lab</a></li>-->

<li class="<?php if($page=='service'){echo 'active';}?>"><a href="<?=base_url()?>services"><i class="fa fa-cube" style="<?php if($page=='service'){echo 'color:red';}?>"></i>Services</a> </li>

<li class="<?php if($page=='product'){echo 'active';}?>"><a href="<?=base_url()?>product"><i class="fa fa-shopping-bag" style="<?php if($page=='product'){echo 'color:red';}?>"></i>Products</a> </li>

<li class="<?php if($page=='news'){echo 'active';}?>"><a href="<?=base_url()?>allnews"><i class="fa fa-rss" style="<?php if($page=='news'){echo 'color:red';}?>"></i>News & Events</a></li>

<li class="<?php if($page=='contact'){echo 'active';}?>"><a href="<?=base_url()?>contact"><i class="fa fa-envelope-o" style="<?php if($page=='contact'){echo 'color:red';}?>"></i>Contact Us</a> </li>
<?php
    $cart_product=$this->Admin_model->fetch_all_join("select * from cart where user_id='$this->user_id'");
    $cart_count=count($cart_product);
    
     if($this->user_id=='')
    {
        $cart_url=base_url().'login';
    }
 else {
        $cart_url=base_url().'User/Viewcart';
}

?>


<li><a href="<?=$cart_url?>"><i class="fa fa-shopping-cart" aria-hidden="true"></i><span class="new"><?=$cart_count?></span></a></li>

</ul>
    
    
    
</nav>
</div>
</div>
</div>
</header>