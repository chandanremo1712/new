 <!-- Footer Start -->
           <footer class="footer-1"  id="footer">      
                <div class="vd_bottom ">
                    <div class="container">
                        <div class="row">
                            <div class=" col-xs-12">
                                <div class="copyright">
                                    Copyright &copy;<?php echo date('Y');?> <?=PROJECT_NAME?>. All Rights Reserved 
                                </div>
                            </div>
                        </div><!-- row -->
                    </div><!-- container -->
                </div>
            </footer>
           
        </div>

        <!-- .vd_body END  -->
        <a id="back-top" href="#" data-action="backtop" class="vd_back-top visible"> <i class="fa  fa-angle-up"> </i> </a>

        <!--
        <a class="back-top" href="#" id="back-top"> <i class="icon-chevron-up icon-white"> </i> </a> -->

        <!-- Javascript =============================================== --> 
        <!-- Placed at the end of the document so the pages load faster --> 
      
        <!--[if lt IE 9]>
          <script type="text/javascript" src="js/excanvas.js"></script>      
        <![endif]-->
        
         <!-- Min JS -->
          <!--<script type="text/javascript" src="<?php echo base_url();?>backend/js/jquery.js"></script>--> 
            
        <!-- Min JS -->
       
<!--  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>-->
<script>
    function readURL(input) {

        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }

    $("#imgInp").change(function(){
        readURL(this);
    });
</script>
        
<!--              <script src="https://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>-->
        <script type="text/javascript" src="<?php echo base_url();?>backend/js/bootstrap.min.js"></script> 
        <script type="text/javascript" src='<?php echo base_url();?>backend/plugins/jquery-ui/jquery-ui.custom.min.js'></script>
        <script type="text/javascript" src="<?php echo base_url();?>backend/plugins/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>

        <script type="text/javascript" src="<?php echo base_url();?>backend/js/caroufredsel.js"></script> 
        <script type="text/javascript" src="<?php echo base_url();?>backend/js/plugins.js"></script>

        <script type="text/javascript" src="<?php echo base_url();?>backend/plugins/breakpoints/breakpoints.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>backend/plugins/dataTables/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>backend/plugins/dataTables/dataTables.bootstrap.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>backend/plugins/prettyPhoto-plugin/js/jquery.prettyPhoto.js"></script> 

        <script type="text/javascript" src="<?php echo base_url();?>backend/plugins/mCustomScrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>backend/plugins/tagsInput/jquery.tagsinput.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>backend/plugins/bootstrap-switch/bootstrap-switch.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>backend/plugins/blockUI/jquery.blockUI.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>backend/plugins/pnotify/js/jquery.pnotify.min.js"></script>
        
        <script type="text/javascript" src='<?php echo base_url();?>backend/plugins/daterangepicker/moment.min.js'></script>
        <script type="text/javascript" src='<?php echo base_url();?>backend/plugins/daterangepicker/daterangepicker.js'></script>
        <script type="text/javascript" src="<?php echo base_url();?>backend/js/theme.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>backend/custom/custom.js"></script>

        <!-- Specific Page Scripts Put Here -->
        <!-- Flot Chart  -->
        <script type="text/javascript" src="<?php echo base_url();?>backend/plugins/flot/jquery.flot.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>backend/plugins/flot/jquery.flot.resize.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>backend/plugins/flot/jquery.flot.pie.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>backend/plugins/flot/jquery.flot.categories.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>backend/plugins/flot/jquery.flot.time.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>backend/plugins/flot/jquery.flot.animator.min.js"></script>

        <!-- Vector Map -->
        <script type="text/javascript" src="<?php echo base_url();?>backend/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>backend/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>

        <!-- Calendar -->
        <script type="text/javascript" src='<?php echo base_url();?>backend/plugins/moment/moment.min.js'></script>
        <script type="text/javascript" src='<?php echo base_url();?>backend/plugins/jquery-ui/jquery-ui.custom.min.js'></script>
        <script type="text/javascript" src='<?php echo base_url();?>backend/plugins/fullcalendar/fullcalendar.min.js'></script>
        <script type="text/javascript" src='<?php echo base_url();?>backend/plugins/ckeditor/ckeditor.js'></script>
        <script type="text/javascript" src='<?php echo base_url();?>backend/plugins/ckeditor/adapters/jquery.js'></script>
        <!-- Intro JS (Tour) -->
        <script type="text/javascript" src='<?php echo base_url();?>backend/plugins/introjs/js/intro.min.js'></script>

        <!-- Sky Icons -->
        <script type="text/javascript" src='<?php echo base_url();?>backend/plugins/skycons/skycons.js'></script>

<script type="text/javascript">
		$(document).ready(function() {
				"use strict";
				
				$('#data-tables').dataTable();
		} );
</script>
       <script type="text/javascript">
$(document).ready(function() {
		"use strict";	

        var form_register = $('#register-form');
        var error_register = $('.alert-danger', form_register);
        var success_register = $('.alert-success', form_register);

        form_register.validate({
            errorElement: 'div', //default input error message container
            errorClass: 'vd_red', // default input error message class
            focusInvalid: false, // do not focus the last invalid input
            ignore: "",
            rules: {
                title: {
                    minlength: 4,
                    required: true
                },
                name: {
                    minlength: 3,
                    required: true
                },
                email: {
                    required: true,
                    email: true
                },
                website: {
                    required: true,
                    url: true
                },
                company: {
                    minlength: 3,					
                    required: true
                },
                member: {
                    required: true
                },				
                password: {
                    required: true
                },
                confirmpass: {
                    required: true
                },				
            },
			
			errorPlacement: function(error, element) {
				if (element.parent().hasClass("vd_checkbox") || element.parent().hasClass("vd_radio")){
					element.parent().append(error);
				} else if (element.parent().hasClass("vd_input-wrapper")){
					error.insertAfter(element.parent());
				}else {
					error.insertAfter(element);
				}
			}, 
			
            invalidHandler: function (event, validator) { //display error alert on form submit              
					success_register.fadeOut(500);
					error_register.fadeIn(500);
					scrollTo(form_register,-100);

            },

            highlight: function (element) { // hightlight error inputs
		
				$(element).addClass('vd_bd-red');
				$(element).siblings('.help-inline').removeClass('help-inline fa fa-check vd_green mgl-10');

            },

            unhighlight: function (element) { // revert the change dony by hightlight
                $(element)
                    .closest('.control-group').removeClass('error'); // set error class to the control group
            },

            success: function (label, element) {
                label
                    .addClass('valid').addClass('help-inline fa fa-check vd_green mgl-10') // mark the current input as valid and display OK icon
                	.closest('.control-group').removeClass('error').addClass('success'); // set success class to the control group
				$(element).removeClass('vd_bd-red');
            },

            submitHandler: function (form) {
					success_register.fadeIn(500);
					error_register.fadeOut(500);
					scrollTo(form_register,-100);					
            }
        });



        var form_register_2 = $('#register-form-2');
        var error_register_2 = $('.alert-danger', form_register_2);
        var success_register_2 = $('.alert-success', form_register_2);

        form_register_2.validate({
            errorElement: 'div', //default input error message container
            errorClass: 'vd_red', // default input error message class
            focusInvalid: false, // do not focus the last invalid input
            ignore: "",
            rules: {
                firstname: {
                    minlength: 3,
                    required: true
                },
                lastname: {
                    minlength: 3,
                    required: true
                },				
                email: {
                    required: true,
                    email: true
                },
                website: {
                    required: true,
                    url: true
                },
                company: {
                    minlength: 3,					
                    required: true
                },
                country: {					
                    required: true
                },				
                phone: {					
                    required: true
                },					
                password: {
                    required: true
                },
                confirmpass: {
                    required: true
                },				
            },
			
			errorPlacement: function(error, element) {
				if (element.parent().hasClass("vd_checkbox") || element.parent().hasClass("vd_radio")){
					element.parent().append(error);
				} else if (element.parent().hasClass("vd_input-wrapper")){
					error.insertAfter(element.parent());
				}else {
					error.insertAfter(element);
				}
			}, 
			
            invalidHandler: function (event, validator) { //display error alert on form submit              

					success_register_2.fadeOut(500);
					error_register_2.fadeIn(500);				
					scrollTo(form_register_2,-100);

            },

            highlight: function (element) { // hightlight error inputs
		
				$(element).addClass('vd_bd-red');
				$(element).parent().siblings('.help-inline').removeClass('help-inline hidden');
				if ($(element).parent().hasClass("vd_checkbox") || $(element).parent().hasClass("vd_radio")) {
					$(element).siblings('.help-inline').removeClass('help-inline hidden');
				}

            },

            unhighlight: function (element) { // revert the change dony by hightlight
                $(element)
                    .closest('.control-group').removeClass('error'); // set error class to the control group
            },

            success: function (label, element) {
                label
                    .addClass('valid').addClass('help-inline hidden') // mark the current input as valid and display OK icon
                	.closest('.control-group').removeClass('error').addClass('success'); // set success class to the control group
				$(element).removeClass('vd_bd-red');
            },

            submitHandler: function (form) {
					success_register_2.fadeIn(500);
					error_register_2.fadeOut(500);
					scrollTo(form_register_2,-100);

            }
        });
	
	
});

//CKEDITOR.replace( $('[data-rel^="ckeditor"]') );
	$( '[data-rel^="ckeditor"]' ).ckeditor();
</script>

       
<!--<script type="text/javascript">
    //alert(1);
   $( "#datepicker-normal" ).datepicker({ dateFormat: 'dd M yy'}); 
</script>-->




<!--<link href="https://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css" rel="stylesheet">-->
  

      <!-- Javascript -->
  
  
 
  <script>
  $( function() {
    $( "#datepicker" ).datepicker({ dateFormat: 'dd M yy'});
  } );
  </script>
  
  <script>
$(document).ready(function () {
//called when key is pressed in textbox
$(".cost").keypress(function (e) {

//if the letter is not digit then display error and don't type anything
if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
//display error message
$("#errmsg").html("Digits Only").show().fadeOut("slow");
return false;
}
});
});
</script>
    </body>
</html>