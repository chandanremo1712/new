<?php
 error_reporting(0);
defined('BASEPATH') OR exit('No direct script access allowed');
include_once (dirname(__FILE__) . "/Index.php");// controller extended


class User extends Index {

function __construct()
{
parent::__construct();

//$this->load->model('Users_signup');
//$this->load->model('Signin_model');


$this->load->model('Admin/Admin_model');
$this->load->library('form_validation');
$this->load->library('upload');
$this->load->helper(array('form', 'url'));
$this->load->library('email');

if (!$this->session->userdata('email')) {
redirect(base_url() . 'Index');
}
$this->email= $this->session->userdata('email');
$this->user_id= $this->session->userdata('user_id');
}


function Index()
{

$data['page']="profile";

$userdetails = $this->Admin_model->fetch_row('user', "user_id='$this->user_id'"); 

$data['details'] = $userdetails;
//$data['countrylist']=  $this->Admin_model->fetch_all('countries');

$this->load->view('header',$data);
$this->load->view('User/dashboard',$data);
$this->load->view('footer',$data);
}


function Orderlist()
{

$data['page']="orderlist";

$userdetails = $this->Admin_model->fetch_row('user', "user_id='$this->user_id'"); 

$data['details'] = $userdetails;

$data['order']=$this->Admin_model->fetch_all_join("select * from order_details where user_id='$this->user_id' and delete_order='No' group by order_id desc");



$this->load->view('header',$data);
$this->load->view('User/orderlist',$data);
$this->load->view('footer',$data); // include footer1 for data table
}


function wishlist()
{

$data['page']="wishlist";




$this->load->view('header',$data);
$this->load->view('wishlist',$data);
$this->load->view('footer',$data); // include footer1 for data table
}


function Orderdetails()
{
$order_id=  $this->uri->segment(2);
$data['page']="orderlist";

$userdetails = $this->Admin_model->fetch_row('user', "email='$this->email'"); 

$data['details'] = $userdetails;

$data['order']=$this->Admin_model->fetch_all_join("select * from order_details where user_id='$this->user_id' and order_id='$order_id' and delete_order='No'");



$this->load->view('header',$data);
$this->load->view('User/order-details',$data);
$this->load->view('footer',$data); // include footer1 for data table
}


function invoice()
{
$order_id=  $this->uri->segment(2);
$data['page']="orderlist";

 $userdetails = $this->Admin_model->fetch_row('user', "user_id='$this->user_id'"); 

$data['details'] = $userdetails;

$data['order']=$this->Admin_model->fetch_all_join("select * from order_details where user_id='$this->user_id' and order_id='$order_id' and delete_order='No'");


$this->load->view('User/invoice',$data);

}


public function delete_user_order()
{

$id = $this->input->get('id', TRUE);
$fetch = $this->Admin_model->fetch_single('order_details',$id);

$data=array(
'delete_order'=>'Yes'
);

$delete_order=$this->Admin_model->eidt_single_row('order_details',$data,"order_id='$id'");

//           echo print_r($delete_order);
//            exit();

if($delete_order){

echo 'Order Deleted Successfully';
}

}

public function change_order_status()
{

$id = $this->input->get('id', TRUE);
$fetch = $this->Admin_model->fetch_single('order_details',$id);

$val = $this->input->get('val');
$field_data = array(
'cancel_order' => $val
);

$delete_order=$this->Admin_model->eidt_single_row('order_details',$data,"order_id='$id'");

//echo  print_r($delete_order);
// exit();

if($delete_order){

echo 'Order Status Updated Successfully';
}

}

public function Edit() {


$data['page']="profile";

$user = $this->Admin_model->fetch_row('user', "email='$this->email'"); 

$data['details'] = $user;


if($this->input->post('submit')=='submit')
{
$this->form_validation->set_rules('name', 'name', 'required');

$this->form_validation->set_rules('phone', 'phone', 'required|min_length[10]');  
$this->form_validation->set_rules('address', 'address', 'required');

//$this->form_validation->set_rules('city', 'city', 'required'); 
//$this->form_validation->set_rules('country', 'country', 'required');
//$this->form_validation->set_rules('last_name', 'name', 'required');

if($this->form_validation->run()=='TRUE')
{
$name = $this->input->post('name');

$phone = $this->input->post('phone'); 
//$city= $this->input->post('city');
//$country= $this->input->post('country');
//$zip= $this->input->post('zip');
$address=$this->input->post('address');


$user_data=array(
'name'=>$name,
'phone'=>$phone,
'address'=>$address


); 

$result=  $this->Admin_model->eidt_single_row('user',$user_data,"email='$this->email'");

// echo $this->db->last_query();exit();

if($result==TRUE)
{
$this->session->set_flashdata('success_msg', 'Profile Successfully Updated...');

redirect(base_url() . 'User');

}
else{

$this->session->set_flashdata('success_msg', 'Invalid Operation...');

}

}



}


$this->load->view('header',$data);
$this->load->view('User/dashboard',$data);
$this->load->view('footer',$data);

}


/* * ********image upload************ */

function profile_upload() {


$config['upload_path'] = './Banner/';
$config['allowed_types'] = 'gif|jpg|png';
$config['max_size'] = 20480;
$config['max_width'] = 30000;
$config['max_height'] = 20000;
$config['file_name'] = uniqid();
$this->upload->initialize($config);
$this->load->library('upload', $config);

echo  $this->input->post('profile'); 

$old_img = $this->input->post('old_img'); 
$image = "";
if (!$this->upload->do_upload('profile')) {

$error = array('error' => $this->upload->display_errors());
//print_r($error); exit();
if ($old_img != "") {
$image = $old_img;
}
} else {

$data = $this->upload->data();
$image = $data['file_name'];
if ($old_img != "")
unlink('Banner/' . $old_img);
$data_field = array(
'profile_image' => $image
);
$this->Admin_model->eidt_single_row('user', $data_field, "email='$this->email'");
//echo $this->db->last_query();exit();
}
if ($image != "")
echo '<img src="' . base_url() . '/Banner/' . $image . '" alt="" class="img-responsive img-circle">';
else
echo '<img src="' . base_url() . '/profile/no-image.png" alt="" class="img-responsive img-circle">';
}

/* * **********image upload end************ */



public function Cart() {

$date=date('Y-m-d');
$quantity= $this->input->post('quantity');

$product_id= $this->input->post('product_id');
$user_id= $this->session->userdata('user_id');



$userdata=array(
'product_id'=>$product_id,
'quantity'=>$quantity,
'user_id'=>$user_id,
'date' =>$date

); 

$result = $this->Users_signup->cart($userdata);

// echo $this->db->last_query();exit();

if($result==TRUE)
{
$this->session->set_flashdata('success_msg', 'Successfully Added To Cart...');

redirect(base_url() . 'User/Viewcart');

}
else{

$this->session->set_flashdata('success_msg', 'Invalid Operation...');

}

$this->load->view('header',$data);
$this->load->view('User/dashboard',$data);
$this->load->view('footer',$data);

}

public function Checkout() {

 $date=date('Y-m-d');
 $user_id= $this->session->userdata('user_id');
 

/*************create order id*************/
$res = "SELECT LAST_INSERT_ID(id) as id From order_details order by id desc limit 1";
$fetch = $this->Admin_model->fetch_single_join($res);

@$id = $fetch->id;

$order_id = "ODR10" . ($id + 1);

/************order id**************/

$row=$this->input->post('row');




for ($i = 1; $i <= $row; $i++) {
$userdata=array(
'order_id'=>$order_id,
'user_id'=>$user_id,
'product_id'=>$this->input->post('product_id'.$i),
'quantity'=>$this->input->post('product_quantity'.$i),
'price'=>$this->input->post('product_price'.$i),

'payment_status'=>'Not Paid',
'order_status'=>'Processed',
'delete_order'=>'No',
'date' =>$date

); 

$pid=$this->input->post('product_id'.$i);

$p_quantity=$this->input->post('product_quantity'.$i);

$result = $this->Admin_model->add_details('order_details',$userdata);

$delete_cart=$this->Admin_model->delete_single_con('cart', "product_id='$pid' and user_id='$user_id'");

//decrease product quantity//
$product=$this->Admin_model->fetch_single_join("select * from nsn_product where Id='$pid'");

$fetch_qty=$product->quantity;

$remaining_quantity=$fetch_qty-$p_quantity;

$dataquantity=array(
'Quantity'=>$remaining_quantity
);

$set_quantity=$this->Admin_model->eidt_single_row('nsn_product',$dataquantity,"Id='$pid'");


}


if($result==TRUE)
{
$this->session->set_flashdata('success_msg', 'Order Placed Successfully...');


redirect(base_url() . 'User');

}
else{

$this->session->set_flashdata('success_msg', 'Invalid Operation...');

}
redirect(base_url() . 'User');


}


function Viewcart()
{
   
$data['page']='mycart';

$user_id= $this->session->userdata('user_id');

if($this->input->post('submit')=="submit"){

$row=$this->input->post('row');
for ($i = 1; $i <= $row; $i++) {

$pid=$this->input->post('product_id'.$i);
$quantity=$this->input->post('quantity'.$i);


$userdata=array(

'quantity'=>$quantity

); 

$result=$this->Admin_model->eidt_single_row('cart',$userdata,"product_id='$pid' and user_id='$user_id'");

$this->db->last_query();

}

if($result==TRUE)
{
$this->session->set_flashdata('success_msg', 'Cart Updated Successfully...');

}
else{

$this->session->set_flashdata('success_msg', 'Invalid Operation...');
}
}




$this->load->view('header',$data);
$this->load->view('User/cart',$data);
$this->load->view('footer',$data);
}


function Delete() {

$id = $this->input->get('id', TRUE);
$banner = $this->Admin_model->delete_single_con('cart', "product_id='$id' and user_id='".$this->session->userdata('user_id')."'");
if ($banner) {

echo 'deleted';
}
}

function Deletecart() {

$id = $this->input->get('id', TRUE);


$banner = $this->Admin_model->delete_single_con('cart', "id='$id' and user_id='".$this->user_id."'");
if ($banner) {

echo 'deleted';
}
}



function job()
{

$data['page'] = "addjob";

$data['statelist']=  $this->Admin_model->fetch_all('state');

$employerdetails = $this->Admin_model->fetch_row('employer', "employer_id='$this->employer_id'"); 

$data['details'] = $employerdetails;



$this->load->view('header',$data);
$this->load->view('Employer/addjob',$data);
$this->load->view('footer',$data);
}


function editjob()
{

$data['page']="alljob";
$id=$this->uri->segment('3');

$data['statelist']=  $this->Admin_model->fetch_all('state');

$employerdetails = $this->Admin_model->fetch_row('employer', "employer_id='$this->employer_id'"); 

$data['details'] = $employerdetails;

$data['job']=  $this->Admin_model->fetch_row('jobs',"id='$id'");

$this->load->view('header',$data);
$this->load->view('Employer/editjob',$data);
$this->load->view('footer',$data);


}


function updatejob()
{
$data['page']="alljob";
$id=$this->uri->segment('3');

$job_id=$this->input->post('id');

$data['statelist']=  $this->Admin_model->fetch_all('state');

$employerdetails = $this->Admin_model->fetch_row('employer', "employer_id='$this->employer_id'"); 

$data['details'] = $employerdetails;

$data['job']=  $this->Admin_model->fetch_row('jobs',"id='$id'");


$this->form_validation->set_rules('company_name', 'Company Name', 'required|trim');  //name , message
//$this->form_validation->set_rules('job_id', 'Job Id', 'required|trim|min_length[6]|callback_employer_jobid_check');

$this->form_validation->set_rules('jobtitle', 'Jobtitle', 'required'); 
//Validating Mobile no. Field
$this->form_validation->set_rules('job_description', 'Job Details', 'required|trim');
$this->form_validation->set_rules('job_vacancy', 'Job Vacancy', 'required|trim');

$this->form_validation->set_rules('job_salary_from', 'Job Salary From', 'required|trim');
$this->form_validation->set_rules('job_salary_to', 'Job Salary To', 'required|trim');
$this->form_validation->set_rules('job_salary_per', 'Job Salary Per', 'required|trim');

$this->form_validation->set_rules('address', 'Address', 'required');
$this->form_validation->set_rules('state', 'State', 'required');
$this->form_validation->set_rules('city', 'City', 'required');
$this->form_validation->set_rules('zip', 'Zip', 'required');

if ($this->form_validation->run() == FALSE) {

redirect('Employer/editjob/'.$job_id);    

} else {

$email=  $this->input->post('email');
//$job_id=$this->input->post('job_id');
$password = $this->input->post('password');

$date=date('Y-m-d');

$datajob = array(


'company_name' => $this->input->post('company_name'),

'jobtitle' => $this->input->post('jobtitle'),
'job_description' => stripcslashes($this->input->post('job_description')),
'job_vacancy' => $this->input->post('job_vacancy'),
'job_salary_from' => $this->input->post('job_salary_from'),
'job_salary_to' => $this->input->post('job_salary_to'),
'job_salary_per' => $this->input->post('job_salary_per'),
'address' => $this->input->post('address'),
'state' => $this->input->post('state'),
'city' => $this->input->post('city'),
'zip' => $this->input->post('zip'),

'status' =>'Active'

);

//Transfering data to Model
$result = $this->Admin_model->eidt_details('jobs',$datajob,$job_id);

if ($result == TRUE) {

$data['message'] = 'Job Updated Successfully';
$this->session->set_flashdata('success_msg', 'Job Updated Successfully...');
}                




}     

redirect('Employer/editjob/'.$job_id);       

}







function addjob()
{
$data['page']="addjob";


$data['statelist']=  $this->Admin_model->fetch_all('state');

$employerdetails = $this->Admin_model->fetch_row('employer', "employer_id='$this->employer_id'"); 

$data['details'] = $employerdetails;


$this->form_validation->set_rules('company_name', 'Company Name', 'required|trim');  //name , message
$this->form_validation->set_rules('job_id', 'Job Id', 'required|trim|min_length[6]|callback_employer_jobid_check');

$this->form_validation->set_rules('jobtitle', 'Jobtitle', 'required'); 
//Validating Mobile no. Field

$this->form_validation->set_rules('job_vacancy', 'Job Vacancy', 'required|trim');
$this->form_validation->set_rules('job_description', 'Job Details', 'required|trim');


$this->form_validation->set_rules('job_salary_from', 'Job Salary From', 'required|trim');
$this->form_validation->set_rules('job_salary_to', 'Job Salary To', 'required|trim');
$this->form_validation->set_rules('job_salary_per', 'Job Salary Per', 'required|trim');

$this->form_validation->set_rules('address', 'Address', 'required');
$this->form_validation->set_rules('state', 'State', 'required');
$this->form_validation->set_rules('city', 'City', 'required');
$this->form_validation->set_rules('zip', 'Zip', 'required');

if ($this->form_validation->run() == FALSE) {
$data['page'] = 'register';
$this->load->view('header', $data);
$this->load->view('Employer/addjob', $data);
$this->load->view('footer', $data);
} else {
//Setting values for tabel columns

//            $rn = "SELECT LAST_INSERT_ID(id) as id From employer order by id desc limit 1";
//            $fetch = $this->Admin_model->fetch_single_join($rn);
//
//            @$id = $fetch->id;
//
//            $employer_id = "EMP10" . ($id + 1);
//            
//            
$email=  $this->input->post('email');
$job_id=$this->input->post('job_id');
//
//
//
//            $password = $this->input->post('password');

$date=date('Y-m-d');

$datajob = array(

'employer_id' => $this->employer_id,
'company_name' => $this->input->post('company_name'),
'job_id' => $this->input->post('job_id'),
'jobtitle' => $this->input->post('jobtitle'),
'job_description' => stripcslashes($this->input->post('job_description')),
'job_vacancy' => $this->input->post('job_vacancy'),
'job_salary_from' => $this->input->post('job_salary_from'),
'job_salary_to' => $this->input->post('job_salary_to'),
'job_salary_per' => $this->input->post('job_salary_per'),

'address' => $this->input->post('address'),
'state' => $this->input->post('state'),
'city' => $this->input->post('city'),
'zip' => $this->input->post('zip'),


'status' =>'Active',

'date' => $date
);

//Transfering data to Model
$result = $this->Users_signup->jobs($datajob);


if ($result == TRUE) {

$data['message'] = 'Job Successfully Added';
$this->session->set_flashdata('success_msg', 'Job Added Successfully...');
}
//Loading View
$data['page'] = 'studentregistration';
$this->load->view('header',$data);
$this->load->view('Employer/addjob',$data);
$this->load->view('footer',$data);

}

}



function ChangePassword() {
$data['page'] = "changepassword";
$data['page_parent'] = "settings";
$data['page']="";

$user = $this->Admin_model->fetch_row('user', "email='$this->email'"); 

$data['details'] = $user;

if ($this->input->post('submit') == "submit") 
{

$this->form_validation->set_rules('newpassword', 'new password', 'required|min_length[6]');


if ($this->form_validation->run() == TRUE)

{

$pass=  $this->input->post('newpassword');
$password=  base64_encode($pass);

$field_data=array(
'password'=>$password

);

$result=  $this->Admin_model->eidt_single_row('user',$field_data,"email='$this->email'");

if($result==TRUE)
{
$this->session->set_flashdata('success_msg', 'Password Changed Successfully...');

}
else{
$this->session->set_flashdata('success_msg', 'Invalid Operation...');
}

}

}

redirect(base_url() . 'User');

}

public function Profile() {

$data['page'] = "changepassword";
$data['page_parent'] = "account";


$studentdetails = $this->Admin_model->fetch_row('student', "student_id='$this->student_id'"); 
$data['education'] = $this->Admin_model->fetch_all_join("select * from student_education where student_id='$this->student_id'"); 

$data['studentdetails'] = $studentdetails;

$this->load->view('Menu', $data);
$this->load->view('student/StudentDashboard');
$this->load->view('Footer');

}

function logout()
{

$this->session->unset_userdata('email');
$this->session->unset_userdata('user_id');
redirect(base_url().'login');
}

function Deletejob() {

$id = $this->input->get('id', TRUE);

$banner = $this->Admin_model->delete_single('jobs', $id);
if ($banner) {

echo 'deleted';
}
}

public function addtowishlist()
{

$id = $this->input->get('id', TRUE);
$date=date('Y-m-d');

$data=array(
'user_id'=>$this->user_id,
'product_id'=>$id,
 'quantity'=>1,   
'date'=>$date
);


$banner = $this->Admin_model->add_details('wishlist',$data);

if($banner){

$this->session->set_flashdata('success_msg', 'Product successfully added to wishlist.');   
} 

}

public function delete_wishlist()
{
$id = $this->input->get('id', TRUE);



$banner = $this->Admin_model->delete_single_con('wishlist',"user_id='$this->user_id' and product_id='$id'");

if($banner){

$this->session->set_flashdata('success_msg', 'Product successfully removed from wishlist.');   
}

}

public function addtocart()
{

$id = $this->input->get('id', TRUE);
$date=date('Y-m-d');

$data=array(
'user_id'=>$this->user_id,
'product_id'=>$id,
     'quantity'=>1,  
'date'=>$date
);


$banner = $this->Admin_model->add_details('cart',$data);

if($banner){

$this->session->set_flashdata('success_msg', 'Product successfully added to cart.');   
} 

}

public function movetocart()
{

$id = $this->input->post('product_id');

$get_id= base64_encode($id);

$quantity=$this->input->post('quantity');
$date=date('Y-m-d');

$data=array(
'user_id'=>$this->user_id,
'product_id'=>$id,
     'quantity'=>$quantity,  
'date'=>$date
);


$banner = $this->Admin_model->add_details('cart',$data);

//$delete_from_wishlist=$this->Admin_model->delete_single_con('wishlist',"product_id='$id'");

if($banner){

$this->session->set_flashdata('success_msg', 'Product successfully added to cart.');   
redirect(base_url().'productdetails/'.$get_id);
} 

}





}

?>
