<?php
error_reporting(0);
defined('BASEPATH') OR exit('No Direct Script access allowed');

class Team extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Webadmin/Admin_model');
                $this->load->helper("file");
                $this->load->helper('date');

                
	}
	
	public function index()
        {
         
            if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
            $page = 'team';
            $data['page'] = $page;
            
            $fetch = $this->Admin_model->fetch_all_join('select * from team order by id desc');
            $data['fetch'] = $fetch;
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/team');
            $this->load->view('Webadmin/footer');
        }
	
        public function add_team()
        {
            if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
            $page = 'team';
            $data['page'] = $page;
            
            $image = "";
            if($this->input->post('submit') == 'Submit')
            {
                $title = $this->input->post('title');
                $position = $this->input->post('position');
               // $description = $this->input->post('desc');
             
                $config['upload_path']   = './News/'; 
                $config['allowed_types'] = 'gif|jpg|png'; 
                $config['max_size']      = 2048; 
                $config['max_width']     = 3000; 
                $config['max_height']    = 2000; 
                  $config['file_name']    = uniqid();  
                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('file')) {
                   $error = array('error' => $this->upload->display_errors()); 
                   $data['error'] = $error;
                }else { 
                    $file_data = $this->upload->data();
                   $image = $file_data['file_name'];
               } 
                
                $field_data = array(
                        'name' => $title,
                    'position' =>$position,
                    //'description'=>$description,
                    
                       
                        'image' => $image,
                         'Status' => 'Yes'
                        );
                $result = $this->Admin_model->add_details('team', $field_data);
                if($result){
                    $succ = "Data Added Successfully";
                    $data['succ']=$succ;
                }
           }
            //$cms = $this->Cms_model->fetch_all();
            //$data['cms'] = $cms;
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/team_details');
            $this->load->view('Webadmin/footer');
        }
        
        public function edit_team()
        {  
            
            if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
            $page = 'team';
            $data['page'] = $page;
            
            if($this->input->post('submit') == 'Submit')
            {
                
                $id = $this->input->post('id');
                $title = $this->input->post('title');
                  $position = $this->input->post('position');
               // $description = $this->input->post('desc');
             //$category = $this->input->post('category');
                
                $config['upload_path']   = './News/'; 
                $config['allowed_types'] = 'gif|jpg|png'; 
                $config['max_size']      = 2048; 
                $config['max_width']     = 3000; 
                $config['max_height']    = 2000;  
                $this->load->library('upload', $config);
                //$upload_data = $this->upload->data(); //Returns array of containing all of the data related to the file you uploaded.
               

                if ( ! $this->upload->do_upload('file')) {
                   $error = array('error' => $this->upload->display_errors()); 
                    $image = $this->input->post('old_img');
                     $data['error'] = $error;
                }

                else { 
                   // print_r($this->upload->data());exit();
                    $file_data = $this->upload->data();
                    $image = $file_data['file_name'];
                   
                   if($this->input->post('old_img') != "")
                        unlink('./News/'.$this->input->post('old_img'));


                }
               
                $field_data = array(
                     'name' => $title,
                    'position' =>$position,
                  //  'description'=>$description,
                    
                       
                        'image' => $image
                   
                       
                        );
                $result = $this->Admin_model->eidt_details('team', $field_data,$id);
                if($result){
                    $succ = "Data Updated Successfully";
                    $data['succ']=$succ;
                    $fetch = $this->Admin_model->fetch_single('team', $id);
                    $data['fetch'] = $fetch;
                    
                }
           }else{
            
                $id = $this->uri->segment(4);
                $fetch = $this->Admin_model->fetch_single('team', $id);
                $data['fetch'] = $fetch;
            
           }
            
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/team_details',$data);
            $this->load->view('Webadmin/footer');
        }
	//Start About-------------------------------------------------------------------------------------------
	function view_team()
	{
            if(!$this->session->userdata('is_logged_in'))
            {
            redirect('Webadmin/Login');
            }
            $page = 'team';
            $data['page'] = $page;
            
            $id = $this->uri->segment(4);
            $fetch = $this->Admin_model->fetch_single('team', $id);
            $data['fetch'] = $fetch;
            
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/team',$data);
            $this->load->view('Webadmin/footer');
	}
        
        public function delete_gallery()
	{
            
           $id = $this->input->get('id', TRUE);
            $fetch = $this->Admin_model->fetch_single('team',$id);
            if($fetch->image != "")
                 unlink('./News/'.$fetch->image);
           $blog = $this->Admin_model->delete_single('team', $id);
           if($blog){
               
                echo 'deleted';
           } 
            
	}
//End About---------------------------------------------------------------------------------------------
	

	
}


?>