<?php
class Banner_model extends CI_Model {
	
      function __construct() { 
         parent::__construct(); 
		 
      }
      
    public function fetch_all()
    {
        $this->db->select('*');
        //$this->db->where('status', 'Yes');
        $query=$this->db->get('nsn_banner');
        return $query->result();
        
    } 
    
    public function fetch_single($id)
    {
        $this->db->select('*');
        $this->db->where('id', $id);
        $query=$this->db->get('nsn_banner');
        return $query->row();
        
    } 
    
    public function add_details($data)
    {
        $query=$this->db->insert('nsn_banner',$data);
        return $query;
        
    }
    
    public function eidt_details($data, $id)
    {
        $this->db->where('id', $id);
        $this->db->update('nsn_banner',$data);
        return true;
        
    }
    
    public function delete_single($id)
    {
         $this->db->where('id', $id);
         $delete = $this->db->delete('nsn_banner'); 
         return $delete;
        
    }
	  
	  
}
?>