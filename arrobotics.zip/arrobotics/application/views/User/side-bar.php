<style>
body {
background: #F1F3FA;
}

/* Profile container */
.profile {
margin: 20px 0;
}

/* Profile sidebar */
.profile-sidebar {
padding: 20px 0 10px 0;
background: #fff;
}
.col-md-3{
padding:0 0 0 15px;
}

.profile-userpic img {
float: none;
margin: 0 auto;
width: 50%;
height: 50%;
-webkit-border-radius: 50% !important;
-moz-border-radius: 50% !important;
border-radius: 50% !important;
}

.profile-usertitle {
text-align: center;
margin-top: 20px;
}

.profile-usertitle-name {
color: #e62b4c;
font-size: 16px;
font-weight: 600;
margin-bottom: 7px;
}

.profile-usertitle-job {
text-transform: uppercase;
color: #5b9bd1;
font-size: 12px;
font-weight: 600;
margin-bottom: 15px;
}

.profile-usermenu {
margin-top: 30px;
padding:0px !important;
}

.profile-usermenu ul li {
border-bottom: 1px solid #f0f4f7;
}

.profile-usermenu ul li:last-child {
border-bottom: none;
}

.profile-usermenu ul li a {
color: #1261b9;
    font-size: 14px;
    font-weight: 400;
}

.profile-usermenu ul li a i {
margin-right: 8px;
font-size: 22px;
}

.profile-usermenu ul li a:hover {
background-color: #fafcfd;
color: #5b9bd1;
}

.profile-usermenu ul li.active {
border-bottom: none;
}

.profile-usermenu ul li.active a {
color: #e62b4c;
background-color: #f6f9fb;
border-left: 2px solid #e62b4c;
margin-left: -2px;
}

/* order Content */
.order-content {
padding: 20px;
background: #ffffff;
min-height: 460px;
}
.form_main {
width: 100%;
}
.form_main h4 {
font-family: roboto;
font-size: 20px;
font-weight: 300;
margin-bottom: 15px;
margin-top: 20px;
text-transform: uppercase;
}
.heading {
border-bottom: 1px solid #A9A59F;
padding-bottom: 9px;
position: relative;
}
.heading span {
background: #6D6C6A none repeat scroll 0 0;
bottom: -2px;
height: 3px;
left: 0;
position: absolute;
width: 75px;
}   
.form {
border-radius: 7px;
padding: 6px;
}
.txt[type="text"] {
border: 1px solid #ccc;
margin: 5px 0;
padding: 4px 0 4px 5px;
border-radius:5px;
width: 80%;
}
.txt[type="password"] {
border: 1px solid #ccc;
margin: 5px 0;
padding: 4px 0 4px 5px;
border-radius:5px;
width: 80%;
}
/*.txt2[type="submit"] {
background: #949390 none repeat scroll 0 0;
border: 1px solid #949390;
border-radius: 10px;
color: #fff;
font-size: 16px;
font-style: normal;
line-height: 35px;
margin: 10px 0;
padding: 0;

width: 12%;
}*/
.txt2:hover {
background: rgba(0, 0, 0, 0) none repeat scroll 0 0;
color: #949390;
transition: all 0.5s ease 0s;
}

</style>

<style>
.profile-userpic .profile-info #profile_image img {
width: 200px;
height: 200px;
}

.profile-userpic img {
float: none;
margin: 0 auto;
width: 50%;
height: 50%;
-webkit-border-radius: 50% !important;
-moz-border-radius: 50% !important;
border-radius: 50% !important;
}

.img-circle {
border-radius: 50%;
}

.carousel-inner>.item>a>img, .carousel-inner>.item>img, .img-responsive, .thumbnail a>img, .thumbnail>img {
display: block;
max-width: 100%;
height: auto;
}

img {
max-width: 100%;
}
.uploadbtn-input2 {
position: absolute;
top: 0;
width: 40px;
height: 40px;
opacity: 0;
}
.profile-userpic .uploadbtn2 {
position: absolute;
    bottom: 255px;
    right: 59px;
}

.uploadbtn2 {
width: 40px;
height: 40px;
background: #00a2ff;
color: #fff;
text-align: center;
line-height: 40px;
position: relative;
border-radius: 360px;
overflow: hidden;
right: 18px;
margin-top: -25px;
float: right;
}
#profile_image{position:relative; width: 100%;height: 100%;}
#profile_image #loader{position: absolute; top:35%;left:1%; width: 100%; height: 100%;}
#profile_image #loader img{width: 40px;height: 40px;}
</style>


<div class="col-md-3">
<div class="profile-sidebar">
<!-- SIDEBAR USERPIC -->
<div class="profile-userpic">



</div>
<!-- END SIDEBAR USERPIC -->
<!-- SIDEBAR USER TITLE -->
<div class="profile-usertitle">
<form id="upload-image" method="post" action="<?= base_url() ?>User/profile_upload" enctype="multipart/form-data">
<div class="profile-userpic">

<?php
if ($details->profile_image != "") {
$pic = base_url() . 'Banner/' . $details->profile_image;
} else {
$pic = base_url() . 'profile/no-image.png';
}
?>

<div class="profile-info">
<div id="profile_image">  
    <div id="loader" style="display: none;">
<img src='<?=base_url()?>reload.gif'>
</div> 
    
<img src="<?=$pic?>" class="img-responsive img-circle" alt="">
</div>
<input type="hidden" id="old_img" class="width-60" value="<?php echo $details->profile_image; ?>" name="old_img">
<!--<div>

<input type="hidden" id="old_img" class="width-60" value="<?php echo $details->profile_image; ?>" name="old_img">
<input type="file"   name="profile" id="photoimg" onchange="uploadProfle();"  accept="image/*" />
<label for="" id="choose-photo" style="margin-left: 115px;"><i style="font-size:24px; cursor: pointer;" class="fa fa-camera"></i> </label>

</div>-->


<div class="uploadbtn2">
<input type="file"  name="profile" id="photoimg" class="uploadbtn-input2" onchange="uploadProfle()" accept="image/*">
<i class="fa fa-camera" aria-hidden="true"></i>
</div>

</div>



</div>

</form>                               









<div class="profile-usertitle-name">
<span class="hidden-xs"><?=$details->name?></span>
</div>
<div class="profile-usertitle-job">
</div>
</div>
<!-- END SIDEBAR USER TITLE -->
<!-- SIDEBAR MENU -->
<div class="profile-usermenu">
<ul class="nav">
<li class="<?php if($page=='profile') {echo 'active';}?>">
<a href="<?=base_url()?>User">
<i class="fa fa-home" aria-hidden="true"></i>
<span class="hidden-xs">Personal<span> </a>
</li>

<!--<li class="<?php if($page=='orderlist') {echo 'active';}?>">
<a href="<?=base_url()?>User/orderlist">
<i class="fa fa-list-alt" aria-hidden="true"></i>
<span class="hidden-xs">Order List<span> </a>
</li>-->

<li>
<a href="#" data-toggle="modal" data-target="#myModalHorizontal">
<i class="fa fa-cog" aria-hidden="true"></i>
<span class="hidden-xs">Change Password<span> </a>
</li>
<li>
<a href="<?=base_url()?>User/logout">
<i class="fa fa-sign-out" aria-hidden="true"></i>
<span class="hidden-xs">Logout <span></a>
</li>



</ul>
</div>
<!-- END MENU -->

</div>
</div>

<!-- Modal Body -->
<div class="modal fade" id="myModalHorizontal" tabindex="-1" role="dialog" 
aria-labelledby="myModalLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<!-- Modal Header -->
<div class="modal-header">
<button type="button" class="close" 
data-dismiss="modal">
<span aria-hidden="true">&times;</span>
<span class="sr-only">Close</span>
</button>
<h4 class="modal-title" id="myModalLabel">
Change Password
</h4>
</div>

<!-- Modal Body -->
<div class="modal-body">

<form class="form-horizontal" role="form" method="post" action="<?=base_url()?>User/ChangePassword">
<div class="form-group">
<label  class="col-sm-4 control-label"
for="inputEmail3">Current Password</label>
<div class="col-sm-6">
<input type="password" name="current_password" value="<?=  base64_decode($details->password);?>" class="form-control" 
id="inputEmail3" placeholder="Password"/>
</div>
</div>
<div class="form-group">
<label class="col-sm-4 control-label"
for="inputPassword3" >New Password</label>
<div class="col-sm-6">
<input type="password" name="newpassword" class="form-control"
id="inputPassword3" placeholder="New Password"  required="" minlength="6"/>
<span style="color:red;"><?php echo form_error('newpassword'); ?></span>
</div>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-default"
data-dismiss="modal">
Close
</button>
<button type="submit" name="submit" value="submit" class="btn btn-primary">
Save changes
</button>
</div>

</form>






</div>

<!-- Modal Footer -->

</div>
</div>
</div>