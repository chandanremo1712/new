<div class="vd_content-wrapper">
<div class="vd_container">
<div class="vd_content clearfix">
<div class="vd_head-section clearfix">
<div class="vd_panel-header">
<ul class="breadcrumb">
<li><a href="<?php echo base_url()?>Webadmin/Dashboard">Home</a> </li>
<li><a href="<?php echo base_url()?>Webadmin/Job">Offer List</a> </li>
<li class="active"><?php if($this->uri->segment(3) == "edit_offer"){echo 'Edit';}elseif($this->uri->segment(3) == "add_job"){echo 'Add';}elseif($this->uri->segment(3)=="view_job"){echo 'View';}?> Offer </li>
</ul>
<div class="vd_panel-menu hidden-sm hidden-xs" data-intro="<strong>Expand Control</strong><br/>To expand content page horizontally, vertically, or Both. If you just need one button just simply remove the other button code." data-step=5  data-position="left">
<div data-action="remove-navbar" data-original-title="Remove Navigation Bar Toggle" data-toggle="tooltip" data-placement="bottom" class="remove-navbar-button menu"> <i class="fa fa-arrows-h"></i> </div>
<div data-action="remove-header" data-original-title="Remove Top Menu Toggle" data-toggle="tooltip" data-placement="bottom" class="remove-header-button menu"> <i class="fa fa-arrows-v"></i> </div>
<div data-action="fullscreen" data-original-title="Remove Navigation Bar and Top Menu Toggle" data-toggle="tooltip" data-placement="bottom" class="fullscreen-button menu"> <i class="glyphicon glyphicon-fullscreen"></i> </div>

</div>
</div>
</div>
<div class="vd_title-section clearfix">
<div class="vd_panel-header">
<h1><?php if($this->uri->segment(3) == "edit_offer"){echo 'Edit';}elseif($this->uri->segment(3) == "add_job"){echo 'Add';}elseif($this->uri->segment(3)=="view_job"){echo 'View';}?> Offer </h1>
</div>
</div>
<?php if($this->uri->segment(3) == 'edit_offer'){?>    
<div class="vd_content-section clearfix">
<div class="panel widget light-widget">
<div class="panel-heading no-title"> </div>
<div class="panel-body">
<?php if(isset($succ)){?>
<div class="alert alert-success alert-dismissable">
<button aria-hidden="true" data-dismiss="alert" class="close" type="button"><i class="icon-cross"></i></button>
<i class="fa fa-check-circle append-icon"></i><strong>Success!</strong> <?php echo $succ;?> 
</div>
<?php }?>    
<h2 class="mgbt-xs-20">Offer Details</h2>

<form class="form-horizontal"  action="<?php echo base_url()?>Webadmin/Weoffer/edit_offer" role="form1" method="post" id="register-form1" enctype="multipart/form-data">
<input type="hidden" name="id" value="<?php echo $cms->id;?>"> 



<div class="form-group">
<div class="col-md-12">
<label class="control-label  col-sm-2"> Title <span class="vd_red">*</span></label>
<div id="first-name-input-wrapper"  class="controls col-sm-10">
<input type="text" placeholder="Title" class="width-60 required" name="title" value="<?php echo $cms->title;?>" id="title" required >
</div>
</div>
</div> 


<div class="form-group">
<div class="col-md-12">
<label class="control-label  col-sm-2"> Price <span class="vd_red">*</span></label>
<div id="first-name-input-wrapper"  class="controls col-sm-10">
<input type="text" placeholder="Price" class="width-60 required" name="price" value="<?php echo $cms->price;?>" id="title" required >
</div>
</div>
</div>

<div class="form-group">
<div class="col-md-12">
<label class="control-label  col-sm-2"> Description <span class="vd_red">*</span></label>
<div id="first-name-input-wrapper"  class="controls col-sm-10">
<textarea name="description" placeholder="Description" data-rel="ckeditor" rows="3" ><?php echo $cms->description;?></textarea>
</div>
</div>
</div>

<div id="vd_login-error" class="alert alert-danger hidden"><i class="fa fa-exclamation-circle fa-fw"></i> Please fill the necessary field </div>
<div class="form-group">
<div class="col-sm-2"></div>
<div class="col-md-6 mgbt-xs-10 mgtp-20">

<div class="mgtp-10">
<input class="btn vd_bg-green vd_white" type="submit" id="submit-register" name="submit" value="Submit">
</div>
</div>
<div class="col-md-12 mgbt-xs-5"> </div>
</div>
</form>
</div>
</div>


</div>
<?php }elseif($this->uri->segment(3) == 'add_job'){?>
<div class="vd_content-section clearfix">
<div class="panel widget light-widget">
<div class="panel-heading no-title"> </div>
<div class="panel-body">
<?php if(isset($succ)){?>
<div class="alert alert-success alert-dismissable">
<button aria-hidden="true" data-dismiss="alert" class="close" type="button"><i class="icon-cross"></i></button>
<i class="fa fa-check-circle append-icon"></i><strong>Success!</strong> <?php echo $succ;?> 
</div>
<?php }?>    
<h2 class="mgbt-xs-20">Add Job</h2>

<form class="form-horizontal"  action="<?php echo base_url()?>Webadmin/Job/add_job" role="form1" method="post" id="register-form1" enctype="multipart/form-data">
<input type="hidden" name="cms_id" value=""> 

<div class="form-group">
<div class="col-md-12">
<label class="control-label  col-sm-2">Job Id <span class="vd_red">*</span></label>
<div id="first-name-input-wrapper"  class="controls col-sm-10">
    <input type="text" placeholder="Job Id" class="width-60 required" name="job_id" value="" id="job_id" required minlength="4">
</div>
</div>
</div> 


<div class="form-group">
<div class="col-md-12">
<label class="control-label  col-sm-2">Job Title <span class="vd_red">*</span></label>
<div id="first-name-input-wrapper"  class="controls col-sm-10">
<input type="text" placeholder="Title" class="width-60 required" name="title" value="" id="title" required >
</div>
</div>
</div> 

<div class="form-group">
<div class="col-md-12">
<label class="control-label  col-sm-2">Job Description <span class="vd_red">*</span></label>
<div id="first-name-input-wrapper"  class="controls col-sm-10">
<textarea name="desc" placeholder="Job Description" data-rel="ckeditor" rows="3" ></textarea>
</div>
</div>
</div> 



<div id="vd_login-error" class="alert alert-danger hidden"><i class="fa fa-exclamation-circle fa-fw"></i> Please fill the necessary field </div>
<div class="form-group">
<div class="col-sm-2"></div>
<div class="col-md-6 mgbt-xs-10 mgtp-20">

<div class="mgtp-10">
<input class="btn vd_bg-green vd_white" type="submit" id="submit-register" name="submit" value="Submit">
</div>
</div>
<div class="col-md-12 mgbt-xs-5"> </div>
</div>
</form>
</div>
</div>
<!-- Panel Widget -->

<!--            <div class="panel widget light-widget">
<div class="panel-heading no-title"> </div>
<div class="panel-body">
<h2 class="mgbt-xs-20">Form Type 2</h2>
<form class="form-horizontal"  action="#" role="form" id="register-form-2">
<div class="alert alert-danger vd_hidden">
<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="icon-cross"></i></button>
<span class="vd_alert-icon"><i class="fa fa-exclamation-circle vd_red"></i></span><strong>Oh snap!</strong> Change a few things up and try submitting again. </div>
<div class="alert alert-success vd_hidden">
<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="icon-cross"></i></button>
<span class="vd_alert-icon"><i class="fa fa-check-circle vd_green"></i></span><strong>Well done!</strong>. </div>
<div class="form-group">
<div class="col-md-6">
<div class="label-wrapper">
<label class="control-label">First Name <span class="vd_red">*</span></label>
</div>
<div class="vd_input-wrapper" id="first-name-input-wrapper"> <span class="menu-icon"> <i class="fa fa-user"></i> </span>
<input type="text" placeholder="John" class="required" required name="firstname" id="firstname">
</div>
</div>
<div class="col-md-6">
<div class="label-wrapper">
<label class="control-label">Last Name <span class="vd_red">*</span></label>
</div>
<div class="vd_input-wrapper" id="last-name-input-wrapper"> <span class="menu-icon"> <i class="fa fa-user"></i> </span>
<input type="text" placeholder="Doe" class="required" required name="lastname" id="lastname">
</div>
</div>
</div>
<div class="form-group">
<div class="col-md-12">
<div class="label-wrapper">
<label class="control-label">Company Name <span class="vd_red">*</span></label>
</div>
<div class="vd_input-wrapper" id="company-input-wrapper"> <span class="menu-icon"> <i class="fa fa-briefcase"></i> </span>
<input type="text" placeholder="Your Company Co, Ltd." class="required" required  name="company" id="company">
</div>
</div>
</div>
<div class="form-group ">
<div class="col-md-3">
<div class="label-wrapper">
<label class="control-label">Phone <span class="vd_red">*</span></label>
</div>
<div class="vd_input-wrapper" id="country-code-input-wrapper"> <span class="menu-icon"> <i class="fa fa-plus"></i> </span>
<input type="number" placeholder="Country" class="required" required  name="country" id="country">
</div>
</div>
<div class="col-md-9">
<div class="label-wrapper">
<label class="control-label">&nbsp;</label>
</div>
<div class="vd_input-wrapper no-icon" id="phone-input-wrapper">
<input type="number" placeholder="Phone Number" class="required" required  name="phone" id="phone">
</div>
</div>
</div>
<div class="form-group">
<div class="col-md-12">
<div class="label-wrapper">
<label class="control-label">Website</label>
</div>
<div class="vd_input-wrapper" id="website-input-wrapper"> <span class="menu-icon"> <i class="fa fa-globe"></i> </span>
<input type="text" placeholder="http://www.yourcompany.com" class=""  name="website" id="website">
</div>
</div>
</div>
<div class="form-group">
<div class="col-md-12">
<div class="label-wrapper">
<label class="control-label">Email <span class="vd_red">*</span></label>
</div>
<div class="vd_input-wrapper" id="email-input-wrapper"> <span class="menu-icon"> <i class="fa fa-envelope"></i> </span>
<input type="email" placeholder="Email" class="required" required  name="email" id="email">
</div>
</div>
</div>
<div class="form-group">
<div class="col-md-6">
<div class="label-wrapper">
<label class="control-label">Password <span class="vd_red">*</span></label>
</div>
<div class="vd_input-wrapper" id="password-input-wrapper"> <span class="menu-icon"> <i class="fa fa-lock"></i> </span>
<input type="password" placeholder="Password" class="required" required  name="password" id="password">
</div>
</div>
<div class="col-md-6">
<div class="label-wrapper">
<label class="control-label">Confirm Password <span class="vd_red">*</span></label>
</div>
<div class="vd_input-wrapper" id="confirm-password-input-wrapper"> <span class="menu-icon"> <i class="fa fa-lock"></i> </span>
<input type="password" placeholder="Password" class="required" required  name="confirmpass" id="confirmpass">
</div>
</div>
</div>
<div id="vd_login-error" class="alert alert-danger hidden"><i class="fa fa-exclamation-circle fa-fw"></i> Please fill the necessary field </div>
<div class="form-group">
<div class="col-md-12 mgbt-xs-10 mgtp-20">
<div class="vd_checkbox">
<input type="checkbox" id="checkbox-1" value="1">
<label for="checkbox-1"> Send me newsletter about the latest update</label>
</div>
<div class="vd_checkbox">
<input type="checkbox" id="checkbox-2" value="1" required name="checkbox-2">
<label for="checkbox-2"> I agree with <a href="#">terms of service</a></label>
</div>
</div>
<div class="col-md-12 mgbt-xs-5">
<button class="btn vd_bg-green vd_white" type="submit" id="submit-register" name="submit-register">Register</button>
</div>
</div>
</form>
</div>
</div>-->


</div>

<?php }else{?>
<div class="vd_content-section clearfix">
<div class="panel widget light-widget">
<div class="panel-heading no-title"> </div>
<div class="panel-body">

<h2 class="mgbt-xs-20">Job Details</h2>

<form class="form-horizontal"  action="<?php echo base_url()?>Webadmin/Job/edit_offer" role="form1" method="post" id="register-form1" enctype="multipart/form-data">
<input type="hidden" name="cms_id" value="<?php echo $cms->id;?>"> 

<div class="form-group">
<div class="col-md-12">
<label class="control-label  col-sm-2">Company Name <span class="vd_red">*</span></label>
<div id="first-name-input-wrapper"  class="controls col-sm-10">
<?php echo $cms->company_name;?>
</div>
</div>
</div> 


<div class="form-group">
<div class="col-md-12">
<label class="control-label  col-sm-2">Job Title <span class="vd_red">*</span></label>
<div id="first-name-input-wrapper"  class="controls col-sm-10">
<?php echo $cms->jobtitle;?>
</div>
</div>
</div> 

<div class="form-group">
<div class="col-md-12">
<label class="control-label  col-sm-2">Job Title <span class="vd_red">*</span></label>
<div id="first-name-input-wrapper"  class="controls col-sm-10">
<?php echo $cms->jobtitle;?>
</div>
</div>
</div> 

<div class="form-group">
<div class="col-md-12">
<label class="control-label  col-sm-2">Job Vacancy <span class="vd_red">*</span></label>
<div id="first-name-input-wrapper"  class="controls col-sm-10">
<?php echo $cms->job_vacancy;?>
</div>
</div>
</div> 


<div class="form-group">
<div class="col-md-12">
<label class="control-label  col-sm-2">Job Salary <span class="vd_red">*</span></label>
<div id="first-name-input-wrapper"  class="controls col-sm-10">
$<?php echo $cms->job_salary_from;?> - $<?php echo $cms->job_salary_to;?> / <?php echo $cms->job_salary_per;?>
</div>
</div>
</div> 

<div class="form-group">
<div class="col-md-12">
<label class="control-label  col-sm-2">Address <span class="vd_red">*</span></label>
<div id="first-name-input-wrapper"  class="controls col-sm-10">
<?php echo $cms->address;?>
</div>
</div>
</div>

<div class="form-group">
<div class="col-md-12">
<label class="control-label  col-sm-2">State <span class="vd_red">*</span></label>
<div id="first-name-input-wrapper"  class="controls col-sm-10">
<?php echo $cms->state;?>
</div>
</div>
</div>

<div class="form-group">
<div class="col-md-12">
<label class="control-label  col-sm-2">City <span class="vd_red">*</span></label>
<div id="first-name-input-wrapper"  class="controls col-sm-10">
<?php echo $cms->city;?>
</div>
</div>
</div>

<div class="form-group">
<div class="col-md-12">
<label class="control-label  col-sm-2">Zip <span class="vd_red">*</span></label>
<div id="first-name-input-wrapper"  class="controls col-sm-10">
<?php echo $cms->zip;?>
</div>
</div>
</div>

<div class="form-group">
<div class="col-md-12">
<label class="control-label  col-sm-2">Date Of Posting <span class="vd_red">*</span></label>
<div id="first-name-input-wrapper"  class="controls col-sm-10">
<?php echo $cms->date;?>
</div>
</div>
</div>






<div class="form-group">
<div class="col-md-12">
<label class="control-label  col-sm-2">Status<span class="vd_red">*</span></label>
<div id="first-name-input-wrapper"  class="controls col-sm-10">
<?php if($cms->status == 'Yes'){echo '<span class="label label-success">Active</span>';}else{ echo '<span class="label label-danger">Inactive</span>';}?>
</div>
</div>
</div> 

</form>
</div>
</div>


</div>

<?php }?>
</div>

</div>
<!-- .vd_container --> 
</div>
<!-- .vd_content-wrapper --> 

<!-- Middle Content End --> 

</div>
<!-- .container --> 
</div>
<!-- .content -->