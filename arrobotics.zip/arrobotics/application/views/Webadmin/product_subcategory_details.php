 <div class="vd_content-wrapper">
      <div class="vd_container">
        <div class="vd_content clearfix">
          <div class="vd_head-section clearfix">
            <div class="vd_panel-header">
              <ul class="breadcrumb">
                <li><a href="<?php echo base_url()?>Webadmin/Dashboard">Home</a> </li>
                <li><a href="<?php echo base_url()?>Webadmin/Product/subcategory_list">Sub Category List</a> </li>
                <li class="active"><?php if($this->uri->segment(3) == "edit_subcategory"){echo 'Edit';}elseif($this->uri->segment(3) == "add_subcategory"){echo 'Add';}elseif($this->uri->segment(3)=="view_subcategory"){echo 'View';}?> Sub Category </li>
              </ul>
              <div class="vd_panel-menu hidden-sm hidden-xs" data-intro="<strong>Expand Control</strong><br/>To expand content page horizontally, vertically, or Both. If you just need one button just simply remove the other button code." data-step=5  data-position="left">
    <div data-action="remove-navbar" data-original-title="Remove Navigation Bar Toggle" data-toggle="tooltip" data-placement="bottom" class="remove-navbar-button menu"> <i class="fa fa-arrows-h"></i> </div>
      <div data-action="remove-header" data-original-title="Remove Top Menu Toggle" data-toggle="tooltip" data-placement="bottom" class="remove-header-button menu"> <i class="fa fa-arrows-v"></i> </div>
      <div data-action="fullscreen" data-original-title="Remove Navigation Bar and Top Menu Toggle" data-toggle="tooltip" data-placement="bottom" class="fullscreen-button menu"> <i class="glyphicon glyphicon-fullscreen"></i> </div>
      
</div>
            </div>
          </div>
          <div class="vd_title-section clearfix">
            <div class="vd_panel-header">
              <h1><?php if($this->uri->segment(3) == "edit_subcategory"){echo 'Edit';}elseif($this->uri->segment(3) == "add_subcategory"){echo 'Add';}elseif($this->uri->segment(3)=="view_subcategory"){echo 'View';}?> Sub Category </h1>
              </div>
          </div>
        <?php if($this->uri->segment(3) == 'edit_subcategory'){?>    
          <div class="vd_content-section clearfix">
            <div class="panel widget light-widget">
              <div class="panel-heading no-title"> </div>
              <div class="panel-body">
               <?php if(isset($succ)){?>
                  <div class="alert alert-success alert-dismissable">
                        <button aria-hidden="true" data-dismiss="alert" class="close" type="button"><i class="icon-cross"></i></button>
                        <i class="fa fa-check-circle append-icon"></i><strong>Success!</strong> <?php echo $succ;?> 
                  </div>
               <?php }?>    
                <h2 class="mgbt-xs-20">Sub Category Details</h2>
            
                <form class="form-horizontal"  action="<?php echo base_url()?>Webadmin/Product/edit_subcategory" role="form1" method="post" id="register-form1" enctype="multipart/form-data">
                    <input type="hidden" name="id" value="<?php echo $fetch->id;?>"> 
                  <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Sub Category Name <span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <input type="text" placeholder="Sub Category Name" class="width-60 required" name="name" value="<?php echo $fetch->SubcatName;?>" id="title" required >
                      </div>
                    </div>
                  </div> 
                    
                 <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Select Category <span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <select name="catid" class="width-60 required">
                           <?php foreach($cat as $catz){ ?>
                              <option value="<?php echo $catz->id;?>" <?php if($catz->id == $fetch->CatId){echo 'selected';}?>><?php echo $catz->CatName;?></option>
                           <?php  }?>
                          </select>
                      </div>
                    </div>
                  </div> 
                 
                  <div id="vd_login-error" class="alert alert-danger hidden"><i class="fa fa-exclamation-circle fa-fw"></i> Please fill the necessary field </div>
                  <div class="form-group">
                    <div class="col-sm-2"></div>
                    <div class="col-md-6 mgbt-xs-10 mgtp-20">
                     
                      <div class="mgtp-10">
                          <input class="btn vd_bg-green vd_white" type="submit" id="submit-register" name="submit" value="Submit">
                      </div>
                    </div>
                    <div class="col-md-12 mgbt-xs-5"> </div>
                  </div>
                </form>
              </div>
            </div>
            
            
          </div>
        <?php }elseif($this->uri->segment(3) == 'add_subcategory'){?>
           <div class="vd_content-section clearfix">
            <div class="panel widget light-widget">
              <div class="panel-heading no-title"> </div>
              <div class="panel-body">
               <?php if(isset($succ)){?>
                  <div class="alert alert-success alert-dismissable">
                        <button aria-hidden="true" data-dismiss="alert" class="close" type="button"><i class="icon-cross"></i></button>
                        <i class="fa fa-check-circle append-icon"></i><strong>Success!</strong> <?php echo $succ;?> 
                  </div>
               <?php }?>    
                <h2 class="mgbt-xs-20">Category Details</h2>
            
                <form class="form-horizontal"  action="<?php echo base_url()?>Webadmin/Product/add_subcategory" role="form1" method="post" id="register-form1" enctype="multipart/form-data">
                    <input type="hidden" name="cms_id" value=""> 
                  <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Sub Category Name<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <input type="text" placeholder="Enter Sub Category Name" class="width-60 required" name="name" value="" id="title" required >
                      </div>
                    </div>
                  </div> 
                    
                  <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Category Name<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <select name="catid" class="width-60 required">
                           <?php foreach($cat as $catz){ ?>
                              <option value="<?php echo $catz->id;?>"><?php echo $catz->CatName;?></option>
                           <?php  }?>
                          </select>
                      </div>
                    </div>
                  </div> 
                 
               
                  <div id="vd_login-error" class="alert alert-danger hidden"><i class="fa fa-exclamation-circle fa-fw"></i> Please fill the necessary field </div>
                  <div class="form-group">
                    <div class="col-sm-2"></div>
                    <div class="col-md-6 mgbt-xs-10 mgtp-20">
                      
                      <div class="mgtp-10">
                          <input class="btn vd_bg-green vd_white" type="submit" id="submit-register" name="submit" value="Submit">
                      </div>
                    </div>
                    <div class="col-md-12 mgbt-xs-5"> </div>
                  </div>
                </form>
              </div>
            </div>
            <!-- Panel Widget -->
           
          </div>
         
        <?php }else{?>
         <div class="vd_content-section clearfix">
            <div class="panel widget light-widget">
              <div class="panel-heading no-title"> </div>
              <div class="panel-body">
               
                <h2 class="mgbt-xs-20">Sub Category Details</h2>
            
                <form class="form-horizontal"  action="" role="form1" method="post" id="register-form1" enctype="multipart/form-data">
                    <input type="hidden" name="id" value="<?php echo $fetch->id;?>"> 
                  <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Sub Category Name <span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <?php echo $fetch->SubcatName;?>
                      </div>
                    </div>
                  </div> 
                    
                  <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Category Name <span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <?php echo $fetch->CatName;?>
                      </div>
                    </div>
                  </div> 
                  
                   
                   <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Status<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <?php if($fetch->Status == 'Yes'){echo '<span class="label label-success">Active</span>';}else{ echo '<span class="label label-danger">Inactive</span>';}?>
                      </div>
                    </div>
                  </div> 
                  
                </form>
              </div>
            </div>
            
            
          </div>
            
        <?php }?>
        </div>
       
      </div>
      <!-- .vd_container --> 
    </div>
    <!-- .vd_content-wrapper --> 
    
    <!-- Middle Content End --> 
    
  </div>
  <!-- .container --> 
</div>
<!-- .content -->