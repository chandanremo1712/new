
<!-- Start main-content -->
<div class="main-content bg-lighter">
<!-- Section: inner-header -->
<section class="inner-header divider parallax layer-overlay overlay-dark-5" data-bg-img="<?=base_url()?>images/bg/bg6.jpg">
<div class="container pt-70 pb-20">
<!-- Section Content -->
<div class="section-content">
<div class="row">
<div class="col-md-12">
<h2 class="title text-white text-center">Services</h2>
<ol class="breadcrumb text-left text-black mt-10">
<li><a href="#">Home</a></li>
<!--<li><a href="#">Pages</a></li>-->
<li class="active text-gray-silver">Services</li>
</ol>
</div>
</div>
</div>
</div>
</section>

<!-- Section: Project -->
<section>
<div class="container pb-40">
<div class="section-title text-center">
<div class="row">
<div class="col-md-8 col-md-offset-2">
<h2 class="mt-0 line-height-1 text-center text-uppercase mb-10 text-black-333">Our <span class="text-theme-color-2"> Services</span></h2>
<!--<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem autem<br> voluptatem obcaecati!</p>-->
</div>
</div>
</div>
<div class="row multi-row-clearfix">
<div class="col-md-12">
<div class="owl-carousel-3col owl-nav-top" data-dots="true">
<?php
 $courses=$this->Admin_model->fetch_all_join("select * from courses where Status='Yes' order by id desc");
 
 foreach($courses as $course){
     
      
if($course->CourseImage!="")
{   
$pic = base_url().'News/'.$course->CourseImage;
}
else
{
    
$pic =  base_url()."News/noimg.png";
}
 
 ?>
<div class="item">
<div class="project mb-30 border-2px">
<a href="<?=base_url()?>servicedetails/<?=$course->id?>">
<div class="thumb">
 
<img class="img-fullwidth" alt="" src="<?=$pic?>" style="height:300px;">
</div>
</a>
    

<div class="project-details p-15 pt-10 pb-10">
<!--<h5 class="font-14 font-weight-500 mb-5"></h5>-->
<h4 class="font-weight-700 text-uppercase mt-0"><a href="<?=base_url()?>servicedetails/<?=$course->id?>"><?=$course->CourseTitle?></a></h4>

<?=substr($course->CourseDesc,0,85)?>

</div>
</div>
</div>
    
<?php } ?>
    
</div>
</div>
</div>
</div>
</section>

</div>
<!-- end main-content -->

<!-- Footer -->
