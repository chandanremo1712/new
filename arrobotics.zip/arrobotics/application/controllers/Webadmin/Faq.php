<?php
defined('BASEPATH') OR exit('No Direct Script access allowed');

class Faq extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Webadmin/Admin_model');
                $this->load->helper("file");

                
	}
	
	public function index()
        {
            if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
            $page = 'faq';
            $data['page'] = $page;
            
            $fetch = $this->Admin_model->fetch_all('nsn_faq');
            $data['fetch'] = $fetch;
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/faq');
            $this->load->view('Webadmin/footer');
        }
	
        public function add_faq()
        {
            if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
            $page = 'faq';
            $data['page'] = $page;
            
            $image = "";
            if($this->input->post('submit') == 'Submit')
            {
                $title = $this->input->post('title');
                $description = $this->input->post('desc');
                
                $field_data = array(
                        'FaqTitle' => addslashes($title),
                        'FaqDesc' => addslashes($description),
                        'FaqDate' => date('Y-m-d H:i:s'),
                        'Status' => 'Yes'
                        );
                $result = $this->Admin_model->add_details('nsn_faq', $field_data);
                if($result){
                    $succ = "Data Added Successfully";
                    $data['succ']=$succ;
                }
           }
            //$cms = $this->Cms_model->fetch_all();
            //$data['cms'] = $cms;
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/faq_details');
            $this->load->view('Webadmin/footer');
        }
        
        public function edit_faq()
        {   if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
            $page = 'faq';
            $data['page'] = $page;
            
            if($this->input->post('submit') == 'Submit')
            {
                
                $id = $this->input->post('id');
                $title = $this->input->post('title');
                $description = $this->input->post('desc');
                
                
                $field_data = array(
                        'FaqTitle' => addslashes($title),
                        'FaqDesc' => addslashes($description)
                        );
                $result = $this->Admin_model->eidt_details('nsn_faq', $field_data,$id);
                if($result){
                    $succ = "Data Updated Successfully";
                    $data['succ']=$succ;
                    $fetch = $this->Admin_model->fetch_single('nsn_faq', $id);
                    $data['fetch'] = $fetch;
                    
                }
           }else{
            
                $id = $this->uri->segment(4);
                $fetch = $this->Admin_model->fetch_single('nsn_faq', $id);
                $data['fetch'] = $fetch;
            
           }
            
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/faq_details',$data);
            $this->load->view('Webadmin/footer');
        }
	//Start About-------------------------------------------------------------------------------------------
	function view_faq()
	{
            if(!$this->session->userdata('is_logged_in'))
            {
            redirect('Webadmin/Login');
            }
            $page = 'faq';
            $data['page'] = $page;
            
            $id = $this->uri->segment(4);
            $fetch = $this->Admin_model->fetch_single('nsn_faq', $id);
            $data['fetch'] = $fetch;
            
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/faq_details',$data);
            $this->load->view('Webadmin/footer');
	}
        
        public function delete_faq()
	{
            
           $id = $this->input->get('id', TRUE);
           
           $faq = $this->Admin_model->delete_single('nsn_faq', $id);
           if($faq){
               
                echo 'deleted';
           } 
            
	}
        
        public function change_status()
        {
            $tbl = $this->uri->segment(4);
            echo $tbl;exit();
            $id = $this->input->get('id', TRUE);
            $val = $this->input->get('val');
            $field_data = array(
                       'Status' => $val
                       );
            $result = $this->Admin_model->eidt_details('nsn_faq', $field_data,$id);
            if($result)
            {
                echo 'Status Changed';
            }
        }
//End About---------------------------------------------------------------------------------------------
	

	
}


?>