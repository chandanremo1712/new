<?php
class Users_signup extends CI_Model
{
	function __construct()
	{
		parent::__construct();
	}
        
         function cart($data)
	{
          		 $query=$this->db->insert('cart',$data);
             		return $query;
	}
        
           function checkout($data)
	{
          		 $query=$this->db->insert('order_details',$data);
             		return $query;
	}
        
        function registereuser($data)
	{
          		 $query=$this->db->insert('user',$data);
             		return $query;
	}
	
	function registeremployer($data)
	{
          		 $query=$this->db->insert('employer',$data);
             		return $query;
	}
        
        function registeremployee($data)
	{
          		 $query=$this->db->insert('employee',$data);
             		return $query;
	}
        
        
       function jobs($data)
	{
          		 $query=$this->db->insert('jobs',$data);
             		return $query;
	} 
        
            function advertiser($data)
	{
          		 $query=$this->db->insert('advertiser',$data);
             		return $query;
	} 
        
        
        
        
        	function register_tutor($data)
	{
          		 $query=$this->db->insert('tutor',$data);
                         //echo $this->load->last_query();exit();
             		return $query;
	}
        

	
	function register_foodtruck($data)
	{
		$query=$this->db->insert('foodtruck',$data);
		return $query;
	}
	
	
	function fetch_mentor_register($email)
	{
		$this->db->where('email',$email);
		$query=$this->db->get('mentor_registrations');
		return $query->row();
	}
	
	function fetch_mentee_register($email)
	{
		$this->db->where('email',$email);
		$query=$this->db->get('mentee_registrations');
		return $query->row();
	}
	
	
	
	function mentor_status($email,$data)
	{
		$this->db->where('email',$email);	
		$query=$this->db->update('mentor_registrations',$data);
		return $query;
	}
	
	function mentee_status($email,$data)
	{
		$this->db->where('email',$email);	
		$query=$this->db->update('mentee_registrations',$data);
		return $query;
	}
}


?>