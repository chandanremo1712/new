
<!-- Start main-content -->
<div class="main-content bg-lighter">
<!-- Section: inner-header -->
<section class="inner-header divider parallax layer-overlay overlay-dark-5" data-bg-img="<?=base_url()?>images/bg/bg6.jpg">
<div class="container pt-70 pb-20">
<!-- Section Content -->
<div class="section-content">
<div class="row">
<div class="col-md-12">
<h2 class="title text-white text-center">About</h2>
<ol class="breadcrumb text-left text-black mt-10">
<li><a href="#">Home</a></li>

<li class="active text-gray-silver">About Us</li>
</ol>
</div>
</div>
</div>
</div>
</section>

<!-- Section: About -->
<section id="about" style="font-size: 18px;">
<div class="container mt-50 pb-70 pt-0">
<div class="section-content">
<div class="row mt-10">
<div class="col-sm-12 col-md-12 mb-sm-20 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.5s">
<h3 class="text-uppercase mt-15"> <span class="text-theme-color-2"><?=$about->title?> </span></h3>


<?=$about->description?>

</div>

  </div>
</div>
</div>
</section>




<!-- Section: teachers -->
<!--<section class="bg-lightest">
<div class="container pt-50 pb-80">
<div class="section-content">
<div class="row">
<div class="col-md-6 wow mt-20 fadeInRight" data-wow-duration="1s" data-wow-delay="0.3s">
<h3 class="text-uppercase title line-bottom mt-0 mb-30">Our <span class="text-theme-color-2">Teachers</span></h3>
<div class="owl-carousel-2col">
<div class="item">
<div class="team-members border-bottom-theme-color-2px text-center maxwidth400">
<div class="team-thumb">
<img class="img-fullwidth" alt="" src="<?=base_url()?>images/team/lg2.jpg">
<div class="team-overlay"></div>
</div>
<div class="team-details bg-silver-light pt-10 pb-10">
<h4 class="text-uppercase font-weight-600 m-5"><a href="#">Jhon Smith</a></h4>
<h6 class="text-theme-colored font-15 font-weight-400 mt-0">Teacher Designation</h6>
<ul class="styled-icons icon-theme-colored icon-dark icon-circled icon-sm">
<li><a href="#"><i class="fa fa-facebook"></i></a></li>
<li><a href="#"><i class="fa fa-twitter"></i></a></li>
<li><a href="#"><i class="fa fa-instagram"></i></a></li>
<li><a href="#"><i class="fa fa-skype"></i></a></li>
</ul>
</div>
</div>
</div>
<div class="item">
<div class="team-members border-bottom-theme-color-2px text-center maxwidth400">
<div class="team-thumb">
<img class="img-fullwidth" alt="" src="<?=base_url()?>images/team/lg3.jpg">
<div class="team-overlay"></div>
</div>
<div class="team-details bg-silver-light pt-10 pb-10">
<h4 class="text-uppercase font-weight-600 m-5"><a href="#">Jhon Smith</a></h4>
<h6 class="text-theme-colored font-15 font-weight-400 mt-0">Teacher Designation</h6>
<ul class="styled-icons icon-theme-colored icon-dark icon-circled icon-sm">
<li><a href="#"><i class="fa fa-facebook"></i></a></li>
<li><a href="#"><i class="fa fa-twitter"></i></a></li>
<li><a href="#"><i class="fa fa-instagram"></i></a></li>
<li><a href="#"><i class="fa fa-skype"></i></a></li>
</ul>
</div>
</div>
</div>
<div class="item">
<div class="team-members border-bottom-theme-color-2px text-center maxwidth400">
<div class="team-thumb">
<img class="img-fullwidth" alt="" src="<?=base_url()?>images/team/lg4.jpg">
<div class="team-overlay"></div>
</div>
<div class="team-details bg-silver-light pt-10 pb-10">
<h4 class="text-uppercase font-weight-600 m-5"><a href="#">Jhon Smith</a></h4>
<h6 class="text-theme-colored font-15 font-weight-400 mt-0">Teacher Designation</h6>
<ul class="styled-icons icon-theme-colored icon-dark icon-circled icon-sm">
<li><a href="#"><i class="fa fa-facebook"></i></a></li>
<li><a href="#"><i class="fa fa-twitter"></i></a></li>
<li><a href="#"><i class="fa fa-instagram"></i></a></li>
<li><a href="#"><i class="fa fa-skype"></i></a></li>
</ul>
</div>
</div>
</div>
</div>
</div>
<div class="col-md-6 wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.3s">
<h3 class="text-uppercase ml-15 title line-bottom">Next <span class="text-theme-color-2 font-weight-700">Events</span></h3>
<div class="bxslider bx-nav-top p-0 m-0">
<div class="col-xs-12 pr-0 col-sm-6 col-md-6 mb-20">
<div class="pricing table-horizontal maxwidth400">
<div class="row">
<div class="col-md-6">
<div class="thumb">
<img class="img-fullwidth mb-sm-0" src="<?=base_url()?>images/about/as1.jpg" alt="">
</div>
</div>
<div class="col-md-6 p-10 pl-sm-50">
<h4 class="mt-0 mb-5 mt-10"><a href="#" class="text-white">Upcoming Event Title</a></h4>
<ul class="list-inline font-16 mb-5 text-white">
<li class="pr-0"><i class="fa fa-calendar mr-5"></i> June 26, 2016 |</li>
<li class="pl-5"><i class="fa fa-map-marker mr-5"></i>New York</li>
</ul>
<p class="mb-0 font-13 text-white mr-5 pr-10">Lorem ipsum dolor sit amet, conse ctetur adipisicing elit. Quas eveniet.</p>
<a class="font-16  text-white mt-20" href="#">Read More →</a>
</div>
</div>
</div>
</div>
<div class="col-xs-12 pr-0 col-sm-6 col-md-6 mb-30">
<div class="pricing table-horizontal maxwidth400">
<div class="row">
<div class="col-md-6">
<div class="thumb">
<img class="img-fullwidth mb-sm-0" src="<?=base_url()?>images/about/as2.jpg" alt="">
</div>
</div>
<div class="col-md-6 p-10 pl-sm-50">
<h4 class="mt-0 mb-5 mt-10"><a href="#" class="text-white">Upcoming Event Title</a></h4>
<ul class="list-inline font-16 mb-5 text-white">
<li class="pr-0"><i class="fa fa-calendar mr-5"></i> June 26, 2016 |</li>
<li class="pl-5"><i class="fa fa-map-marker mr-5"></i>New York</li>
</ul>
<p class="mb-0 font-13 text-white mr-5 pr-10">Lorem ipsum dolor sit amet, conse ctetur adipisicing elit. Quas eveniet.</p>
<a class="font-16  text-white mt-20" href="#">Read More →</a>
</div>
</div>
</div>
</div>
<div class="col-xs-12 pr-0 col-sm-6 col-md-6 mb-30">
<div class="pricing table-horizontal maxwidth400">
<div class="row">
<div class="col-md-6">
<div class="thumb">
<img class="img-fullwidth mb-sm-0" src="<?=base_url()?>images/about/as3.jpg" alt="">
</div>
</div>
<div class="col-md-6 p-10 pl-sm-50">
<h4 class="mt-0 mb-5 mt-10"><a href="#" class="text-white">Upcoming Event Title</a></h4>
<ul class="list-inline font-16 mb-5 text-white">
<li class="pr-0"><i class="fa fa-calendar mr-5"></i> June 26, 2016 |</li>
<li class="pl-5"><i class="fa fa-map-marker mr-5"></i>New York</li>
</ul>
<p class="mb-0 font-13 text-white mr-5 pr-10">Lorem ipsum dolor sit amet, conse ctetur adipisicing elit. Quas eveniet.</p>
<a class="font-16  text-white mt-20" href="#">Read More →</a>
</div>
</div>
</div>
</div>
<div class="col-xs-12 pr-0 col-sm-6 col-md-6 mb-30">
<div class="pricing table-horizontal maxwidth400">
<div class="row">
<div class="col-md-6">
<div class="thumb">
<img class="img-fullwidth mb-sm-0" src="<?=base_url()?>images/about/as4.jpg" alt="">
</div>
</div>
<div class="col-md-6 p-10 pl-sm-50">
<h4 class="mt-0 mb-5 mt-10"><a href="#" class="text-white">Upcoming Event Title</a></h4>
<ul class="list-inline font-16 mb-5 text-white">
<li class="pr-0"><i class="fa fa-calendar mr-5"></i> June 26, 2016 |</li>
<li class="pl-5"><i class="fa fa-map-marker mr-5"></i>New York</li>
</ul>
<p class="mb-0 font-13 text-white mr-5 pr-10">Lorem ipsum dolor sit amet, conse ctetur adipisicing elit. Quas eveniet.</p>
<a class="font-16  text-white mt-20" href="#">Read More →</a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>-->


<section class="divider parallax layer-overlay" data-bg-img="<?=base_url()?>images/bg/bg6.jpg" data-parallax-ratio="0.7">
<div class="container pt-70 pb-60">
<div class="row">
<div class="col-xs-12 col-sm-6 col-md-3 mb-md-50">
<div class="funfact text-center">
<i class="fa fa-clock-o mt-5 text-white"></i>
<h2 data-animation-duration="2000" data-value="10" class="animate-number text-white mt-0 font-38 font-weight-500">0</h2>
<h4 class="text-white text-uppercase">Years Experience</h4>
</div>
</div>
<div class="col-xs-12 col-sm-6 col-md-3 mb-md-50">
<div class="funfact text-center">
<i class="fa fa-users mt-5 text-white"></i>
<h2 data-animation-duration="2000" data-value="20" class="animate-number text-white mt-0 font-38 font-weight-500">0</h2>
<h4 class="text-white text-uppercase">Partners</h4>
</div>
</div>
<div class="col-xs-12 col-sm-6 col-md-3 mb-md-50">
<div class="funfact text-center">
<i class="fa fa-home mt-5 text-white"></i>
<h2 data-animation-duration="2000" data-value="204" class="animate-number text-white mt-0 font-38 font-weight-500">0</h2>
<h4 class="text-white text-uppercase">Class Rooms</h4>
</div>
</div>
<div class="col-xs-12 col-sm-6 col-md-3 mb-md-50">
<div class="funfact text-center">
<i class="fa  fa-graduation-cap mt-5 text-white"></i>
<h2 data-animation-duration="2000" data-value="2324" class="animate-number text-white mt-0 font-38 font-weight-500">0</h2>
<h4 class="text-white text-uppercase">Students</h4>
</div>
</div>
</div>
</div>
</section>

<section id="teachers">
<div class="container pt-70 pb-70">
<div class="section-title text-center">
<div class="row">
<div class="col-md-8 col-md-offset-2">
<h2 class="mt-0 line-height-1 text-center text-uppercase mb-10 text-black-333">Our <span class="text-theme-color-2"> Team</span></h2>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem autem<br> voluptatem obcaecati!</p>
</div>
</div>
</div>
<div class="row mtli-row-clearfix">
<div class="col-md-12">
<div class="owl-carousel-4col">
<?php
$team=$this->Admin_model->fetch_all_join("select * from team where Status='Yes' order by id desc");
foreach($team as $member){

if($member->image!="")
{
$pic=base_url().'News/'.$member->image;
}
else{

$pic =  base_url()."News/noimg.png";
}

?>

<div class="item">
<div class="team-members border-bottom-theme-color-2px text-center maxwidth400">
<div class="team-thumb">
<img class="img-fullwidth" alt="" src="<?=$pic?>" style="height: 350px;">
<div class="team-overlay"></div>
</div>
<div class="team-details bg-silver-light pt-10 pb-10">
<h4 class="text-uppercase font-weight-600 m-5"><a href="#"><?=$member->name?></a></h4>
<h6 class="text-theme-colored font-15 font-weight-400 mt-0"><?=$member->position?></h6>
</div>
</div>
</div>
<?php } ?>

</div>
</div>
</div>
</div>
</section>

 

</div>
<!-- end main-content -->

