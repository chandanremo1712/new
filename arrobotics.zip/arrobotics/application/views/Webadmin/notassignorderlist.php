  <link href="<?php echo base_url();?>backend/css/bootstrap.min.css" rel="stylesheet" type="text/css">

<style>
    .rTable { display: table; }
.rTableRow { display: table-row; }
.rTableHeading { display: table-header-group; }
.rTableBody { display: table-row-group; }
.rTableFoot { display: table-footer-group; }
.rTableCell, .rTableHead { display: table-cell; }

.rTable {
  	display: table;
  	width: 100%;
}
.rTableRow {
  	display: table-row;
}
.rTableHeading {
  	display: table-header-group;
  	background-color: #ddd;
}
.rTableCell, .rTableHead {
  	display: table-cell;
  	padding: 3px 10px;
  	border: 1px solid #999999;
}
.rTableHeading {
  	display: table-header-group;
  	background-color: #ddd;
  	font-weight: bold;
}
.rTableFoot {
  	display: table-footer-group;
  	font-weight: bold;
  	background-color: #ddd;
}
.rTableBody {
  	display: table-row-group;
}


</style>
    <!-- Middle Content Start -->
    
    <div class="vd_content-wrapper">
      <div class="vd_container">
        <div class="vd_content clearfix">
          <div class="vd_head-section clearfix">
            <div class="vd_panel-header">
              <ul class="breadcrumb">
                <li><a href="<?php echo base_url().'Webadmin/Dashboard/';?>">Home</a> </li>
                <li class="active">Order  List</li>
              </ul>
              <div class="vd_panel-menu hidden-sm hidden-xs" data-intro="<strong>Expand Control</strong><br/>To expand content page horizontally, vertically, or Both. If you just need one button just simply remove the other button code." data-step=5  data-position="left">
    <div data-action="remove-navbar" data-original-title="Remove Navigation Bar Toggle" data-toggle="tooltip" data-placement="bottom" class="remove-navbar-button menu"> <i class="fa fa-arrows-h"></i> </div>
      <div data-action="remove-header" data-original-title="Remove Top Menu Toggle" data-toggle="tooltip" data-placement="bottom" class="remove-header-button menu"> <i class="fa fa-arrows-v"></i> </div>
      <div data-action="fullscreen" data-original-title="Remove Navigation Bar and Top Menu Toggle" data-toggle="tooltip" data-placement="bottom" class="fullscreen-button menu"> <i class="glyphicon glyphicon-fullscreen"></i> </div>
      
</div>
 
            </div>
          </div>
          <div class="vd_title-section clearfix">
 <div class="vd_title-section clearfix">
            <div class="vd_panel-header">
              <h1>Not Assign Order  List </h1>
              
              
            </div>
          </div>
          </div>
          <div class="vd_content-section clearfix">
            <div class="row">
              <div class="col-md-12">
                <div class="panel widget portlet">
                  <div class="panel-heading vd_bg-grey">
                    <h3 class="panel-title"> <span class="menu-icon"> <i class="fa fa-dot-circle-o"></i> </span> Order  List 
                        
                    </h3>
                  </div>
                   <div class="tools">
                        <a href="javascript:;" class="collapse"></a>
                        <a href="#portlet-config" data-toggle="modal" class="config"></a>
                        <a href="javascript:;" class="reload"></a>
                        <a href="javascript:;" class="remove"></a>
                </div>
                  <div class="panel-body table-responsive">
                      
                      
                    <table class="table table-striped" id="data-tables">
                        <div class="clearfix"></div>
                        <br/>
                        
                        <div class="clearfix"></div>
                        <br/>
                      <thead>
                        <tr>
                            
                          <th>Nos.</th>
                          <th>Order_id</th>
                         <th>Customer Id</th>
                           <th>Customer Name</th>
                           <th>Post Code</th>
                                <th>Order Details</th>
                    
                        <th>Outlet Extra Order</th>
                          <th>Payment Status</th>
                          
<th>Collection Details</th>
<th>Delivery Details</th>
                          <th>Status</th>
                          <th>Assign To</th>
                        </tr>
                      </thead>
                      <tbody>
                         <?php 
                          // print_r($fetch);
                         $i=1;
                         $count = 1;
                         foreach($fetch as $fetchz)
                           
                         {  
                          ?>
                          <tr class="odd gradeX" id="banner<?php echo $fetchz->id;?>">
                              
                          <td width="5%"><?=$count;?></td>
                             <td><?=$fetchz->order_id;?></td>
                            <td><?=$fetchz->user_id;?></td>
                             <?php
                            $user_details=$this->Admin_model->fetch_single_join("select * from user where user_id='$fetchz->user_id'");
                            ?>
                            
                             <td><?=$user_details->name;?></td>
                            <td><?=$fetchz->postcode;?></td>
                      <th><a href="#" data-toggle="modal" data-target="#myModal<?=$count?>" data-toggle="tooltip"  class="btn menu-icon vd_bd-yellow vd_yellow" title="View Details"> <i class="fa fa-eye"></i> </a></th>
     <!--<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Modal</button>-->               
                         
              <div class="modal fade" id="myModal<?=$count?>" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Order Details</h4>
        </div>
      
          
        <div class="modal-body">
          <!--<p>Some text in the modal.</p>-->
            
            <div class="rTable">
<div class="rTableRow">
<div class="rTableHead"><strong>Name</strong></div>
<div class="rTableHead"><span style="font-weight: bold;">Service</span></div>
<div class="rTableHead">Quantity</div>
<div class="rTableHead">Price(£)</div>
<div class="rTableHead">Subtotal(£)</div>
</div>
          <?php
          $total=0;
         $ord=$this->Admin_model->fetch_all_join("select * from order_details where order_id='$fetchz->order_id'");
            foreach($ord as $ord_details){
                $product_id=$ord_details->product_id;
                
                $product_details=$this->Admin_model->fetch_row('nsn_product','id="'.$product_id.'"');
                
                
         ?>         
<div class="rTableRow">
<div class="rTableCell"><?=$product_details->title?></div>
<?php
$cat=$this->Admin_model->fetch_row('category','id="'.$product_details->category.'"');
?>

<div class="rTableCell"><?=$cat->category?></div>
<div class="rTableCell"><?=$ord_details->quantity?></div>
<div class="rTableCell"><?=$ord_details->price?></div>
<?php

$subtotal=$ord_details->quantity*$ord_details->price;
$total=$total+$subtotal;
?>
<div class="rTableCell"><?=$subtotal?></div>
</div>
               <?php } ?>         
                
                <b>Total Amount: £<?=$total?></b>
</div>
            
        </div>
          
                  
          
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>   
 
                      
  <td>
     <button type="button" class="btn btn-info" data-toggle="modal" data-target="#exampleModal<?=$i?>">View</button>
    


<div class="modal fade" id="exampleModal<?=$i?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog" role="document">
<div class="modal-content">
  <div class="modal-header">
    <!--<h5 class="modal-title" id="exampleModalLabel"></h5>-->
     <h4 class="modal-title">Extra Order Added By Outlet</h4>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
    
<form id="form_new" method="post" action="<?=base_url()?>Outlets/updateinfo"> 
     <input type="hidden" name="order_id" value="<?=$fetchz->order_id?>">
<div class="modal-body">     
      <div class="form-group">
<!--<label for="recipient-name" class="col-form-label">Services Taken:</label>-->
<?php
$cnt=1;
 $fetch_services=$this->Admin_model->fetch_all_join("select * from order_details where (order_id='$fetchz->order_id')");
//echo $this->db->last_query();
 foreach($fetch_services as $service_details){
     
     $product_id=$service_details->product_id;
     
     $get_details=$this->Admin_model->fetch_row('nsn_product',"Id=$product_id");
     
     //echo $this->db->last_query();
         
      $cat=$get_details->category;
      
       $get_cat=$this->Admin_model->fetch_row('category',"id=$cat");
?>

<!--<p><?=$get_cat->category?></p>-->



<?php $cnt++;} ?>

</div>
 <div class="row"> 
     <div class="col-md-6">
        
<div class="form-group">
<label for="recipient-name" class="col-form-label">Number Of Bags:</label>
<input type="text" class="form-control bags" id="quantity" name="bags" value="<?=$fetchz->bags?>"  required="">
</div>
     </div>
         <div class="col-md-6">
    <div class="form-group">
<label for="recipient-name" class="col-form-label">Total Weight Of Bags:</label>
<input type="text" class="form-control weight" id="quantity1" name="weight" value="<?=$fetchz->weight?>" required>
</div>
 </div>
 </div>
      <div class="form-group">
              <label for="recipient-name" class="col-form-label">Cost(£):</label><br>
<input type="text" class="form-control cost" id="cost" name="cost" required value="<?=$fetchz->cost?>">
</div>

<div class="form-group">
    <label for="message-text" class="col-form-label">Extra Services(If any):</label><br>
<textarea class="form-control" id="extra_services" name="extra_services" style="width:486px;"><?=$fetchz->extra_services?></textarea>
</div>

    <br>
    
<div class="form-group">
    <label for="message-text" class="col-form-label">Description:</label><br>
<textarea class="form-control" id="description" name="description" required style="width:486px;"><?=$fetchz->description?></textarea>
</div>
    <br>
    
            
</div>
 
<div class="modal-footer">
<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
<!--<button type="submit" class="btn btn-primary" name="submit" value="submit">Update</button>-->
</div>
    
</form>

    
</div>
</div>
</div>
</td>                             
                         
                         
                         
                         
                         
                         
                         
                          <?php
                            if($fetchz->payment_status=='0')
                            {
                              $payment='Not Paid';  
                            }
 else {
     $payment='Paid'; 
 }  ?>
                            <td><?=$payment;?></td>
                            
                       
                            
                            
                            
                            
 <td>
 <!--<button class="btn btn-view btn-xs" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><i class="fa fa-eye" aria-hidden="true"></i></button>-->
    <button type="button" class="btn btn-info " data-toggle="modal" data-target="#myModal_coll<?=$i?>">View</button>
<!-- Modal -->
<div class="modal fade" id="myModal_coll<?=$i?>" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Collection Details</h4>
        </div>
        <div class="modal-body">
          <p>Collection Address : <?=$fetchz->collection_address?></p>
          <p>Collection Date : <?php echo date("j M y", strtotime($fetchz->collection_date));?></p>
          <p>Collection Time : From <?=$fetchz->collection_start_time?> - To <?=$fetchz->collection_end_time?></p>
        </div>
        
      </div>
      
    </div>
  </div>

</td>



<td>
     <!--<button class="btn btn-view btn-xs" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><i class="fa fa-eye" aria-hidden="true"></i></button>-->
    <button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModalnew<?=$i?>">View</button>
<!-- Modal -->
<div class="modal fade" id="myModalnew<?=$i?>" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Delivery Details</h4>
        </div>
        <div class="modal-body">
          <p>Delivery Address : <?=$fetchz->delivery_address?></p>
          <p>Delivery Date : <?php echo date("j M y", strtotime($fetchz->delivery_date));?></p>
          <p>Delivery Time : From <?=$fetchz->delivery_start_time?> - To <?=$fetchz->delivery_end_time?></p>
        </div>
        
      </div>
      
    </div>
  </div>
</td>
                          
                                            
                      
                      
                      
                      
                      
                             <td><?=$fetchz->service_status;?></td>
                         
                          <td class="center">
                              <select id="status" onchange="changestatus(this.value, '<?=$fetchz->order_id;?>');">
                                  <option>Select Service Outlets</option>
                                  <?php foreach ($outlets as $out) { ?>
                                  <option id="<?php echo $out->user_id; ?>" value="<?php echo $out->user_id; ?>" > <?php echo $out->user_id; ?>[<?php  echo $out->email; ?>] </option>
                             <?php }?>
                              </select>
                          </td>
                        
                        </tr>
                         <?php $i++;$count++; } ?>
                        
                      </tbody>
                    </table>
                  </div>
                </div>
                <!-- Panel Widget --> 
              </div>
              <!-- col-md-12 --> 
            </div>
            <!-- row --> 
            
          </div>
          <!-- .vd_content-section --> 
          
        </div>
        <!-- .vd_content --> 
      </div>
      <!-- .vd_container --> 
    </div>
    <!-- .vd_content-wrapper --> 
    
    <!-- Middle Content End --> 
    
  </div>
  <!-- .container --> 
</div>
<!-- .content -->
<script>
    function deleteone(id)
    {
        alert(id);
        cnf = confirm("Are you confirm to delete?");
        if(cnf)
		{
                  
                    $('.portlet .tools a.reload').click();
                    $.ajax({
                        type:"GET",
                        url:"<?php echo base_url();?>Webadmin/Contacteduser/delorder",
                        data:"id="+id,
                        success:function(data)
                        {
                                                      
                           if(data == "deleted")
                            {
                                $('#banner'+id).css('display', 'none');
                            }
                        }
                    });
			/*$.post('<?php echo base_url();?>Webadmin/Cms/delete_cms/'+id,
				function(data)
				{//deletecinematic
                                    alert(data);
                                    if(data != "deleted")
                                    {
                                        alert(data);
                                        //$('$cms'+id).css('display', 'none');
                                    }
                                    //$('#data-tables').html(data);
					
				}
			);*/
		}
    }
    
    function changestatus(id,val)
    {
     
        //alert(id);
        //   alert(order_id);
        $.ajax({
            type:"GET",
            url:"<?php echo base_url();?>Webadmin/Contacteduser/assignorder",
          data:"id="+id+"&val="+val,
            success:function(data)
            {
               alert(data);
               window.location.reload();
            }
        });
			
    }
</script>