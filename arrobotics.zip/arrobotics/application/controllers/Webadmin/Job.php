<?php
defined('BASEPATH') OR exit('No Direct Script access allowed');

class Job extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Webadmin/Job_model');
                $this->load->model('Webadmin/Admin_model');
                $this->load->helper("file");

                
	}
	
	public function index()
        {
            if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
            $page = 'job';
            $data['page'] = $page;
            
            $cms = $this->Job_model->fetch_all();
            $data['cms'] = $cms;
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/job');
            $this->load->view('Webadmin/footer');
        }
	
        public function add_job()
        {
            if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
             $page = 'job';
            $data['page'] = $page;
            
            $image = "";
            if($this->input->post('submit') == 'Submit')
            {
                //$job_id=$this->input->post('job_id');
                $job_role=$this->input->post('job_role');
                 $location=$this->input->post('location');
                  $job_type=$this->input->post('job_type');
                  $employer_name=$this->input->post('employer_name');
                 
                $wage = $this->input->post('wage');
                $desc = $this->input->post('desc');
                $start_date=$this->input->post('start_date');
                $expiry_date=$this->input->post('expiry_date');
            
              
                
          /*      $config['upload_path']   = './CMS/'; 
                $config['allowed_types'] = 'gif|jpg|png'; 
                $config['max_size']      = 2048; 
                $config['max_width']     = 3000; 
                $config['max_height']    = 2000;  
                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('file')) {
                   $error = array('error' => $this->upload->display_errors()); 

                }

                else { 
                   $file_data = $this->upload->data(); 
                   $image = $file_data['file_name'];
                     


                } */
                
                
                $date=date('y-m-d');
                $field_data = array(
                        'job_role' => $job_role,
                        'location' => $location,
                      'job_type' =>$job_type,
                      'wage' =>$wage,
                    'job_description' =>$desc,
                    'employer_name'=>$employer_name,
                    'date' =>$date,
                    'start_date'=>$start_date,
                    'expiry_date'=>$expiry_date,
                        'status' => 'Active'
                        );
                
                $result = $this->Job_model->add_cms($field_data);
                
              //  echo $this->db->last_query();
                
                if($result){
                    $succ = "Data Added Successfully";
                    $data['succ']=$succ;
                }
           }
            //$cms = $this->Job_model->fetch_all();
            //$data['cms'] = $cms;
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/job_details');
            $this->load->view('Webadmin/footer');
        }
        
        public function edit_job()
        {   if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
             $page = 'job';
            $data['page'] = $page;
            
             // $data['statelist']=  $this->Admin_model->fetch_all('state');
            
            if($this->input->post('submit') == 'Submit')
            {
                
                $id = $this->input->post('id');
              $job_role=$this->input->post('job_role');
                 $location=$this->input->post('location');
                  $job_type=$this->input->post('job_type');
                  $employer_name=$this->input->post('employer_name');
                 
                $wage = $this->input->post('wage');
                $desc = $this->input->post('desc');
                $start_date=$this->input->post('start_date');
                $expiry_date=$this->input->post('expiry_date');
                
               
               
               $field_data = array(
                        'job_role' => $job_role,
                        'location' => $location,
                      'job_type' =>$job_type,
                      'wage' =>$wage,
                    'job_description' =>$desc,
                    'employer_name'=>$employer_name,
                   'start_date'=>$start_date,
                    'expiry_date'=>$expiry_date,
                       
                        );
                
                
                $result = $this->Job_model->eidt_cms($field_data,$id);
                
                
                if($result){
                    $succ = "Data Updated Successfully";
                    $data['succ']=$succ;
                    $cms = $this->Job_model->fetch_single($id);
                    $data['cms'] = $cms;
                    //var_dump($data);exit();
                }
           }else{
            
                $id = $this->uri->segment(4);
                $cms = $this->Job_model->fetch_single($id);
                $data['cms'] = $cms;
            
           }
            
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/job_details',$data);
            $this->load->view('Webadmin/footer');
        }
	//Start About-------------------------------------------------------------------------------------------
	function view_job()
	{
            if(!$this->session->userdata('is_logged_in'))
            {
                redirect('Webadmin/Login');
            }
            $page = 'job';
            $data['page'] = $page;
            
            $id = $this->uri->segment(4);
            $cms = $this->Job_model->fetch_single($id);
            $data['cms'] = $cms;
            
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/job_details',$data);
            $this->load->view('Webadmin/footer');
	}
        
        public function delete_job()
	{
            
           $id = $this->input->get('id', TRUE);
            $fetch = $this->Job_model->fetch_single($id);
            if($fetch->cmsimg != "")
                unlink('./CMS/'.$fetch->cmsimg);
            $cms = $this->Job_model->delete_single($id);
            
            if($cms){
                echo 'deleted';
            }
            
	}
}
?>