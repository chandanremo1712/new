  
    <!-- Middle Content Start -->
    
    <div class="vd_content-wrapper">
      <div class="vd_container">
        <div class="vd_content clearfix">
          <div class="vd_head-section clearfix">
            <div class="vd_panel-header">
              <ul class="breadcrumb">
                <li><a href="<?php echo base_url().'Webadmin/Dashboard/';?>">Home</a> </li>
                <li class="active">Student List</li>
              </ul>
              <div class="vd_panel-menu hidden-sm hidden-xs" data-intro="<strong>Expand Control</strong><br/>To expand content page horizontally, vertically, or Both. If you just need one button just simply remove the other button code." data-step=5  data-position="left">
    <div data-action="remove-navbar" data-original-title="Remove Navigation Bar Toggle" data-toggle="tooltip" data-placement="bottom" class="remove-navbar-button menu"> <i class="fa fa-arrows-h"></i> </div>
      <div data-action="remove-header" data-original-title="Remove Top Menu Toggle" data-toggle="tooltip" data-placement="bottom" class="remove-header-button menu"> <i class="fa fa-arrows-v"></i> </div>
      <div data-action="fullscreen" data-original-title="Remove Navigation Bar and Top Menu Toggle" data-toggle="tooltip" data-placement="bottom" class="fullscreen-button menu"> <i class="glyphicon glyphicon-fullscreen"></i> </div>
      
</div>
 
            </div>
          </div>
          <div class="vd_title-section clearfix">
            <div class="vd_panel-header">
              <!--<h1>Student List <a href="<?php echo base_url();?>Webadmin/Student/add_details"><button id="add-alement" class="btn vd_btn vd_bg-green" type="button">Add New +</button></a></h1>-->
              
              
            </div>
          </div>
          <div class="vd_content-section clearfix">
            <div class="row">
              <div class="col-md-12">
                <div class="panel widget portlet">
                  <div class="panel-heading vd_bg-grey">
                    <h3 class="panel-title"> <span class="menu-icon"> <i class="fa fa-dot-circle-o"></i> </span> Student List 
                        
                    </h3>
                  </div>
                    <?php if($this->uri->segment(4)=='usucc'){?>
                  <div class="alert alert-success alert-dismissable">
                        <button aria-hidden="true" data-dismiss="alert" class="close" type="button"><i class="icon-cross"></i></button>
                        <i class="fa fa-check-circle append-icon"></i><strong>Success!</strong> <?php echo "Data updeted successfully.";?> 
                  </div>
               <?php }?>  
                   <div class="tools">
                        <a href="javascript:;" class="collapse"></a>
                        <a href="#portlet-config" data-toggle="modal" class="config"></a>
                        <a href="javascript:;" class="reload"></a>
                        <a href="javascript:;" class="remove"></a>
                </div>
                  <div class="panel-body table-responsive">
                    <table class="table table-striped" id="data-tables">
                      <thead>
                        <tr>
                          <th>Nos.</th>
                          <th>Student Id</th>
                          <th>Name</th>
                          <th>Email</th>
                          <th>Contact</th>
                          <th>Registered On</th>
                          <th>Session From</th>
                           <th>Session To</th>
                       
                          <!--<th>Status</th>-->
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                         <?php 
                         $count = 1;
                         
         
                       //  print_r($fetch1);
                         
                         foreach($fetch1 as $fetchz)
                         {  
               $fetch = $this->Admin_model->fetch_single_join("select * from student where student_id='$fetchz->student_id'"); 
             //  print_r($fetch);
               
                             
                             
                        ?>
                          <tr class="odd gradeX" id="blog<?php echo $fetch->id;?>">
                          <td width="5%"><?=$count;?></td>
                          <td><?=$fetch->student_id;?></td>
                          <td><?=$fetch->firstname.' '.$fetch->lastname;?></td>
                           <td><?=$fetch->email;?></td>
                          <td><?=$fetch->phone;?></td>
                          <td><?=date('jS M Y',strtotime($fetch->registration_date));?></td>
                   <?php
                   $data['Admin_model']=$this->Admin_model;
                    $event_id=$this->uri->segment(4);
                    $fetch_session_id=$this->Admin_model->fetch_row('applied_session',"event_id=$event_id");
                    
                    
                    $session_id=$fetch_session_id->session_id;
                    
//                    echo $this->db->last_query();
//                        exit();
                   $session_time=$this->Admin_model->fetch_single('event_session',"$session_id");
//                   echo $this->db->last_query();
//                  exit();
                   
                   ?>
                          
                           <th><?=$session_time->from_time;?></th>
                           <th><?=$session_time->to_time;?></th>
                        
                          
<!--                          <td class="center">
                              <select id="status" onchange="changestatus(this.value, <?=$fetch->id;?>);">
                                  
                                  <option value="Active" <?php if($fetch->status=="Active"){echo 'selected';}?>>Active</option>
                                  <option value="Inactive" <?php if($fetch->status=="Inactive"){echo 'selected';}?>>Inactive</option>
                              </select>
                          </td>-->
                          <td class="menu-action" style="width:12%;">
                              <a href="<?php echo base_url();?>Webadmin/Student/view_details/<?php echo $fetch->id;?>" data-original-title="view" data-toggle="tooltip" data-placement="top" class="btn menu-icon vd_bd-green vd_green" title="View Details"> <i class="fa fa-eye"></i> </a> 
                              <!--<a href="<?php echo base_url();?>Webadmin/Student/edit_details/<?php echo $fetch->id;?>" data-original-title="edit" data-toggle="tooltip" data-placement="top" class="btn menu-icon vd_bd-yellow vd_yellow" title="Edit Details"> <i class="fa fa-pencil"></i> </a>--> 
                              <!--<a onclick="deleteone(<?php echo $fetch->id;?>);" data-original-title="delete" data-toggle="tooltip" data-placement="top" class="btn menu-icon vd_bd-red vd_red" title="Delete Details"> <i class="fa fa-times"></i> </a>-->
                          </td>
                        </tr>
                         <?php $count++;}?>
                        
                      </tbody>
                    </table>
                  </div>
                </div>
                <!-- Panel Widget --> 
              </div>
              <!-- col-md-12 --> 
            </div>
            <!-- row --> 
            
          </div>
          <!-- .vd_content-section --> 
          
        </div>
        <!-- .vd_content --> 
      </div>
      <!-- .vd_container --> 
    </div>
    <!-- .vd_content-wrapper --> 
    
    <!-- Middle Content End --> 
    
  </div>
  <!-- .container --> 
</div>
<!-- .content -->
<script>
    function deleteone(id)
    {
        cnf = confirm("Are you confirm to delete?");
        if(cnf)
		{
                  
                    $('.portlet .tools a.reload').click();
                    $.ajax({
                        type:"GET",
                        url:"<?php echo base_url();?>Webadmin/Student/DeleteEmp",
                        data:"id="+id,
                        success:function(data)
                        {
                                                      
                           if(data == "deleted")
                            {
                                $('#blog'+id).css('display', 'none');
                            }
                        }
                    });
			/*$.post('<?php echo base_url();?>Webadmin/Cms/delete_cms/'+id,
				function(data)
				{//deletecinematic
                                    alert(data);
                                    if(data != "deleted")
                                    {
                                        alert(data);
                                        //$('$cms'+id).css('display', 'none');
                                    }
                                    //$('#data-tables').html(data);
					
				}
			);*/
		}
    }
    
    function changestatus(val,id)
    {
        $.ajax({
            type:"GET",
            url:"<?php echo base_url();?>Webadmin/Super/change_status/student",
            data:"id="+id+"&val="+val,
            success:function(data)
            {
               
            }
        });
			
    }
</script>