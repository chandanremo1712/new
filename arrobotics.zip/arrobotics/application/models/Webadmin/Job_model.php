<?php
class Job_model extends CI_Model {
	
      function __construct() { 
         parent::__construct(); 
		 
      }
      
    public function fetch_all()
    {
        $this->db->select('*');
        //$this->db->where('status', 'Yes');
        $query=$this->db->get('jobs');
        return $query->result();
        
    } 
    
    public function fetch_single($id)
    {
        $this->db->select('*');
        $this->db->where('id', $id);
        $query=$this->db->get('jobs');
        return $query->row();
        
    } 
    
    public function add_cms($data)
    {
        $query=$this->db->insert('jobs',$data);
        return $query;
        
    }
    
    public function eidt_cms($data, $id)
    {
        $this->db->where('id', $id);
        $this->db->update('jobs',$data);
        return true;
        
    }
    
    public function delete_single($id)
    {
         $this->db->where('id', $id);
         $delete = $this->db->delete('jobs'); 
         return $delete;
        
    }
	  
	  
}
?>