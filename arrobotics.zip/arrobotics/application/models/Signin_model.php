<?php
class Signin_model extends CI_Model
{
	function __construct()
	{
		parent::__construct();
		
	}
	
	function user_login($data)
	{
		$this->db->where('email',$data['email']);
                $this->db->or_where('username',$data['email']);
		$this->db->where('password',$data['password']);
		//$this->db->where('UserStatus','Yes');
		$query=$this->db->get('student');
		$result= $query->num_rows();
			if($result==1)
			{
				//$data1=array('login'=>1);
				//$this->db->where('email',$data['email']);
				//$this->db->update('student',$data1);
				return TRUE;
			}
			else
			{
				return FALSE;
			}
	}
        
        	function tutor_login($data)
	{
		$this->db->where('email',$data['email']);
                $this->db->or_where('username',$data['email']);
		$this->db->where('password',$data['password']);
		//$this->db->where('UserStatus','Yes');
		$query=$this->db->get('tutor');
		$result= $query->num_rows();
			if($result==1)
			{
				//$data1=array('login'=>1);
				//$this->db->where('email',$data['email']);
				//$this->db->update('student',$data1);
				return TRUE;
			}
			else
			{
				return FALSE;
			}
	}
	
	
	function check_user_forgot($email,$data)
	{
		
		$this->db->where('EmailId',$email);
		$query=$this->db->get('tsr_user_registration');
		$result=$query->num_rows();
		if($result==1)
		{
			$this->db->where('EmailId',$email);
			$query1=$this->db->update('tsr_user_registration',$data);
			return TRUE;
		}
		else
		{
			return FALSE;
		}
	}
	
	function revocer_password($data,$set_pass)
	{
		$this->db->where('EmailId',$data['email']);
		$this->db->where('ConfirmCode',$data['verification_code']);
		$query=$this->db->get('tsr_user_registration');
		$check=$query->num_rows();
		if($check==1)
		{
			$this->db->where('EmailId',$data['email']);
			$query1=$this->db->update('tsr_user_registration',$set_pass);
			return $query1;
		}
		else
		{
			return FALSE;
		}
		
	}
	
	
}

?>