<style>
.custom-search-form{
    margin-top:5px;
}
</style>



<!-- Start main-content -->
<div class="main-content">

<!-- Section: inner-header -->


<section class="inner-header divider parallax layer-overlay overlay-dark-5" data-bg-img="<?=base_url()?>images/bg/bg3.jpg">
<div class="container pt-70 pb-20">
<div class="section-content">
<div class="row">
<div class="col-md-12">
<h2 class="title text-white text-center">Products</h2>
<ol class="breadcrumb text-left text-black mt-10">
<li><a href="#">Home</a></li>
<li class="active text-gray-silver">Products</li>
</ol>
</div>
</div>
</div>
</div>
</section>

<section class="">
<div class="container">
<div class="section-content">
<div class="row">
<div class="col-sm-12 col-md-3">
<div class="sidebar sidebar-right mt-sm-30">
    


<div class="widget">
<h5 class="widget-title line-bottom">Categories</h5>
<div class="categories">
<ul class="list list-border angle-double-right">
  <?php
$cat=$this->Admin_model->fetch_all_join('select * from category where Status="Active" order by category');

foreach($cat as $catz){  
$product_count=$this->Admin_model->total_count("nsn_product","category='$catz->id' and Status='Yes'");
?>  
    
<li><a href="<?=base_url()?>productcategory/<?=$catz->id?>"><?=$catz->category?><span>(<?=$product_count?>)</span></a></li>

<?php } ?>


</ul>
</div>
</div>



<div class="widget">
<h5 class="widget-title line-bottom">For Sale</h5>
<div class="top-sellers">
   <?php
 $for_sale=$this->Admin_model->fetch_all_join("select * from nsn_product where Status='Yes' order by Id desc limit 3");
 foreach($for_sale as $for_salez){
     
      if($for_salez->image != "")
                                 $pic = base_url().'Banner/'.$for_salez->image;
                             else
                                 $pic =  base_url()."Banner/noimg.png";
     
 ?>  
    
<article class="post media-post clearfix pb-0 mb-10">
<a class="post-thumb" href="<?=base_url()?>productdetails/<?= base64_encode($for_salez->Id)?>"><img src="<?=$pic?>" alt="" style="height:80px;width:80px;"></a>
<div class="post-right">
<h5 class="post-title font-weight-600 mt-0 mb-0"><a href="<?=base_url()?>productdetails/<?= base64_encode($for_salez->Id)?>"><?=$for_salez->title?></a></h5>
<div class="product-detail">
<div class="price mb-10"><ins><span class="amount">$<?=$for_salez->price?></span></ins></div>

</div>
</div>
</article>
    
 <?php } ?>
    
    


</div>
</div>

</div>
</div>   
    
    <span style="color:green;font-size:20px;" id="msg"> <i><?php echo $this->session->flashdata('success_msg'); ?></i></span>
    
   <?php include 'search.php';  ?>
    
<div class="col-sm-12 col-md-9">
    


                    
    
<div class="row multi-row-clearfix">
<div class="products">
    
 <?php
// $product=$this->Admin_model->fetch_all_join("select * from nsn_product where Status='Yes' order by Id desc limit 12");
 
 foreach($deptlist as $productz){
     
      if($productz->image != "")
                                 $pic = base_url().'Banner/'.$productz->image;
                             else
                                 $pic =  base_url()."Banner/noimg.png";
     
 ?>
    
    
<div class="col-sm-6 col-md-4 col-lg-4 mb-30">
<div class="product">
    
 <?php
 if($productz->deals=='Yes'){
 ?>
    
<span class="tag-sale">Sale!</span>
 <?php } else { ?>

 <?php } ?>



<div class="product-thumb"> 
<img alt="" src="<?=$pic?>" class="img-responsive img-fullwidth" style="height:200px;">
<div class="overlay">
<div class="btn-add-to-cart-wrapper">
    
<?php
if(!$this->session->userdata('email')){
?>  
<a href="<?=base_url()?>login" class="btn btn-theme-colored btn-sm btn-flat pl-20 pr-20 btn-add-to-cart text-uppercase font-weight-700" href="#">Add To Cart</a>

<?php } else { ?>

<a onclick="getproductid(<?php echo $productz->Id;?>);" class="btn btn-theme-colored btn-sm btn-flat pl-20 pr-20 btn-add-to-cart text-uppercase font-weight-700" href="#">Add To Cart</a>

<?php } ?>


</div>
<div class="btn-product-view-details">
<a class="btn btn-default btn-theme-colored btn-sm btn-flat pl-20 pr-20 btn-add-to-cart text-uppercase font-weight-700" href="<?=base_url()?>productdetails/<?= base64_encode($productz->Id)?>">View detail</a>
</div>
</div>
</div>
<div class="product-details text-center">
    <a href="<?=base_url()?>productdetails/<?= base64_encode($productz->Id)?>"><h5 class="product-title"><?=$productz->title?></h5></a>

<div class="price">
   
    <ins><span class="amount">$<?=$productz->price?></span></ins></div>
</div>
</div>
</div>
    
  <?php } ?>  

</div>
</div>
</div>

</div>
<div class="row">
<div class="col-md-12">
<nav>

<?php echo $pagination;?>
    
    
</nav>
</div>
</div>
</div>
</div>
</section>
</div>
<!-- end main-content -->
