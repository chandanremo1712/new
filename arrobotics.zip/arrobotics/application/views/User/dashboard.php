<!--Banner-->
<!--<section>
<div class="csi-banner csi-banner-inner">
<div class="csi-inner">
<div class="container">
<div class="row">
<div class="col-xs-12">
<div class="csi-heading-area">
<h2 class="csi-heading">
Profile
</h2>
<ul class="breadcrumb">
<li><a href="<?=base_url()?>"><i class="icon-home6"></i>Home</a></li>
<li class="active">Profile</li>
</ul>
</div>
</div>
</div>
</div>

</div>
</div>
</section>-->
<!--Banner END-->
<div class="main-content bg-lighter">
<section class="inner-header divider parallax layer-overlay overlay-dark-5" data-bg-img="<?=base_url()?>images/bg/bg6.jpg">
<div class="container pt-70 pb-20">
<!-- Section Content -->
<div class="section-content">
<div class="row">
<div class="col-md-12">
<h2 class="title text-white text-center">My Account</h2>
<ol class="breadcrumb text-left text-black mt-10">
<li><a href="#">Home</a></li>
<!--<li><a href="#">Pages</a></li>-->
<li class="active text-gray-silver">Profile</li>
</ol>
</div>
</div>
</div>
</div>
</section>


<div class="container">
<div class="row profile">
<?php include 'side-bar.php';  ?>
<div class="col-md-8 order-content" style="margin-left: 35px;">

<div class="form_main col-md-4 col-sm-5 col-xs-7">
<h4 class="heading"><strong>User </strong> Profile <span></span></h4>
<span style="color:green;font-size:18px;" id="msg"> <i><?php echo $this->session->flashdata('success_msg'); ?></i></span>
<div class="form">
<form  method="post" action="<?=base_url()?>User/Edit">

<div class="row">
    
   <div class="col-md-6">
       <label>Name</label><br>
<input type="text" required="" placeholder="Name" value="<?=$details->name?>" name="name" class="txt">
</div> 
    
<div class="col-md-6">
<label>Email</label><br>
<input type="text" required="" placeholder="Email" value="<?=$details->email?>" name="email" class="txt" readonly="">
</div>



</div>
<div class="row">
<div class="col-md-6">
<label>Phone</label><br>
<input type="text" required="" placeholder="Phone" value="<?=$details->phone?>" name="phone" class="txt" minlength="10">
</div>

<div class="col-md-6">
<label>Address</label><br>
<input type="text" required="" placeholder="Street Address" value="<?=$details->address?>" name="address" class="txt">
</div>
</div>



<br>


<!--                    <button type="button" name="submit" value="submit" class="btn btn-default">Update</button>-->
<input type="submit" name="submit" class="btn btn-default" value="submit">
</form>
</div>
</div>

</div>


</div>
</div>
</div>