<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Career extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->database();


        $this->load->library('form_validation');
        $this->load->model('Webadmin/Admin_model');
        $this->load->helper("file");

        $this->load->library('image_lib');
        $this->load->helper("url");

         if (!$this->session->userdata('is_logged_in')) {
            redirect('Webadmin/Login');
        }

    }

    function index() {
        $page = 'career';
        $data['page'] = $page;
       
        
        $fetch = $this->Admin_model->fetch_all_join('select * from career order by id desc');
        $data['fetch'] = $fetch;
        $this->load->view('Webadmin/header');
        $this->load->view('Webadmin/leftbar',$data);
        $this->load->view('Webadmin/career', $data);
        $this->load->view('Webadmin/footer');
    }
    
     public function view_details()
    {
        if(!$this->session->userdata('is_logged_in'))
            {
            redirect('Webadmin/Login');
            }
            $page = 'career';
            $data['page'] = $page;

            $page_type = 'contacteduser';
            $data['page_type'] = $page_type;

            $id = $this->uri->segment(4);
            $fetch = $this->Admin_model->fetch_single('career', $id);
            
            /**********update view statu***********/
            $set=array(
                'view'=>'Yes'
            );
            
            $update=$this->Admin_model->edit_details('career',$set,$id);
            
            /***********************/
            
            
            $data['fetch'] = $fetch;
            $data['Admin_model']=  $this->Admin_model;
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/career_details',$data);
            $this->load->view('Webadmin/footer');
    }


    function edit_details()
    {
        
         if(!$this->session->userdata('is_logged_in'))
            {
            redirect('Webadmin/Login');
            }
            $page = 'student';
            $data['page'] = $page;

            $page_type = 'user';
            $data['page_type'] = $page_type;
            
            
            
            if ($this->input->post('submit') == "Submit") {

            $this->form_validation->set_rules('firstname', 'firstname', 'required|trim');  //name , message 
            $this->form_validation->set_rules('lastname', 'lastname', 'required|trim');

            $this->form_validation->set_rules('mobile', 'phone', 'required|trim');

            //$this->form_validation->set_rules('address', 'address', 'required');
            $this->form_validation->set_rules('state', 'state', 'required');
            $this->form_validation->set_rules('city', 'city', 'required');
            $this->form_validation->set_rules('zip', 'zipcode', 'required');
            $this->form_validation->set_rules('country', 'country', 'required');

if($this->form_validation->run() == FALSE)
{
   
}

if($this->form_validation->run() == TRUE)
{


            $id = $this->input->post('id');
            $firstname = $this->input->post('firstname');
            $lastname = $this->input->post('lastname');
            $mobile = $this->input->post('mobile');
            $skype_id = $this->input->post('skype_id');
            $address = $this->input->post('address');
            $city = $this->input->post('city');
            $state = $this->input->post('state');
            $country = $this->input->post('country');

            $config['upload_path'] = 'profile/';
            $config['allowed_types'] = 'gif|jpg|png';
            $config['max_size'] = 2048;
            $config['max_width'] = 3000;
            $config['max_height'] = 2000;
            $config['file_name'] = uniqid();
            $this->load->library('upload', $config);
            //$upload_data = $this->upload->data(); //Returns array of containing all of the data related to the file you uploaded.


            if (!$this->upload->do_upload('file')) {
                $error = array('error' => $this->upload->display_errors());
                $image = $this->input->post('old_img');
            } else {
                $file_data = $this->upload->data();
                $image = $file_data['file_name'];

                if ($this->input->post('old_img') != "")
                    unlink('profile/' . $this->input->post('old_img'));
            }

            $field_data = array(
                'firstname' => $firstname,
                'lastname' => $lastname,
                'phone' => $mobile,
                'profile_image' => $image,
                'address'=>$address,
                'city'=>$city,
                'state'=>$state,
                'country'=>$country,
                'zip'=>  $this->input->post('zip'),
                'password' => base64_encode($this->input->post('password'))
            );

            $result = $this->Admin_model->eidt_details('student', $field_data, $id);
           
          //  echo $this->db->last_query();exit();
            if ($result) {
                $succ = "Data Updated Successfully";
                $data['succ'] = $succ;
                $fetch = $this->Admin_model->fetch_single('tutor', $id);
                $data['fetch'] = $fetch;
                redirect(base_url() . 'Webadmin/Student/index/usucc');
            }
            
}
else{ 
     $id = $this->uri->segment(4);
          $fetch = $this->Admin_model->fetch_single('student', $id);
            $data['fetch'] = $fetch;
}
            
            
            
        } 
            else{
                 $id = $this->uri->segment(4); 
            
            
            $fetch = $this->Admin_model->fetch_single('student', $id);
            $data['fetch'] = $fetch;
            }
            $data['Admin_model'] = $this->Admin_model;
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/student_details',$data);
            $this->load->view('Webadmin/footer');
        
        
    }
     
      function Delete() {
        $id = $this->input->get('id', TRUE);       
        $fetch = $this->Admin_model->fetch_single('career', $id);        
         unlink('./CV/'.$fetch->cv);
        
        $banner = $this->Admin_model->delete_single('career', $id);
        if ($banner) {

            echo 'deleted';
        }
    }
        
        function download($filename = NULL) {
            // load download helder
            $this->load->helper('download');
            // read file contents
            $data = file_get_contents(base_url('/cv/' . $filename));
            force_download($filename, $data);
        }
     public function subscriber() {
        $page ='subscribeuser';
        $data['page'] = $page;
        $page_type = 'subscribeuser';
        $data['page_type'] = $page_type;
        $fetch= $this->Admin_model->fetch_all('subscribed');
        $data['fetch'] = $fetch;
        $this->load->view('Webadmin/header');
        $this->load->view('Webadmin/leftbar',$data);
        $this->load->view('Webadmin/subscribeuser', $data);
        $this->load->view('Webadmin/footer');
    }
   public function subscriberdel() {

        $id = $this->input->get('id', TRUE);
        // $fetch = $this->Admin_model->fetch_single('sos_employer_register',$id);
        //print_r( $fetch);exit();

        $banner = $this->Admin_model->delete_single('subscribed', $id);
        if ($banner) {

            echo 'deleted';
        }
    }
     public function quickmessage() {
        $page ='quickmessage';
        $data['page'] = $page;
        $page_type = 'quickmessage';
        $data['page_type'] = $page_type;
        $fetch= $this->Admin_model->fetch_all('quickmessage');
        $data['fetch'] = $fetch;
        $this->load->view('Webadmin/header');
        $this->load->view('Webadmin/leftbar',$data);
        $this->load->view('Webadmin/quickmessage', $data);
        $this->load->view('Webadmin/footer');
    }   
    public function quickmessagedel() {

        $id = $this->input->get('id', TRUE);
        // $fetch = $this->Admin_model->fetch_single('sos_employer_register',$id);
        //print_r( $fetch);exit();

        $banner = $this->Admin_model->delete_single('quickmessage', $id);
        if ($banner) {

            echo 'deleted';
        }
    }
    public function servicelist()
    {
        $page ='servicearea';
        $data['page'] = $page;
        $page_type = 'servicearea';
        $data['page_type'] = $page_type;
        $fetch= $this->Admin_model->fetch_all('servicelist');
        $data['fetch'] = $fetch;
        $this->load->view('Webadmin/header');
        $this->load->view('Webadmin/leftbar',$data);
        $this->load->view('Webadmin/servicearealist', $data);
        $this->load->view('Webadmin/footer');
    }
      function add_postcode() {
            $page='servicearea';
            $data['page']=$page;
            $status="Active";
            if($this->input->post('submit')=='submit'){
        
                 $subdata = array(
                    'postcode'=>$this->input->post('postcode'),
                     //'road_name'=>$this->input->post('road_name'),
                    'description'=> $this->input->post('description'),
                     'status'=>$status
                   
                );
         $result=$this->Admin_model->add_details('servicelist',$subdata);
        if($result)
        {
        $this->session->set_flashdata('succ_mess', 'Succeessful  Added.');
        $fetch= $this->Admin_model->fetch_all('servicelist');
        $data['fetch'] = $fetch;
        $this->load->view('Webadmin/header');
        $this->load->view('Webadmin/leftbar',$data);
        $this->load->view('Webadmin/servicearealist', $data);
        $this->load->view('Webadmin/footer');
        }else{
        $this->session->set_flashdata('err_mess', 'Something Wrong...');
             $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/addservicepostcode');
            $this->load->view('Webadmin/footer');
        }
            
         
      }
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/addservicepostcode');
            $this->load->view('Webadmin/footer');   
      
}

public function edit_postcode(){
    $page='servicearea';
    $data['page']=$page;
    $id=$this->uri->segment(4);
    $fetch=$this->Admin_model->fetch_single('servicelist', $id);
    $data['fetch'] = $fetch;
    $updid=$this->input->post('id');
    if($this->input->post('update')=='update')
    {
        
    $data= array(
                'postcode'=>$this->input->post('postcode'),
                //'road_name'=>$this->input->post('road_name'),
                'description'=> $this->input->post('description')
                
    );
     $result = $this->Admin_model->edit_details('servicelist',$data,$updid);
      if($result)
            {
                $fetch= $this->Admin_model->fetch_all('servicelist');
                $data['fetch'] = $fetch;
                redirect('Webadmin/Contacteduser/servicelist');
             }
        
        
    }else{
    $this->load->view('Webadmin/header');
    $this->load->view('Webadmin/leftbar',$data);
    $this->load->view('Webadmin/addservicepostcode');
    $this->load->view('Webadmin/footer'); 
    }
    
    
    
}
public function deltepostocde() {

        $id = $this->input->get('id', TRUE);
        // $fetch = $this->Admin_model->fetch_single('sos_employer_register',$id);
        //print_r( $fetch);exit();

        $banner = $this->Admin_model->delete_single('servicelist', $id);
        if ($banner) {

            echo 'deleted';
        }
    }
     public function change_status1()
        {
            $tbl ="servicelist";
            
            $id = $this->input->get('id', TRUE);
            $val = $this->input->get('val');
            $field_data = array(
                       'status' => $val
                       );
            $result = $this->Admin_model->eidt_details1($tbl,$field_data,$id);
            if($result)
            {
                echo 'Status Changed';
            }
        }
        
   public function orderlist() {
        $page ='orderlist';
        $data['page'] = $page;
        $page_type = 'orderlist';
        $data['page_type'] = $page_type;
        $fetch= $this->Admin_model->fetch_all_join('select * from order_details group by order_id desc');
        $data['fetch'] = $fetch;
        $this->load->view('Webadmin/header');
        $this->load->view('Webadmin/leftbar',$data);
        $this->load->view('Webadmin/orderlist', $data);
        $this->load->view('Webadmin/footer');
    }
    public function delorder() {

        $id = $this->input->get('id', TRUE);
        // $fetch = $this->Admin_model->fetch_single('sos_employer_register',$id);
        //print_r( $fetch);exit();

        $banner = $this->Admin_model->delete_single('order_details', $id);
        if ($banner) {

            echo 'deleted';
        }
    }
    public function notassignlist() {
        $page ='orderlist';
        $data['page'] = $page;
        $page_type = 'orderlist';
        $data['page_type'] = $page_type;
        
        $data['outlets']=$this->Admin_model->fetch_all('service_outlets');
        
        $where="service_status='Not Assigned' group by order_id";
        
        $fetch=$this->Admin_model->fetch_rows('order_details', $where);
        
        $data['fetch']= $fetch;
        $this->load->view('Webadmin/header');
        $this->load->view('Webadmin/leftbar',$data);
        $this->load->view('Webadmin/notassignorderlist', $data);
        $this->load->view('Webadmin/footer');
    }
    
    
    
    
     public function assignorder()
        {
            $tbl ="order_details";
            
            $id = $this->input->get('id', TRUE);
            $order_id= $this->input->get('val', TRUE);
           
            $field_data = array(
                        'service_outlet'=>$id,
                       'service_status' =>"Assigned"
                       );
            $result=$this->Admin_model->eidt_single_row($tbl,$field_data,"order_id='$order_id'");
            //echo $this->db->last_query(); exit();
            if($result)
            {
                echo 'Assigned Successful';
            }
        }
        
          public function increment()
        {
            $tbl ="cart";
            
            $id = $this->input->get('id', TRUE);
            $user_id= $this->user_id;
            
            $fetch_cart=$this->Admin_model->fetch_single_join("select * from cart where id='$id'");
            $old_quantity=$fetch_cart->quantity;
            
            $new_quantity=$old_quantity+1;
            
           
            $field_data = array(
                'quantity'=>$new_quantity,
                       );
            
            $result=$this->Admin_model->eidt_single_row($tbl,$field_data,"id='$id'");
            //echo $this->db->last_query(); exit();
            if($result)
            {
                echo 'Updated Successful';
            }
        }
        
         public function decrement()
        {
            $tbl ="cart";
            
            $id = $this->input->get('id', TRUE);
            $user_id= $this->user_id;
            
            $fetch_cart=$this->Admin_model->fetch_single_join("select * from cart where id='$id'");
            $old_quantity=$fetch_cart->quantity;
            
            $new_quantity=$old_quantity-1;
            
           
            $field_data = array(
                'quantity'=>$new_quantity,
                       );
            
            $result=$this->Admin_model->eidt_single_row($tbl,$field_data,"id='$id'");
            //echo $this->db->last_query(); exit();
            if($result)
            {
                echo 'Updated Successful';
            }
        }
        
        
        
        
        
    public function assignlist() {
        $page ='orderlist';
        $data['page'] = $page;
        $page_type = 'orderlist';
        $data['page_type'] = $page_type;
        $where="service_status='Assigned' group by order_id";
        $fetch= $this->Admin_model->fetch_rows('order_details', $where);
        $data['fetch'] = $fetch;
        $this->load->view('Webadmin/header');
        $this->load->view('Webadmin/leftbar',$data);
        $this->load->view('Webadmin/assignorderlist', $data);
        $this->load->view('Webadmin/footer');
    }
     public function updateorder()
        {
            $tbl ="order_details";
            $id = $this->input->get('id', TRUE);
            //$order_id= $this->input->get('val', TRUE);
            $field_data = array(
                        
                       'service_status' =>"Completed"
                       );
            $result=$this->Admin_model->eidt_single_row($tbl,$field_data,"order_id='$id'");
            //echo $this->db->last_query(); exit();
            if($result)
            {
                echo 'Updated Successful';
            }
        }
}
