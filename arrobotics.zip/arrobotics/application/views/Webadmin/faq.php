  
    <!-- Middle Content Start -->
    
    <div class="vd_content-wrapper">
      <div class="vd_container">
        <div class="vd_content clearfix">
          <div class="vd_head-section clearfix">
            <div class="vd_panel-header">
              <ul class="breadcrumb">
                <li><a href="<?php echo base_url().'Webadmin/Dashboard/';?>">Home</a> </li>
                <li class="active">FAQ List</li>
              </ul>
              <div class="vd_panel-menu hidden-sm hidden-xs" data-intro="<strong>Expand Control</strong><br/>To expand content page horizontally, vertically, or Both. If you just need one button just simply remove the other button code." data-step=5  data-position="left">
    <div data-action="remove-navbar" data-original-title="Remove Navigation Bar Toggle" data-toggle="tooltip" data-placement="bottom" class="remove-navbar-button menu"> <i class="fa fa-arrows-h"></i> </div>
      <div data-action="remove-header" data-original-title="Remove Top Menu Toggle" data-toggle="tooltip" data-placement="bottom" class="remove-header-button menu"> <i class="fa fa-arrows-v"></i> </div>
      <div data-action="fullscreen" data-original-title="Remove Navigation Bar and Top Menu Toggle" data-toggle="tooltip" data-placement="bottom" class="fullscreen-button menu"> <i class="glyphicon glyphicon-fullscreen"></i> </div>
      
</div>
 
            </div>
          </div>
          <div class="vd_title-section clearfix">
            <div class="vd_panel-header">
              <h1>FAQ List <a href="<?php echo base_url();?>Webadmin/Faq/add_faq"><button id="add-alement" class="btn vd_btn vd_bg-green" type="button">Add New +</button></a></h1>
              
              
            </div>
          </div>
          <div class="vd_content-section clearfix">
            <div class="row">
              <div class="col-md-12">
                <div class="panel widget portlet">
                  <div class="panel-heading vd_bg-grey">
                    <h3 class="panel-title"> <span class="menu-icon"> <i class="fa fa-dot-circle-o"></i> </span> FAQ List 
                        
                    </h3>
                  </div>
                   <div class="tools">
                        <a href="javascript:;" class="collapse"></a>
                        <a href="#portlet-config" data-toggle="modal" class="config"></a>
                        <a href="javascript:;" class="reload"></a>
                        <a href="javascript:;" class="remove"></a>
                   </div>
                  <div class="panel-body table-responsive">
                    <table class="table table-striped" id="data-tables">
                      <thead>
                        <tr>
                          <th>Nos.</th>
                          <th>FAQ Title</th>
                          <th>Description</th>
                          <th>Created On</th>
                          <!--<th>Status</th>-->
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                         <?php 
                         $count = 1;
                         foreach($fetch as $fetchz)
                         {  
                         ?>
                          <tr class="odd gradeX" id="faq<?php echo $fetchz->id;?>">
                          <td width="5%"><?=$count;?></td>
                          <td><?=$fetchz->FaqTitle;?></td>
                          <td width="30%"><?=substr($fetchz->FaqDesc,0,100);?>..</td>
                          <td><?=date('d F Y', strtotime($fetchz->FaqDate));?></td>
<!--                          <td class="center">
                              <select id="status" onchange="changestatus(this.value, <?=$fetchz->id;?>);">
                                  <option value="<?=$fetchz->Status?>"><?=$fetchz->Status?></option>
                                  <option value="Yes">Yes</option>
                                  <option value="No">No</option>
                              </select>
                          </td>-->
                          <td class="menu-action" style="width:12%;">
                              <a href="<?php echo base_url();?>Webadmin/Faq/view_faq/<?php echo $fetchz->id;?>" data-original-title="view" data-toggle="tooltip" data-placement="top" class="btn menu-icon vd_bd-green vd_green" title="View Details"> <i class="fa fa-eye"></i> </a> 
                              <a href="<?php echo base_url();?>Webadmin/Faq/edit_faq/<?php echo $fetchz->id;?>" data-original-title="edit" data-toggle="tooltip" data-placement="top" class="btn menu-icon vd_bd-yellow vd_yellow" title="Edit Details"> <i class="fa fa-pencil"></i> </a> 
                              <a onclick="deleteone(<?php echo $fetchz->id;?>);" data-original-title="delete" data-toggle="tooltip" data-placement="top" class="btn menu-icon vd_bd-red vd_red" title="Delete Details"> <i class="fa fa-times"></i> </a>
                          </td>
                        </tr>
                         <?php $count++;}?>
                        
                      </tbody>
                    </table>
                  </div>
                </div>
                <!-- Panel Widget --> 
              </div>
              <!-- col-md-12 --> 
            </div>
            <!-- row --> 
            
          </div>
          <!-- .vd_content-section --> 
          
        </div>
        <!-- .vd_content --> 
      </div>
      <!-- .vd_container --> 
    </div>
    <!-- .vd_content-wrapper --> 
    
    <!-- Middle Content End --> 
    
  </div>
  <!-- .container --> 
</div>
<!-- .content -->
<script>
    function deleteone(id)
    {
        cnf = confirm("Are you confirm to delete?");
        if(cnf)
		{
                  
                    $('.portlet .tools a.reload').click();
                    $.ajax({
                        type:"GET",
                        url:"<?php echo base_url();?>Webadmin/Faq/delete_faq/",
                        data:"id="+id,
                        success:function(data)
                        {
                                                      
                           if(data == "deleted")
                            {
                                $('#faq'+id).css('display', 'none');
                            }
                        }
                    });
			/*$.post('<?php echo base_url();?>Webadmin/Cms/delete_cms/'+id,
				function(data)
				{//deletecinematic
                                    alert(data);
                                    if(data != "deleted")
                                    {
                                        alert(data);
                                        //$('$cms'+id).css('display', 'none');
                                    }
                                    //$('#data-tables').html(data);
					
				}
			);*/
		}
    }
    
    function changestatus(val,id)
    {
        $.ajax({
            type:"GET",
            url:"<?php echo base_url();?>Webadmin/Super/change_status/nsn_faq",
            data:"id="+id+"&val="+val,
            success:function(data)
            {
               alert(data);
            }
        });
			
    }
</script>