<?php
defined('BASEPATH') OR exit('No Direct Script access allowed');

class Notification extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Webadmin/Admin_model');
                $this->load->helper("file");
                $this->load->helper('date');
                $this->load->library('email');

                
	}
	
	public function index()
        {
            if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
            $page = 'notify';
            $data['page'] = $page;
            
            $fetch = $this->Admin_model->fetch_all('nsn_email_notification');
            $data['fetch'] = $fetch;
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/notification');
            $this->load->view('Webadmin/footer');
        }
	
        public function send_notification()
        {
            if(!$this->session->userdata('is_logged_in'))
            {
                    redirect('Webadmin/Login');
            }
            $page = 'notify';
            $data['page'] = $page;
            
            
            if($this->input->post('submit') == 'Send Notification')
            {
                $title = $this->input->post('title');
                $description = $this->input->post('desc');
                
                
                $field_data = array(
                        'Subject' => $title,
                        'Notification' => $description,
                        'Date' => date('Y-m-d H:i:s',time())
                        );
                $result = $this->Admin_model->add_details('nsn_email_notification', $field_data);
                
                $fetch = $this->input->post('emails');
                //print_r($fetch);exit();
                $emails = implode(',',$fetch);
              
    /*************************Email Functionality Implement here ***********************************/
                $htmlContent = "<table align='center' style='width:650px; text-align:center; background:#f7f7f7;'>
                                    <tbody>
                                    <tr style='height:50px;background-color:red;'><td valign='middle' style='color:white;'><img src='".base_url()."frontend/images/logo.png' alt='Nxtstepnutrition' title='Nxtstepnutrition' /></td></tr>
                                    <tr>
                                        <td valign='top' align='center' colspan='2'>
                                            <table align='center' style='height:380px; color:#000; width:600px;'>
                                            <tbody>
                                                <tr>
                                                    <td style='width:8px;'>&nbsp;</td> 
                                                    <td align='center' style='font-size:28px;border-top:1px dashed #ccc;' colspan='3'><h2>".$this->input->post('title')."</h2></td>
                                                </tr>
                                                <tr>
                                                    <td valign='top' align='center' colspan='2'>".
                                                    $this->input->post('desc')
                                                    ."<br>
                                                    Sincerely,<br>
                                                    Nest Step Nutrition<br><br>
                                                    <strong>Email:</strong>info@nxtstepnutrition.com/<br><br>

                                                    This is a Notification Email, please DO NOT reply.
                                                    </td>
                                                 </tr>
                                            </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>";

                            $config['mailtype'] = 'html';
                            $this->email->initialize($config);
                            $this->email->to($emails);
                            $this->email->from('nxtstepnutrition.com','Nextstepnutrition');
                            $this->email->subject($title);
                            $this->email->message($htmlContent);

                            $this->email->send();
                
                if($result){
                    $succ = "Notification Send Successfully";
                    $data['succ']=$succ;
                }
                $email = $this->Admin_model->fetch_all('nsn_users');
                $data['email'] = $email;
                $this->load->view('Webadmin/header');
                $this->load->view('Webadmin/leftbar',$data);
                $this->load->view('Webadmin/notification_details');
                $this->load->view('Webadmin/footer');
           }else{
                $email = $this->Admin_model->fetch_all('nsn_users');
                $data['email'] = $email;
                $this->load->view('Webadmin/header');
                $this->load->view('Webadmin/leftbar',$data);
                $this->load->view('Webadmin/notification_details');
                $this->load->view('Webadmin/footer');
           }
        }
        
       
	function view_notification()
	{
            if(!$this->session->userdata('is_logged_in'))
            {
            redirect('Webadmin/Login');
            }
            $page = 'notify';
            $data['page'] = $page;
            
            $id = $this->uri->segment(4);
            $fetch = $this->Admin_model->fetch_single('nsn_email_notification', $id);
            $data['fetch'] = $fetch;
            
            $this->load->view('Webadmin/header');
            $this->load->view('Webadmin/leftbar',$data);
            $this->load->view('Webadmin/notification_details',$data);
            $this->load->view('Webadmin/footer');
	}
        
        public function delete_notification()
	{
            
           $id = $this->input->get('id', TRUE);
            $notify = $this->Admin_model->delete_single('nsn_email_notification', $id);
           if($notify){
               
                echo 'deleted';
           } 
            
	}
//End About---------------------------------------------------------------------------------------------
	

	
}


?>