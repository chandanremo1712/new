<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('Webadmin/Admin_model');
		$this->load->database();
	}
	
	
	
	
	function Services()
	{
		if(!$this->session->userdata('is_logged_in'))
		{
			redirect('Webadmin/Login');
		}
		
		$this->form_validation->set_rules('service_name', 'Service Name', 'trim|required');
		
		if($this->input->post('btn_service')=="add")
		{
		
		 
		 if($this->form_validation->run() == TRUE)
		 {
			
			$data=array('name'=>$this->input->post('service_name'),
			'status'=>$this->input->post('status')
			);
			$result=$this->Admin_model->service($data);
			
			$data['success_msg']="Successfully Added";
			
		 }
		 
			
		}
		
		
		if($this->input->post('btn_service')=="update")
		{
			if($this->form_validation->run() == TRUE)
		    {
			
			$id=$this->input->post('service_id');
			$data=array('name'=>$this->input->post('service_name'),
				'status'=>$this->input->post('status')
			);
			$result=$this->Admin_model->update_service($data,$id);
			}
			
		}
		
		 $query = $this->db->get("service"); 
         $data['fetch_service'] = $query->result(); 
		 
		 $this->load->view('Webadmin/Service',$data);
	}
	
	function DeleteService()
	{	
		$id=$this->uri->segment('4');
		$this->Admin_model->delete_service($id);
		redirect('Webadmin/Users/Services');
	}
	
	function EditService()
	{
		if(!$this->session->userdata('is_logged_in'))
		{
			redirect('Webadmin/Login');
		}
		$id=$this->uri->segment('4');
		$fetch=$this->Admin_model->service_data($id);
		$data['edit_service']=$fetch;
		$this->load->view('Webadmin/Edit-service',$data);
	}
	
	
	
	
	
	
	public function MentorList()
	{
		if(!$this->session->userdata('is_logged_in'))
		{
			redirect('Admin');
		}
		$this->load->model('Admin_model');
		$result=$this->Admin_model->fetch_mentor();
		$data['fetch_user']=$result;
		$this->load->view('Webadmin/List-mentor',$data);
		
		
	}
	
	public function DeleteMentor()
	{
		$this->load->model('Admin_model');
		$id=$this->uri->segment('3');
		
		$this->Admin_model->mentor_delete($id);
		redirect('Webadmin/MentorList','refresh');
	}
	
	public function MentorStatus()
	{
		$this->load->model('Admin_model');
		$id = $this->input->post('id',TRUE); 
		$status = $this->input->post('status',TRUE);
		
		$data=array('status'=>$status);
		$this->Admin_model->mentorstatus_change($id,$data);
	}
	
	
	public function MenteeList()
	{
		if(!$this->session->userdata('is_logged_in'))
		{
			redirect('Admin');
		}
		$this->load->model('Admin_model');
		$result=$this->Admin_model->fetch_mentee();
		$data['fetch_user']=$result;
		$this->load->view('Webadmin/List-mentee',$data);
		
		
	}
	
	public function DeleteMentee()
	{
		$this->load->model('Admin_model');
		$id=$this->uri->segment('3');
		
		$this->Admin_model->mentee_delete($id);
		redirect('Webadmin/UsersList','refresh');
	}
	
	public function MenteeStatus()
	{
		$this->load->model('Admin_model');
		$id = $this->input->post('id',TRUE); 
		$status = $this->input->post('status',TRUE);
		
		$data=array('status'=>$status);
		$this->Admin_model->menteestatus_change($id,$data);
	}
	
	
}
?>