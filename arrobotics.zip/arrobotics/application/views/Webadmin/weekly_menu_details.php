 <div class="vd_content-wrapper">
      <div class="vd_container">
        <div class="vd_content clearfix">
          <div class="vd_head-section clearfix">
            <div class="vd_panel-header">
              <ul class="breadcrumb">
                <li><a href="<?php echo base_url()?>Webadmin/Dashboard">Home</a> </li>
                <li class="active"><?=$title?> Menu</li>
              </ul>
              <div class="vd_panel-menu hidden-sm hidden-xs" data-intro="<strong>Expand Control</strong><br/>To expand content page horizontally, vertically, or Both. If you just need one button just simply remove the other button code." data-step=5  data-position="left">
    <div data-action="remove-navbar" data-original-title="Remove Navigation Bar Toggle" data-toggle="tooltip" data-placement="bottom" class="remove-navbar-button menu"> <i class="fa fa-arrows-h"></i> </div>
      <div data-action="remove-header" data-original-title="Remove Top Menu Toggle" data-toggle="tooltip" data-placement="bottom" class="remove-header-button menu"> <i class="fa fa-arrows-v"></i> </div>
      <div data-action="fullscreen" data-original-title="Remove Navigation Bar and Top Menu Toggle" data-toggle="tooltip" data-placement="bottom" class="fullscreen-button menu"> <i class="glyphicon glyphicon-fullscreen"></i> </div>
      
</div>
            </div>
          </div>
          <div class="vd_title-section clearfix">
            <div class="vd_panel-header">
              <h1><?=$title?> Menu</h1>
              </div>
          </div>
         
          <div class="vd_content-section clearfix">
            <div class="panel widget light-widget">
              <div class="panel-heading no-title"> </div>
              <div class="panel-body">
               <?php if(isset($succ)){?>
                  <div class="alert alert-success alert-dismissable">
                        <button aria-hidden="true" data-dismiss="alert" class="close" type="button"><i class="icon-cross"></i></button>
                        <i class="fa fa-check-circle append-icon"></i><strong>Success!</strong> <?php echo $succ;?> 
                  </div>
               <?php }?>    
                <h2 class="mgbt-xs-20">Weekly Menu Details</h2>
            
                <form class="form-horizontal"  action="<?php echo base_url()?>Webadmin/WeeklyMenu/edit_weekly_<?=strtolower($title);?>_menu" role="form1" method="post" id="register-form1" enctype="multipart/form-data">
                 <?php 
                 $i=1;
                 foreach($menulist as $list){
                     
                     $menus = explode(',',$list->MenuList);
                     
                 
                ?>
                
               <input type="hidden" name="day" value="<?=$list->WeekDay;?>"> 
               <input type="hidden" name="id<?=$i;?>" value="<?=$list->id;?>">
                 <div class="panel widget">
                  <div class="panel-heading vd_bg-red">
                      <h3 class="panel-title" style="color: #FFF;"> <span class="menu-icon"> <i class="icon-pie"></i> </span> <?=$list->WeekDay;?> </h3>
                    <div class="vd_panel-menu">
                        <div data-action="minimize" data-original-title="Minimize" data-toggle="tooltip" data-placement="bottom" class=" menu entypo-icon"> <i class="icon-minus3"></i> </div>
                    </div>

 
                  </div>
                  <div class="panel-body">
                    
                    <?php foreach($fetch as $fetchz)
                        {
                        ?>
                          <label style="width: 23%;"> <input type="checkbox" name="menu<?=$i;?>[]" <?php if(in_array($fetchz->id, $menus)){echo 'checked';} ?> value="<?php echo $fetchz->id;?>"> <?php echo $fetchz->MenuName;?></label>
                    <?php }?>
                  </div>
                </div>
                    
                 <?php $i++;}?>
                   
                  <div id="vd_login-error" class="alert alert-danger hidden"><i class="fa fa-exclamation-circle fa-fw"></i> Please fill the necessary field </div>
                  <div class="form-group">
                    
                    <div class="col-md-6 mgbt-xs-10 mgtp-20">
                     
                      <div class="mgtp-10">
                          <input class="btn vd_bg-green vd_white" type="submit" id="submit-register" name="submit" value="Submit">
                      </div>
                    </div>
                    <div class="col-md-12 mgbt-xs-5"> </div>
                  </div>
                </form>
              </div>
            </div>
            
            
          </div>
       
         
        </div>
       
      </div>
      <!-- .vd_container --> 
    </div>
    <!-- .vd_content-wrapper --> 
    
    <!-- Middle Content End --> 
    
  </div>
  <!-- .container --> 
</div>
<!-- .content -->