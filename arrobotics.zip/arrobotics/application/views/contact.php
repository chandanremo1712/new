
<!-- Start main-content -->
<div class="main-content bg-lighter">
<!-- Section: inner-header -->
<section class="inner-header divider parallax layer-overlay overlay-dark-5" data-bg-img="<?=base_url()?>images/bg/bg6.jpg">
<div class="container pt-70 pb-20">
<!-- Section Content -->
<div class="section-content">
<div class="row">
<div class="col-md-12">
<h2 class="title text-white text-center">Contact Us</h2>
<ol class="breadcrumb text-left text-black mt-10">
<li><a href="#">Home</a></li>
<!--<li><a href="#">Pages</a></li>-->
<li class="active text-gray-silver">Contact Us</li>
</ol>
</div>
</div>
</div>
</div>
</section>

<!-- Section: Have Any Question -->
<section class="divider">
<div class="container pt-60 pb-60">
<div class="section-title mb-60">
<div class="row">
<div class="col-md-12">
<div class="esc-heading small-border text-center">
<h3>Have any Questions?</h3>
</div>
</div>
</div>
</div>
<div class="section-content">
<div class="row">
    
<div class="col-sm-12 col-md-4">
<div class="contact-info text-center">
<!--<i class="fa fa-phone font-36 mb-10 text-theme-colored"></i>-->
    
    <img src="<?=base_url()?>images/phone.gif" alt="" style="height:250px;">   
<h4>Call Us</h4>
<h5 class="text-gray">Phone: <?=$contact->phone?></h5>
</div>
</div>
    
    
<div class="col-sm-12 col-md-4">
<div class="contact-info text-center">
<!--<i class="fa fa-map-marker font-36 mb-10 text-theme-colored"></i>-->
    
     <img src="<?=base_url()?>images/address.gif" alt="" style="height:250px;">   
<h4>Address</h4>
<h5 class="text-gray"><?=$contact->address?></h5>
</div>
</div>
    
    
<div class="col-sm-12 col-md-4">
<div class="contact-info text-center">
<!--<i class="fa fa-envelope font-36 mb-10 text-theme-colored"></i>-->
     <img src="<?=base_url()?>images/email.gif" alt="" style="height:250px;">   
<h4>Email</h4>
<h5 class="text-gray"><?=$contact->email?></h5>
</div>
</div>
    
    
</div>
</div>
</div>
</section>

<!-- Section Contact -->
<section id="contact" class="divider bg-lighter">
<div class="container-fluid pt-0 pb-0">
<div class="section-content">
<div class="row">
<div class="col-sm-12 col-md-12">
<div class="contact-wrapper">
<h3 class="line-bottom mt-0 mb-20">Interested in discussing?</h3>

<!--<p class="mb-30">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>-->

<!-- Contact Form -->
<span style="color:green;font-size:20px;" id="msg"> <i><?php echo $this->session->flashdata('success_msg'); ?></i></span>

<form id="contact_form" name="contact_form" class="form-transparent" action="#" method="post">
<div class="row">
<div class="col-sm-6">
<div class="form-group">
<label for="form_name">Name <small>*</small></label>
<input name="name" class="form-control required txt_color" type="text" placeholder="Enter Name" required="" >
</div>
</div>
<div class="col-sm-6">
<div class="form-group">
<label for="form_email">Email <small>*</small></label>
<input name="email" class="form-control required email txt_color" type="email" placeholder="Enter Email">
</div>
</div>
</div>
<div class="row">
<div class="col-sm-6">
<div class="form-group">
<label for="form_name">Subject <small>*</small></label>
<input name="subject" class="form-control required txt_color" type="text" placeholder="Enter Subject">
</div>
</div>
<div class="col-sm-6">
<div class="form-group">
<label for="form_phone">Phone</label>
<input name="phone" class="form-control required txt_color" type="text" placeholder="Enter Phone">
</div>
</div>
</div>
<div class="form-group">
<label for="form_name">Message</label>
<textarea name="message" class="form-control required txt_color" rows="5" placeholder="Enter Message"></textarea>
</div>
<div class="form-group">
<input name="form_botcheck" class="form-control" type="hidden" value="" />
<button type="submit" name="submit" value="submit" class="btn btn-dark btn-theme-colored btn-flat mr-5" data-loading-text="Please wait...">Submit</button>
<button type="reset" class="btn btn-default btn-flat btn-theme-colored">Reset</button>
</div>
</form>


<!-- Contact Form Validation-->

</div>
</div>

    
</div>
</div>
</div>
</section>
</div>
<!-- end main-content -->
