

<!DOCTYPE html>

<html>

    <head>
        <meta charset="utf-8" />
        <title>Administrative Dashboard</title>
        <meta name="keywords" content="HTML5 Template, CSS3, All Purpose Admin Template, " />
        <meta name="description" content="Responsive Admin Template for multipurpose use">
        <meta name="author" content="Venmond">

        <!-- Set the viewport width to device width for mobile -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">    


        <!-- Fav and touch icons -->
<!--        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo base_url();?>backend/img/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo base_url();?>backend/img/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo base_url();?>backend/img/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="<?php echo base_url();?>backend/img/ico/apple-touch-icon-57-precomposed.png">
       -->

 <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url();?>frontend/images/favicon.png">


        <!-- CSS -->

        <!-- Bootstrap & FontAwesome & Entypo CSS -->
        <link href="<?php echo base_url();?>backend/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="<?php echo base_url();?>backend/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <!--[if IE 7]><link type="text/css" rel="stylesheet" href="css/font-awesome-ie7.min.css"><![endif]-->
        <link href="<?php echo base_url();?>backend/css/font-entypo.css" rel="stylesheet" type="text/css">    

        <!-- Fonts CSS -->
        <link href="<?php echo base_url();?>backend/css/fonts.css"  rel="stylesheet" type="text/css">

        <!-- Plugin CSS -->
        <link href="<?php echo base_url();?>backend/plugins/jquery-ui/jquery-ui.custom.min.css" rel="stylesheet" type="text/css">    
        <link href="<?php echo base_url();?>backend/plugins/prettyPhoto-plugin/css/prettyPhoto.css" rel="stylesheet" type="text/css">
        <link href="<?php echo base_url();?>backend/plugins/isotope/css/isotope.css" rel="stylesheet" type="text/css">
        <link href="<?php echo base_url();?>backend/plugins/pnotify/css/jquery.pnotify.css" media="screen" rel="stylesheet" type="text/css">    
        <link href="<?php echo base_url();?>backend/plugins/google-code-prettify/prettify.css" rel="stylesheet" type="text/css"> 


        <link href="<?php echo base_url();?>backend/plugins/mCustomScrollbar/jquery.mCustomScrollbar.css" rel="stylesheet" type="text/css">
        <link href="<?php echo base_url();?>backend/plugins/tagsInput/jquery.tagsinput.css" rel="stylesheet" type="text/css">
        <link href="<?php echo base_url();?>backend/plugins/bootstrap-switch/bootstrap-switch.css" rel="stylesheet" type="text/css">    
        <link href="<?php echo base_url();?>backend/plugins/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css">    
        <link href="<?php echo base_url();?>backend/plugins/bootstrap-timepicker/bootstrap-timepicker.min.css" rel="stylesheet" type="text/css">
        <link href="<?php echo base_url();?>backend/plugins/colorpicker/css/colorpicker.css" rel="stylesheet" type="text/css">            

        <!-- Specific CSS -->
        <link href="<?php echo base_url();?>backend/plugins/fullcalendar/fullcalendar.css" rel="stylesheet" type="text/css"><link href="plugins/fullcalendar/fullcalendar.print.css" rel="stylesheet" type="text/css"><link href="plugins/introjs/css/introjs.min.css" rel="stylesheet" type="text/css">    

        <!-- Theme CSS -->
        <link href="<?php echo base_url();?>backend/css/theme.min.css" rel="stylesheet" type="text/css">
        <!--[if IE]> <link href="css/ie.css" rel="stylesheet" > <![endif]-->
        <link href="<?php echo base_url();?>backend/css/chrome.css" rel="stylesheet" type="text/chrome"> <!-- chrome only css -->    
        

        <!-- Responsive CSS -->
        <link href="<?php echo base_url();?>backend/css/theme-responsive.min.css" rel="stylesheet" type="text/css"> 



<!--        <link href="<?php echo base_url();?>backend/css/bootstrap-select.css" rel="stylesheet" type="text/chrome">-->
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.1/css/bootstrap-select.min.css"/>
        <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>

        <!-- for specific page in style css -->

        <!-- for specific page responsive in style css -->


        <!-- Custom CSS -->
        <link href="<?php echo base_url();?>backend/custom/custom.css" rel="stylesheet" type="text/css">

      
        <!-- Head SCRIPTS -->
        <script type="text/javascript" src="<?php echo base_url();?>backend/js/modernizr.js"></script> 
        <script type="text/javascript" src="<?php echo base_url();?>backend/js/mobile-detect.min.js"></script> 
        <script type="text/javascript" src="<?php echo base_url();?>backend/js/mobile-detect-modernizr.js"></script> 
        
<!--         <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">-->
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
        <style type="text/css">
        .active {
            background-color: rgb(104, 136, 83)
        }
        #data-tables_filter {
            text-align: right;
        }
        #data-tables_paginate {
            text-align: right;
        }
        #add-alement {
            float:right;
        }
        
        .portlet > .tools > a {
            display: inline-block;
            height: 16px;
            margin-left: 5px;
        }
        
        .portlet.box > .tools > a.reload {
            background-image: url(<?php echo base_url();?>backend/img/input-spinner.gif);
        }
        </style>

    </head>    

    <body id="dashboard" class="full-layout  nav-right-hide nav-right-start-hide  nav-top-fixed      responsive    clearfix" data-active="dashboard "  data-smooth-scrolling="1">     
        <div class="vd_body">
            <!-- Header Start -->
            <header class="header-1" id="header">
                <div class="vd_top-menu-wrapper">
                    <div class="container ">
                        <div class="vd_top-nav vd_nav-width  ">
                            <div class="vd_panel-header">
                                <div class="logo">
                                    <a href="<?php echo base_url();?>" target="_blank"><img alt="logo" src="<?php echo base_url();?>frontend/images/Nxtstepnutrition-logo.png" alt="Nxtstepnutrition"></a>
                                </div>
                                <!-- logo -->
                                <div class="vd_panel-menu  hidden-sm hidden-xs" data-intro="<strong>Minimize Left Navigation</strong><br/>Toggle navigation size to medium or small size. You can set both button or one button only. See full option at documentation." data-step=1>
                                    <span class="nav-medium-button menu" data-toggle="tooltip" data-placement="bottom" data-original-title="Medium Nav Toggle" data-action="nav-left-medium">
                                        <i class="fa fa-bars"></i>
                                    </span>

                                    <span class="nav-small-button menu" data-toggle="tooltip" data-placement="bottom" data-original-title="Small Nav Toggle" data-action="nav-left-small">
                                        <i class="fa fa-ellipsis-v"></i>
                                    </span> 

                                </div>
                                <div class="vd_panel-menu left-pos visible-sm visible-xs">

                                    <span class="menu" data-action="toggle-navbar-left">
                                        <i class="fa fa-ellipsis-v"></i>
                                    </span>  


                                </div>
                                <div class="vd_panel-menu visible-sm visible-xs">
                                    <span class="menu visible-xs" data-action="submenu">
                                        <i class="fa fa-bars"></i>
                                    </span>        

                                    <span class="menu visible-sm visible-xs" data-action="toggle-navbar-right">
                                        <i class="fa fa-comments"></i>
                                    </span>                   

                                </div>                                     
                                <!-- vd_panel-menu -->
                            </div>
                            <!-- vd_panel-header -->

                        </div>    
                        <div class="vd_container">
                            <div class="row">
                                <div class="col-sm-5 col-xs-12">

<!--                                    <div class="vd_menu-search">
                                        <form id="search-box" method="post" action="#">
                                            <input type="text" name="search" class="vd_menu-search-text width-60" placeholder="Search">
                                            <div class="vd_menu-search-category"> <span data-action="click-trigger"> <span class="separator"></span> <span class="text">Category</span> <span class="icon"> <i class="fa fa-caret-down"></i></span> </span>
                                                <div class="vd_mega-menu-content width-xs-2 center-xs-2 right-sm" data-action="click-target">
                                                    <div class="child-menu">
                                                        <div class="content-list content-menu content">
                                                            <ul class="list-wrapper">
                                                                <li>
                                                                    <label>
                                                                        <input type="checkbox" value="all-files">
                                                                        <span>All Files</span></label>
                                                                </li>
                                                                <li>
                                                                    <label>
                                                                        <input type="checkbox" value="photos">
                                                                        <span>Photos</span></label>
                                                                </li>
                                                                <li>
                                                                    <label>
                                                                        <input type="checkbox" value="illustrations">
                                                                        <span>Illustrations</span></label>
                                                                </li>
                                                                <li>
                                                                    <label>
                                                                        <input type="checkbox" value="video">
                                                                        <span>Video</span></label>
                                                                </li>
                                                                <li>
                                                                    <label>
                                                                        <input type="checkbox" value="audio">
                                                                        <span>Audio</span></label>
                                                                </li>
                                                                <li>
                                                                    <label>
                                                                        <input type="checkbox" value="flash">
                                                                        <span>Flash</span></label>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <span class="vd_menu-search-submit"><i class="fa fa-search"></i> </span>
                                        </form>
                                    </div>-->
                                </div>
                                <div class="col-sm-7 col-xs-12">
                                    <div class="vd_mega-menu-wrapper">
                                        <div class="vd_mega-menu pull-right">
                                            <ul class="mega-ul">
                                              
                                                <li id="top-menu-profile" class="profile mega-li"> 
                                                    <a href="#" class="mega-link"  data-action="click-trigger"> 
                                                        <span  class="mega-image">
                                                            <img src="<?php echo base_url();?>backend/img/admin.png" alt="example image" />               
                                                        </span>
                                                        <span class="mega-name">
                                                            Administrative <i class="fa fa-caret-down fa-fw"></i> 
                                                        </span>
                                                    </a> 
                                                    <div class="vd_mega-menu-content  width-xs-2  left-xs left-sm" data-action="click-target">
                                                        <div class="child-menu"> 
                                                            <div class="content-list content-menu">
                                                                <ul class="list-wrapper pd-lr-10">
<!--                                                                    <li> <a href="#"> <div class="menu-icon"><i class=" fa fa-user"></i></div> <div class="menu-text">Edit Profile</div> </a> </li>
                                                                    <li> <a href="#"> <div class="menu-icon"><i class=" fa fa-trophy"></i></div> <div class="menu-text">My Achievements</div> </a> </li>
                                                                    <li> <a href="#"> <div class="menu-icon"><i class=" fa fa-envelope"></i></div> <div class="menu-text">Messages</div><div class="menu-badge"><div class="badge vd_bg-red">10</div></div> </a>  </li>
                                                                    <li> <a href="#"> <div class="menu-icon"><i class=" fa fa-tasks
                                                                                                                "></i></div> <div class="menu-text"> Tasks</div><div class="menu-badge"><div class="badge vd_bg-red">5</div></div> </a> </li> 
                                                                    <li class="line"></li>                
                                                                    <li> <a href="#"> <div class="menu-icon"><i class=" fa fa-lock
                                                                                                                "></i></div> <div class="menu-text">Privacy</div> </a> </li>
                                                                    <li> <a href="#"> <div class="menu-icon"><i class=" fa fa-cogs"></i></div> <div class="menu-text">Settings</div> </a> </li>-->
                                                                    <li> <a href="<?php echo base_url();?>Webadmin/Super/change_password"> <div class="menu-icon"><i class="  fa fa-key"></i></div> <div class="menu-text">Change Password</div> </a> </li>
                                                                    <li> <a href="<?php echo base_url();?>Webadmin/Login/logout"> <div class="menu-icon"><i class=" fa fa-sign-out"></i></div>  <div class="menu-text">Sign Out</div> </a> </li>
<!--                                                                    <li class="line"></li>                
                                                                    <li> <a href="#"> <div class="menu-icon"><i class=" fa fa-question-circle"></i></div> <div class="menu-text">Help</div> </a> </li>
                                                                    <li> <a href="#"> <div class="menu-icon"><i class=" glyphicon glyphicon-bullhorn"></i></div> <div class="menu-text">Report a Problem</div> </a> </li>              -->
                                                                </ul>
                                                            </div> 
                                                        </div> 
                                                    </div>     

                                                </li>               

                                              
                                            </ul>
                                            <!-- Head menu search form ends -->                         
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <!-- container --> 
                </div>
                <!-- vd_primary-menu-wrapper --> 

            </header>
            <!-- Header Ends --> 
            <div class="content">
                <div class="container">
                    <div class="vd_navbar vd_nav-width vd_navbar-tabs-menu vd_navbar-left  ">
                        <div class="navbar-tabs-menu clearfix">
                            <span class="expand-menu" data-action="expand-navbar-tabs-menu">
                                <span class="menu-icon menu-icon-left">
                                    <i class="fa fa-ellipsis-h"></i>
                                    <span class="badge vd_bg-red">
                                        20
                                    </span>                    
                                </span>
                                <span class="menu-icon menu-icon-right">
                                    <i class="fa fa-ellipsis-h"></i>
                                    <span class="badge vd_bg-red">
                                        20
                                    </span>                    
                                </span>                
                            </span>
<!--                            <div class="menu-container">
                                <div class="vd_mega-menu-wrapper">
                                    <div class="vd_mega-menu"  data-intro="<strong>Tabs Menu</strong><br/>Can be placed for dropdown menu, tabs, or user profile. Responsive for medium and small size navigation." data-step=3>
                                        <ul class="mega-ul">
                                            <li id="home" class="one-icon mega-li"> 
                                                <a class="mega-link  vd_bg-blue" href="javascript:void(0);"  data-action="click-trigger">
                                                    <span class="mega-icon">
                                                        <i class="fa fa-cloud"></i>
                                                    </span>
                                                    <span class="badge vd_bg-red">
                                                        10
                                                    </span>
                                                </a>
                                                <div class="vd_mega-menu-content width-xs-3 width-sm-5 width-md-6   right-xs " data-action="click-target">
                                                    <div class="child-menu">  
                                                        <div class="title"> 
                                                            Server Status
                                                            <div class="vd_panel-menu">
                                                                <span data-original-title="Find Server" data-toggle="tooltip" data-placement="bottom" class="menu">
                                                                    <i class="fa fa-search"></i>
                                                                </span>                 
                                                                <span data-original-title="Message Setting" data-toggle="tooltip" data-placement="bottom" class="menu">
                                                                    <i class="fa fa-cog"></i>
                                                                </span>                                                                              
                                                            </div>
                                                        </div>                 
                                                        <div class="content-grid column-md-3 column-sm-2 column-xs-1 height-xs-auto height-sm-4">	
                                                            <div data-rel="scroll">
                                                                <ul class="list-wrapper">
                                                                    <li><a>
                                                                            <div class="menu-icon">
                                                                                <i class="fa fa-cloud"></i>
                                                                            </div>
                                                                            <div class="menu-text"> Venmond.com
                                                                                <div class="menu-info">
                                                                                    <span class="menu-date vd_bg-green badge">Online</span>
                                                                                    <div class="menu-status  text-left">
                                                                                        <span class="text">Disk Usage</span>
                                                                                        <span class="value pull-right vd_black">4.35/140 GB</span>
                                                                                    </div>
                                                                                    <div class="menu-info">
                                                                                        <div class="progress">
                                                                                            <div style="width:15%" class="progress-bar progress-bar-info"> 
                                                                                            </div>
                                                                                        </div>                                                   
                                                                                    </div>                                     
                                                                                    <div class="menu-status  text-left">
                                                                                        <span class="text">BW Usage</span>
                                                                                        <span class="value pull-right vd_black">1600/2500 GB</span>
                                                                                    </div>
                                                                                    <div class="menu-info">
                                                                                        <div class="progress">
                                                                                            <div style="width:65%" class="progress-bar  progress-bar-warning"> 
                                                                                            </div>
                                                                                        </div>                                                   
                                                                                    </div>                                                                                                               
                                                                                    <span class="menu-action">
                                                                                        <span class="menu-action-icon vd_green vd_bd-green" data-original-title="Reboot Server" data-toggle="tooltip" data-placement="bottom">
                                                                                            <i class="fa fa-refresh"></i>
                                                                                        </span> 
                                                                                        <span class="menu-action-icon vd_red vd_bd-red" data-original-title="Stop Server" data-toggle="tooltip" data-placement="bottom">
                                                                                            <i class="fa fa-stop"></i>
                                                                                        </span>
                                                                                    </span>                                
                                                                                </div>
                                                                            </div> 
                                                                        </a></li>
                                                                    <li> <a>
                                                                            <div class="menu-icon">
                                                                                <i class="fa fa-cloud"></i>
                                                                            </div>
                                                                            <div class="menu-text"> Venmond.com
                                                                                <div class="menu-info">
                                                                                    <span class="menu-date vd_bg-grey badge">Offline</span>
                                                                                    <div class="menu-status  text-left">
                                                                                        <span class="text">Disk Usage</span>
                                                                                        <span class="value pull-right vd_black">4.35/140 GB</span>
                                                                                    </div>
                                                                                    <div class="menu-info">
                                                                                        <div class="progress">
                                                                                            <div style="width:15%" class="progress-bar progress-bar-info"> 
                                                                                            </div>
                                                                                        </div>                                                   
                                                                                    </div>                                     
                                                                                    <div class="menu-status  text-left">
                                                                                        <span class="text">BW Usage</span>
                                                                                        <span class="value pull-right vd_black">1600/2500 GB</span>
                                                                                    </div>
                                                                                    <div class="menu-info">
                                                                                        <div class="progress">
                                                                                            <div style="width:65%" class="progress-bar  progress-bar-warning"> 
                                                                                            </div>
                                                                                        </div>                                                   
                                                                                    </div>                                                                                                               
                                                                                    <span class="menu-action">
                                                                                        <span class="menu-action-icon vd_green vd_bd-green" data-original-title="Reboot Server" data-toggle="tooltip" data-placement="bottom">
                                                                                            <i class="fa fa-refresh"></i>
                                                                                        </span> 
                                                                                        <span class="menu-action-icon vd_red vd_bd-red" data-original-title="Stop Server" data-toggle="tooltip" data-placement="bottom">
                                                                                            <i class="fa fa-stop"></i>
                                                                                        </span>
                                                                                    </span>                                
                                                                                </div>
                                                                            </div> 
                                                                        </a></li>
                                                                    <li> <a>
                                                                            <div class="menu-icon">
                                                                                <i class="fa fa-cloud"></i>
                                                                            </div>
                                                                            <div class="menu-text"> Venmond.com
                                                                                <div class="menu-info">
                                                                                    <span class="menu-date vd_bg-grey badge">Offline</span>
                                                                                    <div class="menu-status  text-left">
                                                                                        <span class="text">Disk Usage</span>
                                                                                        <span class="value pull-right vd_black">4.35/140 GB</span>
                                                                                    </div>
                                                                                    <div class="menu-info">
                                                                                        <div class="progress">
                                                                                            <div style="width:15%" class="progress-bar progress-bar-info"> 
                                                                                            </div>
                                                                                        </div>                                                   
                                                                                    </div>                                     
                                                                                    <div class="menu-status  text-left">
                                                                                        <span class="text">BW Usage</span>
                                                                                        <span class="value pull-right vd_black">1600/2500 GB</span>
                                                                                    </div>
                                                                                    <div class="menu-info">
                                                                                        <div class="progress">
                                                                                            <div style="width:65%" class="progress-bar  progress-bar-warning"> 
                                                                                            </div>
                                                                                        </div>                                                   
                                                                                    </div>                                                                                                               
                                                                                    <span class="menu-action">
                                                                                        <span class="menu-action-icon vd_green vd_bd-green" data-original-title="Reboot Server" data-toggle="tooltip" data-placement="bottom">
                                                                                            <i class="fa fa-refresh"></i>
                                                                                        </span> 
                                                                                        <span class="menu-action-icon vd_red vd_bd-red" data-original-title="Stop Server" data-toggle="tooltip" data-placement="bottom">
                                                                                            <i class="fa fa-stop"></i>
                                                                                        </span>
                                                                                    </span>                                
                                                                                </div>
                                                                            </div> 
                                                                        </a></li>
                                                                    <li><a> 
                                                                            <div class="menu-icon">
                                                                                <i class="fa fa-cloud"></i>
                                                                            </div>
                                                                            <div class="menu-text"> Venmond.com
                                                                                <div class="menu-info">
                                                                                    <span class="menu-date vd_bg-grey badge">Offline</span>
                                                                                    <div class="menu-status  text-left">
                                                                                        <span class="text">Disk Usage</span>
                                                                                        <span class="value pull-right vd_black">4.35/140 GB</span>
                                                                                    </div>
                                                                                    <div class="menu-info">
                                                                                        <div class="progress">
                                                                                            <div style="width:15%" class="progress-bar progress-bar-info"> 
                                                                                            </div>
                                                                                        </div>                                                   
                                                                                    </div>                                     
                                                                                    <div class="menu-status  text-left">
                                                                                        <span class="text">BW Usage</span>
                                                                                        <span class="value pull-right vd_black">1600/2500 GB</span>
                                                                                    </div>
                                                                                    <div class="menu-info">
                                                                                        <div class="progress">
                                                                                            <div style="width:65%" class="progress-bar  progress-bar-warning"> 
                                                                                            </div>
                                                                                        </div>                                                   
                                                                                    </div>                                                                                                               
                                                                                    <span class="menu-action">
                                                                                        <span class="menu-action-icon vd_green vd_bd-green" data-original-title="Reboot Server" data-toggle="tooltip" data-placement="bottom">
                                                                                            <i class="fa fa-refresh"></i>
                                                                                        </span> 
                                                                                        <span class="menu-action-icon vd_red vd_bd-red" data-original-title="Stop Server" data-toggle="tooltip" data-placement="bottom">
                                                                                            <i class="fa fa-stop"></i>
                                                                                        </span>
                                                                                    </span>                                
                                                                                </div>
                                                                            </div> 
                                                                        </a></li>                                                                                                                         

                                                                </ul>
                                                            </div> 
                                                            <div class="closing text-center" style="">
                                                                <a href="#">See All Requests <i class="fa fa-angle-double-right"></i></a>
                                                            </div>                                                                       
                                                        </div>                              
                                                    </div>                 
                                                </div>   
                                            </li>
                                            <li id="tabs-menu-tasks" class="one-icon mega-li"> 
                                                <a class="mega-link  vd_bg-green" href="javascript:void(0);"   data-action="click-trigger">
                                                    <span class="mega-icon">
                                                        <i class="fa fa-tasks"></i>
                                                    </span>
                                                    <span class="badge vd_bg-red">
                                                        8
                                                    </span>
                                                </a>
                                                <div class="vd_mega-menu-content width-xs-3 width-sm-4 width-md-5 right-xs" data-action="click-target">
                                                    <div class="child-menu">  
                                                        <div class="title"> 
                                                            You have 8 pending tasks
                                                            <div class="vd_panel-menu">
                                                                <span data-original-title="Task Setting" data-toggle="tooltip" data-placement="bottom" class="menu">
                                                                    <i class="fa fa-cog"></i>
                                                                </span>                                                                              
                                                            </div>
                                                        </div>                 
                                                        <div class="content-list content-image">	
                                                            <div data-rel="scroll">
                                                                <ul class="list-wrapper pd-lr-10">
                                                                    <li> <a href="#"> 
                                                                            <div class="menu-icon vd_blue"><i class="fa fa-bolt"></i></div> 
                                                                            <div class="menu-text"> Electricity Problem
                                                                                <div class="menu-info">
                                                                                    <div class="progress progress-sm">
                                                                                        <div style="width:85%" class="progress-bar progress-bar-info"> 
                                                                                            85%
                                                                                        </div>
                                                                                    </div>                                                                                                    
                                                                                </div>
                                                                            </div> 
                                                                        </a> </li>
                                                                    <li> <a href="#"> 
                                                                            <div class="menu-icon vd_yellow"><i class="fa fa-code"></i></div>  
                                                                            <div class="menu-text">  Finish coding jquery plugin
                                                                                <div class="menu-info">
                                                                                    <div class="progress progress-sm">
                                                                                        <div style="width:20%" class="progress-bar progress-bar-danger"> 
                                                                                            20%
                                                                                        </div>
                                                                                    </div>                                                                                                    
                                                                                </div>                           
                                                                            </div> 
                                                                        </a> </li>    
                                                                    <li> <a> 
                                                                            <div class="menu-icon"><img alt="example image" src="<?php echo base_url();?>backend/img/avatar/avatar-3.jpg"></div> 
                                                                            <div class="menu-text"> Client: Zoe Project
                                                                                <div class="menu-info">
                                                                                    <span class="menu-date">Make a call</span>                                                                         
                                                                                    <span class="menu-action">
                                                                                        <span class="menu-action-icon" data-original-title="Call" data-toggle="tooltip" data-placement="bottom">
                                                                                            <i class="fa fa-phone"></i>
                                                                                        </span>                                                                            
                                                                                    </span>                                
                                                                                </div>                                                     
                                                                            </div> 
                                                                        </a> </li>                                     
                                                                    <li> <a href="#"> 
                                                                            <div class="menu-icon"><i class=" fa fa-magic"></i></div>  
                                                                            <div class="menu-text">  Final error check on new templates
                                                                                <div class="menu-info">
                                                                                    <div class="progress progress-sm">
                                                                                        <div style="width:95%" class="progress-bar progress-bar-success"> 
                                                                                            95%
                                                                                        </div>
                                                                                    </div>                                                                                                    
                                                                                </div>                           
                                                                            </div> 
                                                                        </a> </li> 
                                                                    <li> <a href="#"> 
                                                                            <div class="menu-icon vd_green"><i class=" fa fa-camera"></i></div>  
                                                                            <div class="menu-text">  Update product image
                                                                                <div class="menu-info">
                                                                                    <div class="progress progress-sm">
                                                                                        <div style="width:50%" class="progress-bar progress-bar-warning"> 
                                                                                            50%
                                                                                        </div>
                                                                                    </div>                                                                                                    
                                                                                </div>                           
                                                                            </div> 
                                                                        </a> </li>
                                                                    <li> <a href="#"> 
                                                                            <div class="menu-icon vd_blue"><i class="fa fa-bolt"></i></div> 
                                                                            <div class="menu-text"> Electricity Problem
                                                                                <div class="menu-info">
                                                                                    <div class="progress progress-sm">
                                                                                        <div style="width:85%" class="progress-bar progress-bar-info"> 
                                                                                            85%
                                                                                        </div>
                                                                                    </div>                                                                                                    
                                                                                </div>
                                                                            </div> 
                                                                        </a> </li>
                                                                    <li> <a href="#"> 
                                                                            <div class="menu-icon vd_yellow"><i class=" fa fa-code"></i></div>  
                                                                            <div class="menu-text">  Finish coding jquery plugin
                                                                                <div class="menu-info">
                                                                                    <div class="progress progress-sm">
                                                                                        <div style="width:20%" class="progress-bar progress-bar-danger"> 
                                                                                            20%
                                                                                        </div>
                                                                                    </div>                                                                                                    
                                                                                </div>                           
                                                                            </div> 
                                                                        </a> </li>    
                                                                    <li> <a> 
                                                                            <div class="menu-icon"><img alt="example image" src="<?php echo base_url();?>backend/img/avatar/avatar-3.jpg"></div> 
                                                                            <div class="menu-text"> Client: Zoe Project
                                                                                <div class="menu-info">
                                                                                    <span class="menu-date">Make a call</span>                                                                         
                                                                                    <span class="menu-action">
                                                                                        <span class="menu-action-icon" data-original-title="Call" data-toggle="tooltip" data-placement="bottom">
                                                                                            <i class="fa fa-phone"></i>
                                                                                        </span>                                                                            
                                                                                    </span>                                
                                                                                </div>                                                     
                                                                            </div> 
                                                                        </a> </li>                                     


                                                                </ul>
                                                            </div>
                                                            <div class="closing text-center" style="">
                                                                <a href="#">See All Tasks <i class="fa fa-angle-double-right"></i></a>
                                                            </div>                                                                       
                                                        </div>                              
                                                    </div>                       
                                                </div>   
                                            </li>  
                                            <li id="test-2" class="one-icon mega-li"> 
                                                <a class="mega-link vd_bg-yellow " href="javascript:void(0);" data-action="click-trigger">
                                                    <span class="mega-icon">
                                                        <i class="fa fa-pencil"></i>
                                                    </span>
                                                </a>     
                                                <div class="vd_mega-menu-content width-xs-3 width-sm-4 width-md-5 center-xs-3 right-sm pd-0" data-action="click-target">
                                                    <div class="child-menu">  

                                                        <textarea class="no-bd" rows="3" placeholder="What are you doing?" ></textarea>
                                                        <div class="vd_textarea-menu vd_bg-yellow vd_bd-yellow" >
                                                            <ul class="nav nav-pills ">
                                                                <li class="one-icon">
                                                                    <a data-toggle="tab-post" href="javascript:void(0);">
                                                                        <span class="menu-icon">
                                                                            <i class="fa fa-user fa-fw"></i>
                                                                        </span>
                                                                    </a>
                                                                </li>
                                                                <li class="one-icon">
                                                                    <a data-toggle="tab-post" href="javascript:void(0);">
                                                                        <span class="menu-icon">
                                                                            <i class="fa fa-camera fa-fw"></i>
                                                                        </span>
                                                                    </a>
                                                                </li>   
                                                                <li class="one-icon">
                                                                    <a data-toggle="tab-post" href="javascript:void(0);">
                                                                        <span class="menu-icon">
                                                                            <i class="fa fa-smile-o fa-fw"></i>
                                                                        </span>
                                                                    </a>
                                                                </li>  
                                                                <li class="pull-right">
                                                                    <a data-toggle="tab-post" href="javascript:void(0);" style="border-left:1px solid rgba(255,255,255,.3)">
                                                                        <span class="menu-icon">
                                                                            <i class="fa fa-check fa-fw"></i>
                                                                        </span>                             
                                                                        <span class="menu-text">
                                                                            Post
                                                                        </span>                              
                                                                    </a>
                                                                </li>  

                                                            </ul>

                                                        </div>

                                                    </div>                      
                                                </div>                             

                                            </li>  
                                            <li id="test" class="one-icon mega-li"> 
                                                <a class="mega-link vd_bg-red" href="javascript:void(0);" data-action="click-trigger">
                                                    <span class="mega-icon">
                                                        <i class="fa fa-plus"></i>
                                                    </span>
                                                </a>
                                                <div class="vd_mega-menu-content  width-xs-2  center-xs-2" data-action="click-target" >
                                                    <div class="child-menu"> 
                                                        <div class="content-list content-menu">
                                                            <ul class="list-wrapper pd-lr-10">
                                                                <li> <a href="#"> <span class="menu-icon"><i class=" fa fa-user"></i></span> <span class="menu-text">Write Article</span> </a> </li>
                                                                <li> <a href="#"> <span class="menu-icon"><i class=" fa fa-trophy"></i></span> <span class="menu-text">Write News</span> </a> </li>
                                                                <li> <a href="#"> <span class="menu-icon"><i class=" fa fa-flask"></i></span> <span class="menu-text">Add Product</span> </a>  </li>

                                                            </ul>
                                                        </div> 
                                                    </div> 
                                                </div>        
                                            </li>      
                                        </ul>                        	
                                    </div>                
                                </div>
                            </div>                                                   -->
                        </div>