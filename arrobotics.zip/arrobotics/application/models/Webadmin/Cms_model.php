<?php
class Cms_model extends CI_Model {
	
      function __construct() { 
         parent::__construct(); 
		 
      }
      
    public function fetch_all()
    {
        $this->db->select('*');
        //$this->db->where('status', 'Yes');
        $query=$this->db->get('tbl_cms');
        return $query->result();
        
    } 
    
    public function fetch_single($id)
    {
        $this->db->select('*');
        $this->db->where('id', $id);
        $query=$this->db->get('tbl_cms');
        return $query->row();
        
    } 
    
    public function add_cms($data)
    {
        $query=$this->db->insert('tbl_cms',$data);
        return $query;
        
    }
    
    public function eidt_cms($data, $id)
    {
        $this->db->where('id', $id);
        $this->db->update('tbl_cms',$data);
        return true;
        
    }
    
    public function delete_single($id)
    {
         $this->db->where('id', $id);
         $delete = $this->db->delete('tbl_cms'); 
         return $delete;
        
    }
	  
	  
}
?>