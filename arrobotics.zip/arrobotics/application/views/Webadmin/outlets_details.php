<style>
    .dl{
        color:red;
    }
    
    </style>

<div class="vd_content-wrapper">
      <div class="vd_container">
        <div class="vd_content clearfix">
          <div class="vd_head-section clearfix">
            <div class="vd_panel-header">
              <ul class="breadcrumb">
                <li><a href="<?php echo base_url()?>Webadmin/Dashboard">Home</a> </li>
                <li><a href="<?php echo base_url()?>Webadmin/Tutor">Service Outlets List</a> </li>
                <li class="active"><?php if($this->uri->segment(3) == "edit_details"){echo 'Edit';}elseif($this->uri->segment(3) == "add_details"){echo 'Add';}elseif($this->uri->segment(3)=="view_details"){echo 'View';}?> Service Outlets  </li>
              </ul>
              <div class="vd_panel-menu hidden-sm hidden-xs" data-intro="<strong>Expand Control</strong><br/>To expand content page horizontally, vertically, or Both. If you just need one button just simply remove the other button code." data-step=5  data-position="left">
    <div data-action="remove-navbar" data-original-title="Remove Navigation Bar Toggle" data-toggle="tooltip" data-placement="bottom" class="remove-navbar-button menu"> <i class="fa fa-arrows-h"></i> </div>
      <div data-action="remove-header" data-original-title="Remove Top Menu Toggle" data-toggle="tooltip" data-placement="bottom" class="remove-header-button menu"> <i class="fa fa-arrows-v"></i> </div>
      <div data-action="fullscreen" data-original-title="Remove Navigation Bar and Top Menu Toggle" data-toggle="tooltip" data-placement="bottom" class="fullscreen-button menu"> <i class="glyphicon glyphicon-fullscreen"></i> </div>
      
</div>
            </div>
          </div>
          <div class="vd_title-section clearfix">
            <div class="vd_panel-header">
              <h1><?php if($this->uri->segment(3) == "edit_details"){echo 'Edit';}elseif($this->uri->segment(3) == "add_details"){echo 'Add';}elseif($this->uri->segment(3)=="view_details"){echo 'View';}?> User </h1>
              </div>
          </div>
        <?php if($this->uri->segment(3) == 'edit_details'){?>    
          <div class="vd_content-section clearfix">
            <div class="panel widget light-widget">
              <div class="panel-heading no-title"> </div>
              <div class="panel-body">
               <?php if(isset($succ)){?>
                  <div class="alert alert-success alert-dismissable">
                        <button aria-hidden="true" data-dismiss="alert" class="close" type="button"><i class="icon-cross"></i></button>
                        <i class="fa fa-check-circle append-icon"></i><strong>Success!</strong> <?php echo $succ;?> 
                  </div>
               <?php }?>
              <?php if(isset($error)){?>
                  <div class="alert alert-danger alert-dismissable alert-condensed">
                        <button aria-hidden="true" data-dismiss="alert" class="close" type="button"><i class="icon-cross"></i></button>
                         <?php echo $error['error'];?>
                  </div>
              <?php }?>
                <h2 class="mgbt-xs-20">Service Outlets Details</h2>
            
                <form class="form-horizontal"  action="<?php echo base_url()?>Webadmin/Outlets/edit_details" role="form1" method="post" id="register-form1" enctype="multipart/form-data">
                    <input type="hidden" name="id" value="<?php echo $fetch->id;?>"> 
                  <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2"> Name<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <input type="text" placeholder=" Name" class="width-60 required" name="name" value="<?php echo $fetch->name;?>" id="name" required >
                      </div>
                    </div>
                  </div>
                    
                       <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2"> Username<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <input type="text" placeholder="Username" class="width-60 required" name="username" value="<?php echo $fetch->username;?>" id="username" required >
                      </div>
                    </div>
                  </div>
                    
                        <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2"> Email<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <input type="email" placeholder="Email" class="width-60 required" name="email" value="<?php echo $fetch->email;?>" id="email" required >
                      </div>
                    </div>
                  </div>
                    
                 
              
                    
                    
               <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Password<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <input type="text" placeholder="Password" class="width-60 required" name="password" value="<?php echo base64_decode($fetch->password);?>" id="password" required minlength="6">
                      </div>
                    </div>
                  </div>
                    
                
                    
                    <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Phone<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <input type="text" placeholder="Mobile" class="width-60 required" name="mobile" id="mobile" required value="<?php echo $fetch->phone;?>" minlength="10" onKeyPress="return numbersonly(event)">
                      </div>
                    </div>
                  </div>
                    
                    
                    <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Address<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <input type="text" placeholder="Address" class="width-60 required" name="address" id="address" required value="<?php echo $fetch->address;?>" >
                      </div>
                    </div>
                  </div>
       
   
                          <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Wash to Tumble Dry<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <input type="text" placeholder="Price" class="width-60 required cost" name="wash_to_tumble_dry" id="wash_to_tumble_dry" required=""   value="<?php echo $fetch->wash_to_tumble_dry;?>">
                      </div>
                    </div>
                  </div>
                    
                         <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Wash and Iron<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <input type="text" placeholder="Price" class="width-60 required cost" name="wash_and_iron" id="wash_and_iron"  required=""   value="<?php echo $fetch->wash_and_iron;?>" >
                      </div>
                    </div>
                  </div>
                    
                         <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Dry Clean<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <input type="text" placeholder="Price" class="width-60 required cost" name="dry_clean" id="dry_clean"   required=""   value="<?php echo $fetch->dry_clean;?>">
                      </div>
                    </div>
                  </div>
                    
                      <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Ironing<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <input type="text" placeholder="Price" class="width-60 required cost" name="ironing" id="ironing"  required=""   value="<?php echo $fetch->ironing;?>" >
                      </div>
                    </div>
                  </div>
                    
                    <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Bedding<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <input type="text" placeholder="Price" class="width-60 required cost" name="bedding" id="bedding"   required=""   value="<?php echo $fetch->bedding;?>">
                      </div>
                    </div>
                  </div>                 
                    

                   <?php
                    if($fetch->profile_image != "")
                        $pic = base_url().'profile/'.$fetch->profile_image;
                    else
                        $pic =  base_url()."profile/nopic.jpg";
                 ?>
<!--                    <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Profile Image<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <img id="blah" style="border: 2px solid #000; margin-bottom:5px;" src="<?php echo $pic;?>" height="150">
                          <input type="hidden" class="width-60" value="<?php echo $fetch->profile_image;?>" name="old_img">
                        <input type="file" class="width-60" name="file" id="imgInp">
                        [Image size must be less than 2MB]
                      </div>
                    </div>
                  </div> -->
                  
                  <div id="vd_login-error" class="alert alert-danger hidden"><i class="fa fa-exclamation-circle fa-fw"></i> Please fill the necessary field </div>
                  <div class="form-group">
                    <div class="col-sm-2"></div>
                    <div class="col-md-6 mgbt-xs-10 mgtp-20">
                     
                      <div class="mgtp-10">
                          <input class="btn vd_bg-green vd_white" type="submit" id="submit-register" name="submit" value="Submit">
                      </div>
                    </div>
                    <div class="col-md-12 mgbt-xs-5"> </div>
                  </div>
                </form>
              </div>
            </div>
            
            
          </div>
        <?php }elseif($this->uri->segment(3) == 'add_details'){?>
            <div class="vd_content-section clearfix">
            <div class="panel widget light-widget">
              <div class="panel-heading no-title"> </div>
              <div class="panel-body">
               <?php if(isset($succ)){?>
                  <div class="alert alert-success alert-dismissable">
                        <button aria-hidden="true" data-dismiss="alert" class="close" type="button"><i class="icon-cross"></i></button>
                        <i class="fa fa-check-circle append-icon"></i><strong>Success!</strong> <?php echo $succ;?> 
                  </div>
               <?php }?>
              <?php if(isset($error)){?>
                  <div class="alert alert-danger alert-dismissable alert-condensed">
                        <button aria-hidden="true" data-dismiss="alert" class="close" type="button"><i class="icon-cross"></i></button>
                         <?php echo $error['error'];?>
                  </div>
              <?php }?>
                <h2 class="mgbt-xs-20">Service Outlets Details</h2>
            
                <form class="form-horizontal"  action="<?php echo base_url()?>Webadmin/Outlets/add_details" role="form1" method="post" id="register-form1" enctype="multipart/form-data">
                    
                 <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2"> Name<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <input type="text" placeholder="Name" class="width-60 required" name="name"  id="name"  >
                      </div>
                       
                    </div>
                  </div>
                    
                       <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2"> Username<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <input type="text" placeholder="Username" class="width-60 required" name="username" id="username"  >
                       <span class="dl" ><?php echo form_error('username'); ?></span>
                      </div>
                      
                    </div>
                  </div>
                    
                        <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2"> Email<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <input type="email" placeholder="Email" class="width-60 required" name="email"  id="email"  >
                           <span class="dl"><?php echo form_error('email'); ?></span>
                      </div>
                 
                    </div>
                  </div>
                    
                 
              
                    
                    
               <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Password<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <input type="text" placeholder="Password" class="width-60 required" name="password"  id="password"  minlength="6">
                      </div>
                    </div>
                  </div>
                    
                
                    
                    <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Phone<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <input type="text" placeholder="Mobile" class="width-60 required" name="mobile" id="mobile"   minlength="10" onKeyPress="return numbersonly(event)">
                      </div>
                    </div>
                  </div>
                    
                    
                    <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Address<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <input type="text" placeholder="Address" class="width-60 required" name="address" id="address"   >
                      </div>
                    </div>
                  </div>
                    
                          <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Wash to Tumble Dry<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <input type="text" placeholder="Price" class="width-60 required cost" name="wash_to_tumble_dry" id="wash_to_tumble_dry"   >
                      </div>
                    </div>
                  </div>
                    
                         <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Wash and Iron<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <input type="text" placeholder="Price" class="width-60 required cost" name="wash_and_iron" id="wash_and_iron"   >
                      </div>
                    </div>
                  </div>
                    
                         <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Dry Clean<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <input type="text" placeholder="Price" class="width-60 required cost" name="dry_clean" id="dry_clean"   >
                      </div>
                    </div>
                  </div>
                    
                      <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Ironing<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <input type="text" placeholder="Price" class="width-60 required cost" name="ironing" id="ironing"   >
                      </div>
                    </div>
                  </div>
                    
                    <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Bedding<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <input type="text" placeholder="Price" class="width-60 required cost" name="bedding" id="bedding"   >
                      </div>
                    </div>
                  </div>


                   <?php
                  
                        $pic =  base_url()."profile/noimg.png";
                 ?>
<!--                    <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-2">Profile Image<span class="vd_red">*</span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-10">
                          <img id="blah" style="border: 2px solid #000; margin-bottom:5px;" src="<?php echo $pic;?>" height="150">
                         
                        <input type="file" class="width-60" name="file" id="imgInp">
                        [Image size must be less than 2MB]
                      </div>
                    </div>
                  </div> -->
                   
                  <div id="vd_login-error" class="alert alert-danger hidden"><i class="fa fa-exclamation-circle fa-fw"></i> Please fill the necessary field </div>
                  <div class="form-group">
                    <div class="col-sm-2"></div>
                    <div class="col-md-6 mgbt-xs-10 mgtp-20">
                     
                      <div class="mgtp-10">
                          <input class="btn vd_bg-green vd_white" type="submit" id="submit-register" name="submit" value="Submit">
                      </div>
                    </div>
                    <div class="col-md-12 mgbt-xs-5"> </div>
                  </div>
                </form>
              </div>
            </div>
            
            
          </div>
         
        <?php }else{?>
         <div class="vd_content-section clearfix">
            <div class="panel widget light-widget">
              <div class="panel-heading no-title"> </div>
              <div class="panel-body">
               
                <h2 class="mgbt-xs-20">Service Outlets </h2>
            
                <form class="form-horizontal"  action="" role="form1" method="post" id="register-form1" enctype="multipart/form-data">
                    <input type="hidden" name="id" value="<?php echo $fetch->id;?>"> 
                  
<!--                   <div class="col-md-2">
                       <div class="form-group">
                           <div class="col-md-12">
                            
                            <div id="first-name-input-wrapper"  class="controls col-sm-10">
                                <?php
                                 if($fetch->profile_image != "" )
                                       $pic = base_url().'profile/'.$fetch->profile_image;
                                   else
                                       $pic =  base_url()."profile/nopic.jpg";
                                ?>
                                <img src="<?php echo $pic;?>">
                            </div>
                          </div>
                       </div>
                   </div>-->
                   <div class="col-md-10">
                       <div class="form-group">
                            <div class="col-md-12">
                              <label class="control-label  col-sm-3"> Name <span class="vd_red"></span></label>
                              <div id="first-name-input-wrapper"  class="controls col-sm-9">
                                  <?php echo $fetch->name;?>
                              </div>
                            </div>
                           
                           <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-3">Username<span class="vd_red"></span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-9">
                       <?php echo $fetch->username;?>
                      </div>
                    </div>
                  </div> 
                           
                             <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-3">Email<span class="vd_red"></span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-9">
                       <?php echo $fetch->email;?>
                      </div>
                    </div>
                  </div> 
                             <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-3">Password<span class="vd_red"></span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-9">
                       <?php echo base64_decode($fetch->password);?>
                      </div>
                    </div>
                  </div> 
                    
                    <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-3">Mobile<span class="vd_red"></span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-9">
                        <?php echo $fetch->phone;?>
                      </div>
                    </div>
                  </div>
                     
                           
                           
                           
                  <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-3">Address <span class="vd_red"></span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-9">
                         <?php echo stripslashes($fetch->address);?>
                      </div>
                    </div>
                  </div> 
                           
                             <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-3">Wash to Tumble Dry(£) <span class="vd_red"></span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-9">
                         <?php echo stripslashes($fetch->wash_to_tumble_dry);?>
                      </div>
                    </div>
                  </div>
                           
              <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-3">Wash And Iron(£) <span class="vd_red"></span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-9">
                         <?php echo stripslashes($fetch->wash_and_iron);?>
                      </div>
                    </div>
                  </div> 
                           
                              <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-3">Dry Clean(£) <span class="vd_red"></span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-9">
                         <?php echo stripslashes($fetch->dry_clean);?>
                      </div>
                    </div>
                  </div> 
                           
                                    <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-3">Ironing(£) <span class="vd_red"></span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-9">
                         <?php echo stripslashes($fetch->ironing);?>
                      </div>
                    </div>
                  </div>
                           
                                        <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-3">Bedding(£) <span class="vd_red"></span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-9">
                         <?php echo stripslashes($fetch->bedding);?>
                      </div>
                    </div>
                  </div>
                           
                           
                       <div class="form-group">
                    <div class="col-md-12">
                      <label class="control-label  col-sm-3">Registration Date<span class="vd_red"></span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-9">
                        <?php echo date('jS M Y',strtotime($fetch->date));?>
                      </div>
                    </div>
                  </div>
                           
<!--                      <div class="form-group">    
                           <div class="col-md-12">
                      <label class="control-label  col-sm-3">Email Verification:<span class="vd_red"></span></label>
                      <div id="first-name-input-wrapper"  class="controls col-sm-9">
                        <?php if($fetch->verification == 1){echo "Verified";}else{echo "Unverified";}?>
                      </div>
                    </div> 
                       </div>     -->
                         
                       

                        </div>
                  </div> 
                  
                  
                </form>
              </div>
            </div>
            
            
          </div>
            
        <?php }?>
        </div>
       
      </div>
      <!-- .vd_container --> 
    </div>
    <!-- .vd_content-wrapper --> 
    
    <!-- Middle Content End --> 
    
  </div>
  <!-- .container --> 
</div>
<!-- .content -->


<script>
function deleteloc(id)
{
     cnf = confirm("Are you confirm to delete?");
        if(cnf)
		{
                  
                    $('.portlet .tools a.reload').click();
                    $.ajax({
                        type:"GET",
                        url:"<?php echo base_url();?>Webadmin/Employer/DeleteLoc",
                        data:"id="+id,
                        success:function(data)
                        {
                                                      
                           if(data == "deleted")
                            {
                                $('#loc'+id).css('display', 'none');
                            }
                        }
                    });
			
		}
}


</script>

<script>
function numbersonly(e) {
                var unicode = e.charCode ? e.charCode : e.keyCode
                if (unicode != 8 && unicode != 46 && unicode != 37 && unicode != 27 && unicode != 38 && unicode != 39 && unicode != 40 && unicode != 9) { //if the key isn't the backspace key (which we should allow)
                    if (unicode < 48 || unicode > 57)
                        return false
                }
            }
</script>

